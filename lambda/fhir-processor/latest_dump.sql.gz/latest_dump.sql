mysqldump: Error: 'Access denied; you need (at least one of) the PROCESS privilege(s) for this operation' when trying to dump tablespaces
/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.23-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: db    Database: 
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `femr_db`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `femr_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `femr_db`;

--
-- Table structure for table `chief_complaints`
--

DROP TABLE IF EXISTS `chief_complaints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chief_complaints` (
  `id` int NOT NULL AUTO_INCREMENT,
  `value` text NOT NULL,
  `patient_encounter_id` int NOT NULL,
  `sort_order` int DEFAULT NULL,
  `language_code` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chief_complaints_patient_encounter_id_idx` (`patient_encounter_id`),
  CONSTRAINT `fk_chief_complaints_patient_encounter_id` FOREIGN KEY (`patient_encounter_id`) REFERENCES `patient_encounters` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chief_complaints`
--

LOCK TABLES `chief_complaints` WRITE;
/*!40000 ALTER TABLE `chief_complaints` DISABLE KEYS */;
INSERT INTO `chief_complaints` VALUES (1,'Head injury',31,0,NULL),(2,'cough',31,1,NULL),(3,'Pregnancy checkup',32,0,NULL),(4,'fever',32,1,NULL),(5,'Chest pain',33,0,NULL),(6,'shortness of breath',33,1,NULL),(7,'fever',33,2,NULL),(8,'Diarrhea',34,0,NULL),(9,'abdominal pain',34,1,NULL),(10,'dehydration',34,2,NULL),(11,'Limb fracture',35,0,NULL),(12,'severe pain',35,1,NULL),(13,'trauma',35,2,NULL),(14,'Measles suspected',36,0,NULL),(15,'high fever',36,1,NULL),(16,'rash',36,2,NULL),(17,'Severe cough',37,0,NULL),(18,'respiratory infection',37,1,NULL),(19,'fever',37,2,NULL),(20,'Skin disease',38,0,NULL),(21,'wound',38,1,NULL),(22,'laceration',38,2,NULL),(23,'Fever',39,0,NULL),(24,'suspected malaria',39,1,NULL),(25,'chills',39,2,NULL),(26,'Mental health problem',40,0,NULL),(27,'depression',40,1,NULL),(28,'anxiety',40,2,NULL),(29,'Hemorrhage',41,0,NULL),(30,'acute bleeding',41,1,NULL),(31,'trauma',41,2,NULL),(32,'Malnutrition',42,0,NULL),(33,'failure to thrive',42,1,NULL),(34,'underweight',42,2,NULL),(35,'Head injury',43,0,NULL),(36,'cough',43,1,NULL),(37,'Pregnancy checkup',44,0,NULL),(38,'fever',44,1,NULL),(39,'Chest pain',45,0,NULL),(40,'shortness of breath',45,1,NULL),(41,'fever',45,2,NULL),(42,'Diarrhea',46,0,NULL),(43,'abdominal pain',46,1,NULL),(44,'dehydration',46,2,NULL),(45,'Limb fracture',47,0,NULL),(46,'severe pain',47,1,NULL),(47,'trauma',47,2,NULL),(48,'Measles suspected',48,0,NULL),(49,'high fever',48,1,NULL),(50,'rash',48,2,NULL),(51,'Severe cough',49,0,NULL),(52,'respiratory infection',49,1,NULL),(53,'fever',49,2,NULL),(54,'Skin disease',50,0,NULL),(55,'wound',50,1,NULL),(56,'laceration',50,2,NULL),(57,'Fever',51,0,NULL),(58,'suspected malaria',51,1,NULL),(59,'chills',51,2,NULL),(60,'Mental health problem',52,0,NULL),(61,'depression',52,1,NULL),(62,'anxiety',52,2,NULL),(63,'Hemorrhage',53,0,NULL),(64,'acute bleeding',53,1,NULL),(65,'trauma',53,2,NULL),(66,'Malnutrition',54,0,NULL),(67,'failure to thrive',54,1,NULL),(68,'underweight',54,2,NULL),(69,'Head injury',55,0,NULL),(70,'cough',55,1,NULL),(71,'Pregnancy checkup',56,0,NULL),(72,'fever',56,1,NULL),(73,'Chest pain',57,0,NULL),(74,'shortness of breath',57,1,NULL),(75,'fever',57,2,NULL),(76,'Diarrhea',58,0,NULL),(77,'abdominal pain',58,1,NULL),(78,'dehydration',58,2,NULL),(79,'Limb fracture',59,0,NULL),(80,'severe pain',59,1,NULL),(81,'trauma',59,2,NULL),(82,'Measles suspected',60,0,NULL),(83,'high fever',60,1,NULL),(84,'rash',60,2,NULL),(85,'Severe cough',61,0,NULL),(86,'respiratory infection',61,1,NULL),(87,'fever',61,2,NULL),(88,'Skin disease',62,0,NULL),(89,'wound',62,1,NULL),(90,'laceration',62,2,NULL),(91,'Fever',63,0,NULL),(92,'suspected malaria',63,1,NULL),(93,'chills',63,2,NULL),(94,'Mental health problem',64,0,NULL),(95,'depression',64,1,NULL),(96,'anxiety',64,2,NULL),(97,'Hemorrhage',65,0,NULL),(98,'acute bleeding',65,1,NULL),(99,'trauma',65,2,NULL),(100,'Malnutrition',66,0,NULL),(101,'failure to thrive',66,1,NULL),(102,'underweight',66,2,NULL),(103,'Major torso injury\r\n',69,0,NULL),(104,'Skin disease, Major torso injury',70,0,NULL),(105,'Minor Injury',71,0,NULL),(106,'Suspected tetanus',72,0,NULL),(107,'Suspected tetanus',73,0,NULL);
/*!40000 ALTER TABLE `chief_complaints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_diagnoses`
--

DROP TABLE IF EXISTS `concept_diagnoses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_diagnoses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `language_code` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_diagnoses`
--

LOCK TABLES `concept_diagnoses` WRITE;
/*!40000 ALTER TABLE `concept_diagnoses` DISABLE KEYS */;
INSERT INTO `concept_diagnoses` VALUES (1,'Acne Vulgaris',NULL),(2,'Allergies',NULL),(3,'Amenorrhea',NULL),(4,'Anemia, Iron Deficiency',NULL),(5,'Anemia, Sickle Cell',NULL),(6,'Anxiety Disorder',NULL),(7,'Arthritis, Osteo',NULL),(8,'Arthritis, Rheumatoid',NULL),(9,'Ascites',NULL),(10,'Asthma',NULL),(11,'Bacterial Infection, Abscess',NULL),(12,'Bacterial Infection, Skin',NULL),(13,'Bacterial Vaginosis',NULL),(14,'Trichomonas Vaginalis',NULL),(15,'Benign Prostatic Hyperplasia',NULL),(16,'Bronchitis',NULL),(17,'Bursitis',NULL),(18,'Cataracts',NULL),(19,'Cerebral Palsy',NULL),(20,'Chlamydia',NULL),(21,'Chronic Obstructive Pulmonary Disease',NULL),(22,'Constipation',NULL),(23,'Contact Dermatitis',NULL),(24,'Cough',NULL),(25,'Conjuctivitis',NULL),(26,'Cystitis',NULL),(27,'Dehydration',NULL),(28,'Dental, Abscess',NULL),(29,'Dental, Chipped Tooth',NULL),(30,'Dental, Gingivitis',NULL),(31,'Dental, Infection',NULL),(32,'Dental, Pain',NULL),(33,'Depression',NULL),(34,'Diabetes Mellitus, Type 1',NULL),(35,'Diabetes mellitus, Type 2',NULL),(36,'Diarrhea',NULL),(37,'Dizziness',NULL),(38,'Dry Eyes',NULL),(39,'Dry Skin',NULL),(40,'Dysmenorrhea',NULL),(41,'Dysuria',NULL),(42,'Ear Infection (not Otitis Media)',NULL),(43,'Eczema',NULL),(44,'Fever',NULL),(45,'Folliculitis',NULL),(46,'Gastric Ulcer',NULL),(47,'Gastritis',NULL),(48,'Gastroenteritis',NULL),(49,'Gastroesophageal Reflux Disease',NULL),(50,'Headache',NULL),(51,'Herpangina',NULL),(52,'Herpes Simplex Virus, Oral',NULL),(53,'Herpes Simplex Virus, Genital',NULL),(54,'High Blood Pressure',NULL),(55,'Hypertension',NULL),(56,'Irregular Menstruation',NULL),(57,'Laceration',NULL),(58,'Lipoma',NULL),(59,'Lymphadenitis',NULL),(60,'Malaria',NULL),(61,'Malnutrition',NULL),(62,'Melena',NULL),(63,'Nausea',NULL),(64,'Neuropathy',NULL),(65,'Orthostatic Hypotension',NULL),(66,'Otitis Media',NULL),(67,'Pain, Abdominal',NULL),(68,'Pain, Arm',NULL),(69,'Pain, Bone',NULL),(70,'Pain, Breast',NULL),(71,'Pain, Costrochondral',NULL),(72,'Pain, Ear',NULL),(73,'Pain, Eye',NULL),(74,'Pain, Foot',NULL),(75,'Pain, Generalized',NULL),(76,'Pain, Joint',NULL),(77,'Pain, Knee',NULL),(78,'Pain, Leg',NULL),(79,'Pain, Muscle',NULL),(80,'Parasitic Infection',NULL),(81,'Pelvic Inflammatory Disease',NULL),(82,'Pharyngitis, Bacterial',NULL),(83,'Pharyngitis, Viral',NULL),(84,'Phimosis',NULL),(85,'Pneumonia',NULL),(86,'Pregnancy',NULL),(87,'Prostitis',NULL),(88,'Psoriasis',NULL),(89,'Pylonephritis',NULL),(90,'Scabies',NULL),(91,'Sebhorragic Dermatitis',NULL),(92,'Seizure Disorder',NULL),(93,'Shortness of Breath',NULL),(94,'Angina Pectoris, Stable',NULL),(95,'Angina Pectoris, Unstable',NULL),(96,'Sinusitis',NULL),(97,'Sty',NULL),(98,'Syphilis',NULL),(99,'Thelarche',NULL),(100,'Tinea Capitis',NULL),(101,'Tinea Corporis',NULL),(102,'Tinea Cruris',NULL),(103,'Tinea Legionella',NULL),(104,'Tinea Versicolor',NULL),(105,'Urinary Tract Infection',NULL),(106,'Uterine Fibroids',NULL),(107,'Uterine Prolapse',NULL),(108,'Candiasis, Vaginal',NULL),(109,'Candiasis, Oral',NULL),(110,'Candiasis, Cutaneous',NULL);
/*!40000 ALTER TABLE `concept_diagnoses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_medication_concept_generic_strengths`
--

DROP TABLE IF EXISTS `concept_medication_concept_generic_strengths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_medication_concept_generic_strengths` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `concept_medication_id` int NOT NULL,
  `concept_medication_generic_strength_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `fk_concept_medication_concept_generic_strengths_idx` (`concept_medication_generic_strength_id`),
  KEY `fk_concept_generic_strengths_concept_medications_idx` (`concept_medication_id`),
  CONSTRAINT `fk_concept_generic_strengths_concept_medications` FOREIGN KEY (`concept_medication_id`) REFERENCES `concept_medications` (`id`),
  CONSTRAINT `fk_concept_medication_concept_generic_strengths` FOREIGN KEY (`concept_medication_generic_strength_id`) REFERENCES `concept_medication_generic_strengths` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_medication_concept_generic_strengths`
--

LOCK TABLES `concept_medication_concept_generic_strengths` WRITE;
/*!40000 ALTER TABLE `concept_medication_concept_generic_strengths` DISABLE KEYS */;
INSERT INTO `concept_medication_concept_generic_strengths` VALUES (1,1,2),(2,2,3),(3,3,5),(4,4,6),(5,5,7),(6,6,8),(7,7,9),(8,8,10),(9,9,12),(10,10,13),(11,11,14),(12,12,15),(13,13,16),(14,14,17),(15,15,19),(16,16,20),(17,17,21),(18,18,22),(19,19,23),(20,20,25),(21,21,26),(22,22,27),(23,23,28),(24,24,29),(25,25,30),(26,26,32),(27,27,33),(28,28,36),(29,29,38),(30,30,39),(31,31,41),(32,32,42),(33,33,43),(34,34,45),(35,35,46),(36,36,48),(37,37,49),(38,38,50),(39,39,51),(40,40,52),(41,41,53),(42,42,54),(43,43,55),(44,44,56),(45,45,57),(46,46,59),(47,47,60),(48,48,61),(49,49,63),(50,50,65),(51,51,66),(52,52,67),(53,53,68),(54,54,69),(55,55,72),(56,56,74),(57,57,75),(58,58,76),(59,59,77),(60,60,78),(61,61,79),(62,62,80),(63,63,81),(64,64,82),(65,65,83),(66,66,84),(67,67,85),(68,68,86),(69,69,87),(70,70,89),(71,71,90),(72,72,91),(73,73,95),(74,74,96),(75,75,99),(76,76,103),(77,77,104),(78,78,44),(79,78,102),(80,79,70),(81,79,102),(82,80,1),(83,80,102),(84,81,64),(85,81,102),(86,82,10),(87,82,102),(88,83,11),(89,83,40),(90,83,102),(91,84,14),(92,84,102),(93,85,18),(94,85,102),(95,86,31),(96,86,102),(97,87,37),(98,87,102),(99,88,94),(100,88,97),(101,89,93),(102,89,98),(103,90,47),(104,90,92),(105,91,71),(106,91,73),(107,92,34),(108,92,101),(109,93,58),(110,93,102),(111,94,4),(112,94,61),(113,94,100),(114,95,35),(115,95,102),(116,96,88),(117,96,102);
/*!40000 ALTER TABLE `concept_medication_concept_generic_strengths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_medication_forms`
--

DROP TABLE IF EXISTS `concept_medication_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_medication_forms` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` varchar(45) DEFAULT NULL,
  `isDeleted` bit(1) DEFAULT b'0',
  `language_code` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `form_name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_medication_forms`
--

LOCK TABLES `concept_medication_forms` WRITE;
/*!40000 ALTER TABLE `concept_medication_forms` DISABLE KEYS */;
INSERT INTO `concept_medication_forms` VALUES (1,'B/S','bite and swallow','\0',NULL),(2,'caps','capsules','\0',NULL),(3,'crm','cream','\0',NULL),(4,'elix','elixir','\0',NULL),(5,'gtts','drops','\0',NULL),(6,'MDI','metered dose inhaler','\0',NULL),(7,'nebs','solution for nebulization','\0',NULL),(8,'NPO','nothing by mouth','\0',NULL),(9,'PO','by mouth, orally , or swallowed','\0',NULL),(10,'PR','suppository','\0',NULL),(11,'SL','sublingual form','\0',NULL),(12,'soln','solution','\0',NULL),(13,'supp','suppository','\0',NULL),(14,'susp','suspension','\0',NULL),(15,'syr','syrup','\0',NULL),(16,'tabs','tablets','\0',NULL),(17,'tab chew','Chewable Tablets','\0',NULL),(18,'ung','ointment','\0',NULL),(19,'lotion','lotion','\0',NULL),(20,'inj','injection','\0',NULL);
/*!40000 ALTER TABLE `concept_medication_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_medication_generic_strengths`
--

DROP TABLE IF EXISTS `concept_medication_generic_strengths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_medication_generic_strengths` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `concept_medication_unit_id` int unsigned NOT NULL,
  `concept_medication_generic_id` int NOT NULL,
  `isDenominator` bit(1) NOT NULL DEFAULT b'0',
  `value` decimal(10,4) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `fk_concept_generic_strengths_concept_units_idx` (`concept_medication_unit_id`),
  KEY `fk_concept_generic_strengths_concept_generics_idx` (`concept_medication_generic_id`),
  CONSTRAINT `fk_concept_generic_strengths_concept_generics` FOREIGN KEY (`concept_medication_generic_id`) REFERENCES `concept_medication_generics` (`id`),
  CONSTRAINT `fk_concept_generic_strengths_concept_units` FOREIGN KEY (`concept_medication_unit_id`) REFERENCES `concept_medication_units` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_medication_generic_strengths`
--

LOCK TABLES `concept_medication_generic_strengths` WRITE;
/*!40000 ALTER TABLE `concept_medication_generic_strengths` DISABLE KEYS */;
INSERT INTO `concept_medication_generic_strengths` VALUES (1,5,1,'\0',160.0000),(2,5,1,'\0',325.0000),(3,5,1,'\0',500.0000),(4,1,2,'\0',2.0000),(5,5,3,'\0',200.0000),(6,5,3,'\0',400.0000),(7,1,4,'\0',0.0830),(8,9,4,'\0',90.0000),(9,5,5,'\0',5.0000),(10,5,6,'\0',125.0000),(11,5,6,'\0',200.0000),(12,5,6,'\0',250.0000),(13,5,6,'\0',500.0000),(14,5,7,'\0',250.0000),(15,5,8,'\0',325.0000),(16,5,8,'\0',81.0000),(17,5,9,'\0',50.0000),(18,5,10,'\0',200.0000),(19,5,10,'\0',250.0000),(20,5,10,'\0',500.0000),(21,2,11,'\0',0.9000),(22,2,11,'\0',28.0000),(23,5,12,'\0',9.0000),(24,5,13,'\0',5.0000),(25,5,14,'\0',262.0000),(26,9,15,'\0',180.0000),(27,1,16,'\0',8.0000),(28,5,17,'\0',1000.0000),(29,5,17,'\0',500.0000),(30,5,17,'\0',750.0000),(31,5,18,'\0',125.0000),(32,5,19,'\0',250.0000),(33,2,20,'\0',1.0000),(34,2,20,'\0',10.0000),(35,5,21,'\0',125.0000),(36,5,21,'\0',500.0000),(37,5,22,'\0',250.0000),(38,5,22,'\0',300.0000),(39,5,22,'\0',500.0000),(40,5,23,'\0',28.5000),(41,1,24,'\0',1.0000),(42,5,25,'\0',180.0000),(43,5,25,'\0',240.0000),(44,5,26,'\0',12.5000),(45,5,26,'\0',25.0000),(46,5,27,'\0',100.0000),(47,5,27,'\0',50.0000),(48,5,28,'\0',100.0000),(49,5,28,'\0',150.0000),(50,5,28,'\0',75.0000),(51,5,29,'\0',85.0000),(52,7,30,'\0',16.0000),(53,5,31,'\0',20.0000),(54,5,32,'\0',100.0000),(55,5,33,'\0',1.0000),(56,5,34,'\0',10.0000),(57,1,35,'\0',50.0000),(58,5,36,'\0',100.0000),(59,5,36,'\0',200.0000),(60,5,36,'\0',400.0000),(61,1,37,'\0',1.0000),(62,1,37,'\0',1.0000),(63,5,38,'\0',200.0000),(64,5,39,'\0',100.0000),(65,5,39,'\0',200.0000),(66,5,40,'\0',6.0000),(67,5,41,'\0',500.0000),(68,5,42,'\0',2.0000),(69,5,43,'\0',10.0000),(70,5,43,'\0',5.0000),(71,1,44,'\0',10.0000),(72,5,45,'\0',500.0000),(73,1,46,'\0',15.0000),(74,5,47,'\0',5.0000),(75,5,48,'\0',50.0000),(76,5,49,'\0',250.0000),(77,5,49,'\0',500.0000),(78,5,50,'\0',4.0000),(79,5,50,'\0',5.0000),(80,5,51,'\0',220.0000),(81,5,51,'\0',500.0000),(82,5,52,'\0',100.0000),(83,5,53,'\0',20.0000),(84,5,54,'\0',4.0000),(85,5,54,'\0',8.0000),(86,1,55,'\0',1.0000),(87,1,55,'\0',5.0000),(88,5,56,'\0',15.0000),(89,5,57,'\0',10.0000),(90,5,58,'\0',50.0000),(91,5,59,'\0',150.0000),(92,5,60,'\0',8.6000),(93,5,61,'\0',160.0000),(94,5,61,'\0',80.0000),(95,5,62,'\0',2.0000),(96,5,63,'\0',250.0000),(97,5,64,'\0',400.0000),(98,5,64,'\0',800.0000),(99,2,65,'\0',1.0000),(100,8,66,'',10.0000),(101,8,66,'',100.0000),(102,8,66,'',5.0000),(103,5,67,'\0',20.0000),(104,5,68,'\0',220.0000);
/*!40000 ALTER TABLE `concept_medication_generic_strengths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_medication_generics`
--

DROP TABLE IF EXISTS `concept_medication_generics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_medication_generics` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_medication_generics`
--

LOCK TABLES `concept_medication_generics` WRITE;
/*!40000 ALTER TABLE `concept_medication_generics` DISABLE KEYS */;
INSERT INTO `concept_medication_generics` VALUES (66,'a liquid'),(1,'acetaminophen'),(2,'acetic acid'),(3,'albendazole'),(4,'albuterol'),(5,'amlodipine'),(6,'amoxicillin'),(7,'ampicillin'),(8,'aspirin'),(9,'atenolol'),(10,'azithromycin'),(11,'bacitracin'),(12,'bacitracin/neomycin/polymyxin b'),(13,'bisacodyl'),(14,'bismuth subsalicylate'),(15,'budesonide'),(16,'calamine'),(17,'calcium cargonate'),(18,'cefdinir'),(19,'cefprozil'),(20,'ceftriaxone'),(21,'cephalexin'),(22,'clarithromycin'),(23,'clavulanic acid'),(24,'clotrimazole'),(25,'diltiazem'),(26,'diphenhydramine'),(27,'docusate'),(28,'doxycycline'),(29,'econazole'),(30,'electrolytes'),(31,'famotidine'),(32,'fluconazole'),(33,'folic acid'),(34,'glipizide'),(35,'glycerin'),(36,'guaifenesin'),(37,'hydrocortisone'),(38,'hydroxychloroquine'),(39,'ibuprofen'),(40,'ivermectin'),(41,'levofloxacin'),(42,'loperamide'),(43,'loratadine'),(44,'menthol'),(45,'metformin'),(46,'methylsalicylate'),(47,'metoclopramide'),(48,'metoprolol'),(49,'metronidazole'),(50,'montelukast'),(51,'naproxen'),(52,'nitrofurantoin'),(53,'omeprazole'),(54,'ondansetron'),(55,'permethrin'),(56,'prednisolone'),(57,'prednisone'),(58,'promethazine'),(59,'ranitidine'),(60,'sennosides'),(61,'sulfamethoxazole'),(62,'terazosin'),(63,'terbinafine'),(64,'trimethoprim'),(65,'valacyclovir'),(67,'zafirlukast'),(68,'zinc');
/*!40000 ALTER TABLE `concept_medication_generics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_medication_units`
--

DROP TABLE IF EXISTS `concept_medication_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_medication_units` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` varchar(45) DEFAULT NULL,
  `isDeleted` bit(1) DEFAULT b'0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `unit_name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_medication_units`
--

LOCK TABLES `concept_medication_units` WRITE;
/*!40000 ALTER TABLE `concept_medication_units` DISABLE KEYS */;
INSERT INTO `concept_medication_units` VALUES (1,'%','g/dL','\0'),(2,'g','gram','\0'),(3,'gr','grain','\0'),(4,'IU','international units','\0'),(5,'mg','milligram','\0'),(6,'U','unit','\0'),(7,'oz','ounces','\0'),(8,'mL','milliliter','\0'),(9,'mcg','microgram','\0');
/*!40000 ALTER TABLE `concept_medication_units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_medications`
--

DROP TABLE IF EXISTS `concept_medications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_medications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `isDeleted` bit(1) DEFAULT b'0',
  `concept_medication_form_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `fk_concept_medications_concept_medication_forms_idx` (`concept_medication_form_id`),
  CONSTRAINT `fk_concept_medications_concept_medication_forms` FOREIGN KEY (`concept_medication_form_id`) REFERENCES `concept_medication_forms` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_medications`
--

LOCK TABLES `concept_medications` WRITE;
/*!40000 ALTER TABLE `concept_medications` DISABLE KEYS */;
INSERT INTO `concept_medications` VALUES (1,'Tylenol','\0',16),(2,'Tylenol','\0',16),(3,'Albenza','\0',2),(4,'Albenza','\0',2),(5,'Proventil','\0',7),(6,'Proventil','\0',6),(7,'Norvasc','\0',2),(8,'Amoxil','\0',2),(9,'Amoxil','\0',2),(10,'Amoxil','\0',2),(11,'Principen','\0',2),(12,'Bayer','\0',16),(13,'Bayer','\0',16),(14,'Tenormin','\0',16),(15,'Zithromax','\0',2),(16,'Zithromax','\0',2),(17,'Bacitracin','\0',18),(18,'Bacitracin','\0',18),(19,'Triple Antibiotic','\0',18),(20,'Pepto Bismol','\0',17),(21,'Pulmicort','\0',6),(22,'Calamine','\0',19),(23,'Tums','\0',17),(24,'Tums','\0',17),(25,'Tums','\0',17),(26,'Cefzil','\0',16),(27,'Rocephin','\0',20),(28,'Keflex','\0',2),(29,'Biaxin','\0',16),(30,'Biaxin','\0',16),(31,'Lotrimin','\0',3),(32,'Tiazac','\0',2),(33,'Tiazac','\0',2),(34,'Benadryl','\0',16),(35,'Colace','\0',16),(36,'Vibramycin','\0',2),(37,'Adoxa','\0',2),(38,'Vibramycin','\0',2),(39,'Spectazole','\0',3),(40,'Pedialyte','\0',12),(41,'Pepcid','\0',16),(42,'Diflucan','\0',16),(43,'Folvite','\0',16),(44,'Glucotrol','\0',16),(45,'Sani-Supp','\0',10),(46,'Mucinex','\0',16),(47,'Mucinex','\0',16),(48,'Cortaid','\0',3),(49,'Plaquenil','\0',16),(50,'Advil','\0',16),(51,'Stromectol','\0',16),(52,'Levaquin','\0',16),(53,'Imodium','\0',16),(54,'Claritin','\0',16),(55,'Glucophage','\0',16),(56,'Metozolv ODT','\0',16),(57,'Lopressor','\0',16),(58,'Flagyl','\0',16),(59,'Flagyl','\0',16),(60,'Singulair','\0',16),(61,'Singulair','\0',16),(62,'Aleve','\0',16),(63,'Aleve','\0',16),(64,'Furadantin','\0',2),(65,'Zegerid','\0',2),(66,'Zofran','\0',16),(67,'Zofran','\0',16),(68,'Elimite','\0',3),(69,'Acticin','\0',3),(70,'Rayos','\0',16),(71,'Phenergan','\0',16),(72,'Zantac','\0',16),(73,'Hytrin','\0',2),(74,'Lamisil','\0',16),(75,'Valtrex','\0',16),(76,'Accolate','\0',16),(77,'Zincfant','\0',16),(78,'Benadryl','\0',14),(79,'Claritin','\0',14),(80,'Tylenol','\0',14),(81,'Advil','\0',14),(82,'Amoxil','\0',14),(83,'Augmentin','\0',14),(84,'Principen','\0',14),(85,'Zithromax','\0',14),(86,'Omnicef','\0',14),(87,'Biaxin','\0',14),(88,'Bactrim','\0',16),(89,'Bactrim','\0',16),(90,'Senokot','\0',16),(91,'Bengay','\0',3),(92,'Rocephin','\0',20),(93,'Mucinex','\0',14),(94,'Vosol HC','\0',14),(95,'Keflex','\0',14),(96,'Prednisolone','\0',20);
/*!40000 ALTER TABLE `concept_medications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_prescription_administrations`
--

DROP TABLE IF EXISTS `concept_prescription_administrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_prescription_administrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `daily_modifier` decimal(9,6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_prescription_administrations`
--

LOCK TABLES `concept_prescription_administrations` WRITE;
/*!40000 ALTER TABLE `concept_prescription_administrations` DISABLE KEYS */;
INSERT INTO `concept_prescription_administrations` VALUES (1,'alt',0.500000),(2,'BID',2.000000),(3,'BIW',0.285700),(4,'CID',5.000000),(5,'HS',1.000000),(6,'q12h',2.000000),(7,'q24h',1.000000),(8,'q4-6h',5.000000),(9,'q4h',6.000000),(10,'q6h',4.000000),(11,'q8h',3.000000),(12,'qAM',1.000000),(13,'qd',1.000000),(14,'qHS',1.000000),(15,'QID',4.000000),(16,'q5min',288.000000),(17,'qOd',0.500000),(18,'qPM',1.000000),(19,'q week',0.142857),(20,'TID',3.000000),(21,'TIW',0.428570);
/*!40000 ALTER TABLE `concept_prescription_administrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `database_status`
--

DROP TABLE IF EXISTS `database_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `database_status` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `val` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `database_status`
--

LOCK TABLES `database_status` WRITE;
/*!40000 ALTER TABLE `database_status` DISABLE KEYS */;
INSERT INTO `database_status` VALUES (1,'Last Backup','2021.02.17');
/*!40000 ALTER TABLE `database_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `feedback` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `feedback` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

LOCK TABLES `feedback` WRITE;
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
INSERT INTO `feedback` VALUES (1,'2025-11-05','hhhh');
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `internet_status`
--

DROP TABLE IF EXISTS `internet_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `internet_status` (
  `id` int NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `internet_status`
--

LOCK TABLES `internet_status` WRITE;
/*!40000 ALTER TABLE `internet_status` DISABLE KEYS */;
INSERT INTO `internet_status` VALUES (0,0);
/*!40000 ALTER TABLE `internet_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kit_status`
--

DROP TABLE IF EXISTS `kit_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `kit_status` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `val` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kit_status`
--

LOCK TABLES `kit_status` WRITE;
/*!40000 ALTER TABLE `kit_status` DISABLE KEYS */;
INSERT INTO `kit_status` VALUES (1,'Status','Currently Online'),(2,'Version','Unknown Version'),(3,'Last Update','Unknown Build Date'),(4,'Type','Docker Container');
/*!40000 ALTER TABLE `kit_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `language_codes`
--

DROP TABLE IF EXISTS `language_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `language_codes` (
  `code` varchar(5) NOT NULL,
  `language_name` varchar(64) NOT NULL,
  `status` varchar(64) NOT NULL,
  `updateScheduled` tinyint(1) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language_codes`
--

LOCK TABLES `language_codes` WRITE;
/*!40000 ALTER TABLE `language_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `language_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_attempts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `ip_address` binary(16) NOT NULL,
  `date_of_attempt` datetime NOT NULL,
  `isSuccessful` bit(1) NOT NULL,
  `username_attempt` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `login_attempts_user_id_users_id_idx` (`user_id`),
  CONSTRAINT `login_attempts_user_id_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_attempts`
--

LOCK TABLES `login_attempts` WRITE;
/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
INSERT INTO `login_attempts` VALUES (1,1,'�\0\0\0\0\0\0\0\0\0\0\0','2025-11-05 00:15:38','','admin'),(2,3,'�\0\0\0\0\0\0\0\0\0\0\0','2025-11-05 00:16:53','','testnurse'),(3,1,'�\0\0\0\0\0\0\0\0\0\0\0','2025-11-05 00:18:29','','admin'),(4,4,'�\0\0\0\0\0\0\0\0\0\0\0','2025-11-05 00:19:24','\0','test@email.com'),(5,4,'�\0\0\0\0\0\0\0\0\0\0\0','2025-11-05 00:19:28','','test@email.com'),(6,1,'�\0\0\0\0\0\0\0\0\0\0\0','2025-11-05 00:26:31','','admin'),(7,4,'�\0\0\0\0\0\0\0\0\0\0\0','2025-11-05 00:27:35','','test@email.com'),(8,3,'�\0\0\0\0\0\0\0\0\0\0\0','2025-11-06 23:50:17','','testnurse'),(9,4,'�\0\0\0\0\0\0\0\0\0\0\0','2025-11-07 00:17:12','','test@email.com'),(10,4,'�\0\0\0\0\0\0\0\0\0\0\0','2025-12-02 23:30:28','','test@email.com'),(11,1,'�\0\0\0\0\0\0\0\0\0\0\0','2025-12-04 20:09:43','','admin'),(12,4,'�\0\0\0\0\0\0\0\0\0\0\0','2025-12-04 20:09:50','','test@email.com'),(13,4,'�\0\0\0\0\0\0\0\0\0\0\0','2025-12-04 21:16:15','','test@email.com'),(14,4,'�\0\0\0\0\0\0\0\0\0\0\0','2025-12-04 21:58:52','','test@email.com'),(15,4,'�\0\0\0\0\0\0\0\0\0\0\0','2025-12-04 23:08:30','','test@email.com'),(16,4,'�\0\0\0\0\0\0\0\0\0\0\0','2025-12-08 03:20:49','','test@email.com'),(17,1,'�\0\0\0\0\0\0\0\0\0\0\0','2025-12-12 00:21:28','','admin'),(18,1,'�\0\0\0\0\0\0\0\0\0\0\0','2026-01-06 20:32:43','','admin'),(19,4,'�\0\0\0\0\0\0\0\0\0\0\0','2026-01-06 20:32:54','','test@email.com'),(20,4,'�\0\0\0\0\0\0\0\0\0\0\0','2026-01-08 20:24:28','','test@email.com'),(21,1,'�\0\0\0\0\0\0\0\0\0\0\0','2026-01-13 21:22:07','','admin'),(22,4,'�\0\0\0\0\0\0\0\0\0\0\0','2026-01-13 21:22:20','','test@email.com'),(23,1,'�\0\0\0\0\0\0\0\0\0\0\0','2026-01-22 21:31:12','','admin'),(24,1,'�\0\0\0\0\0\0\0\0\0\0\0','2026-01-22 21:31:12','','admin'),(25,4,'�\0\0\0\0\0\0\0\0\0\0\0','2026-01-22 21:31:19','','test@email.com'),(26,4,'�\0\0\0\0\0\0\0\0\0\0\0','2026-01-27 20:31:18','','test@email.com'),(27,4,'�\0\0\0\0\0\0\0\0\0\0\0\0\0','2026-02-01 00:18:53','','test@email.com'),(28,1,'�\0\0\0\0\0\0\0\0\0\0\0\0\0','2026-02-17 21:57:34','','admin'),(29,4,'�\0\0\0\0\0\0\0\0\0\0\0\0\0','2026-02-17 21:57:43','','test@email.com'),(30,1,'�\0\0\0\0\0\0\0\0\0\0\0\0\0','2026-02-19 20:33:02','','admin'),(31,NULL,'�\0\0\0\0\0\0\0\0\0\0\0\0\0','2026-02-19 20:33:10','\0','nurse'),(32,4,'�\0\0\0\0\0\0\0\0\0\0\0\0\0','2026-02-19 20:33:16','','test@email.com'),(33,4,'�\0\0\0\0\0\0\0\0\0\0\0\0\0','2026-02-19 21:15:00','','test@email.com'),(34,4,'�\0\0\0\0\0\0\0\0\0\0\0\0\0','2026-02-24 20:38:58','','test@email.com'),(35,1,'�\0\0\0\0\0\0\0\0\0\0\0\0\0','2026-03-17 16:13:28','','admin'),(36,4,'�\0\0\0\0\0\0\0\0\0\0\0\0\0','2026-03-17 16:14:59','\0','test@email.com'),(37,4,'�\0\0\0\0\0\0\0\0\0\0\0\0\0','2026-03-17 16:15:57','','test@email.com'),(38,4,'�\0\0\0\0\0\0\0\0\0\0\0\0\0','2026-03-17 16:25:22','','test@email.com'),(39,4,'�\0\0\0\0\0\0\0\0\0\0\0\0\0','2026-04-02 20:00:18','','test@email.com'),(40,4,'�\0\0\0\0\0\0\0\0\0\0\0\0\0','2026-04-07 20:10:37','','test@email.com');
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `measurement_categories`
--

DROP TABLE IF EXISTS `measurement_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `measurement_categories` (
  `category` varchar(16) NOT NULL,
  PRIMARY KEY (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `measurement_categories`
--

LOCK TABLES `measurement_categories` WRITE;
/*!40000 ALTER TABLE `measurement_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `measurement_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `measurement_units`
--

DROP TABLE IF EXISTS `measurement_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `measurement_units` (
  `id` int NOT NULL,
  `unit` varchar(16) NOT NULL,
  `category` varchar(16) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category` (`category`),
  CONSTRAINT `measurement_units_ibfk_1` FOREIGN KEY (`category`) REFERENCES `measurement_categories` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `measurement_units`
--

LOCK TABLES `measurement_units` WRITE;
/*!40000 ALTER TABLE `measurement_units` DISABLE KEYS */;
/*!40000 ALTER TABLE `measurement_units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medication_generic_strengths`
--

DROP TABLE IF EXISTS `medication_generic_strengths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `medication_generic_strengths` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `concept_medication_units_id` int unsigned NOT NULL,
  `medication_generics_id` int unsigned NOT NULL,
  `isDenominator` bit(1) NOT NULL,
  `value` decimal(10,4) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `fk_medication_active_drugs_medication_measurement_units_idx` (`concept_medication_units_id`),
  KEY `fk_medication_active_drugs_medication_active_drug_names_idx` (`medication_generics_id`),
  CONSTRAINT `fk_medication_active_drugs_concept_medication_units` FOREIGN KEY (`concept_medication_units_id`) REFERENCES `concept_medication_units` (`id`),
  CONSTRAINT `fk_medication_active_drugs_medication_generics` FOREIGN KEY (`medication_generics_id`) REFERENCES `medication_generics` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medication_generic_strengths`
--

LOCK TABLES `medication_generic_strengths` WRITE;
/*!40000 ALTER TABLE `medication_generic_strengths` DISABLE KEYS */;
/*!40000 ALTER TABLE `medication_generic_strengths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medication_generics`
--

DROP TABLE IF EXISTS `medication_generics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `medication_generics` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medication_generics`
--

LOCK TABLES `medication_generics` WRITE;
/*!40000 ALTER TABLE `medication_generics` DISABLE KEYS */;
/*!40000 ALTER TABLE `medication_generics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medication_inventories`
--

DROP TABLE IF EXISTS `medication_inventories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `medication_inventories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `quantity_current` int NOT NULL,
  `quantity_initial` int NOT NULL,
  `mission_trip_id` int NOT NULL,
  `medication_id` int NOT NULL,
  `isDeleted` datetime DEFAULT NULL,
  `timeAdded` datetime DEFAULT NULL,
  `createdBy` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_medication_inventory_mission_trips_id_idx` (`mission_trip_id`),
  KEY `fk_medication_inventory_medications_id_idx` (`medication_id`),
  KEY `fk_created_by_user_id_user_id` (`createdBy`),
  CONSTRAINT `fk_created_by_user_id_user_id` FOREIGN KEY (`createdBy`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_medication_inventory_medications_id` FOREIGN KEY (`medication_id`) REFERENCES `medications` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_medication_inventory_mission_trips_id` FOREIGN KEY (`mission_trip_id`) REFERENCES `mission_trips` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medication_inventories`
--

LOCK TABLES `medication_inventories` WRITE;
/*!40000 ALTER TABLE `medication_inventories` DISABLE KEYS */;
/*!40000 ALTER TABLE `medication_inventories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medication_medication_generic_strengths`
--

DROP TABLE IF EXISTS `medication_medication_generic_strengths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `medication_medication_generic_strengths` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `medications_id` int NOT NULL,
  `medication_generic_strength_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `fk_medication_medication_active_drugs_medication_active_dru_idx` (`medication_generic_strength_id`),
  KEY `fk_medication_medication_active_drugs_medications_idx` (`medications_id`),
  CONSTRAINT `fk_medication_medication_generic_strengths` FOREIGN KEY (`medication_generic_strength_id`) REFERENCES `medication_generic_strengths` (`id`),
  CONSTRAINT `fk_medication_medication_generic_strengths_medications` FOREIGN KEY (`medications_id`) REFERENCES `medications` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medication_medication_generic_strengths`
--

LOCK TABLES `medication_medication_generic_strengths` WRITE;
/*!40000 ALTER TABLE `medication_medication_generic_strengths` DISABLE KEYS */;
/*!40000 ALTER TABLE `medication_medication_generic_strengths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medications`
--

DROP TABLE IF EXISTS `medications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `medications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `isDeleted` bit(1) DEFAULT b'0',
  `concept_medication_forms_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `fk_medications_medication_forms_idx` (`concept_medication_forms_id`),
  CONSTRAINT `fk_medications_concept_medication_forms` FOREIGN KEY (`concept_medication_forms_id`) REFERENCES `concept_medication_forms` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medications`
--

LOCK TABLES `medications` WRITE;
/*!40000 ALTER TABLE `medications` DISABLE KEYS */;
/*!40000 ALTER TABLE `medications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mission_cities`
--

DROP TABLE IF EXISTS `mission_cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mission_cities` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `mission_country_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `fk_mission_cities_1_idx` (`mission_country_id`),
  CONSTRAINT `fk_mission_cities_1` FOREIGN KEY (`mission_country_id`) REFERENCES `mission_countries` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mission_cities`
--

LOCK TABLES `mission_cities` WRITE;
/*!40000 ALTER TABLE `mission_cities` DISABLE KEYS */;
INSERT INTO `mission_cities` VALUES (1,'Morne De L\' Hopital',72),(2,'Port-au-Prince',72);
/*!40000 ALTER TABLE `mission_cities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mission_countries`
--

DROP TABLE IF EXISTS `mission_countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mission_countries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=197 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mission_countries`
--

LOCK TABLES `mission_countries` WRITE;
/*!40000 ALTER TABLE `mission_countries` DISABLE KEYS */;
INSERT INTO `mission_countries` VALUES (1,'Afghanistan'),(2,'Albania'),(3,'Algeria'),(4,'Andorra'),(5,'Angola'),(6,'Antigua & Deps'),(7,'Argentina'),(8,'Armenia'),(9,'Australia'),(10,'Austria'),(11,'Azerbaijan'),(12,'Bahamas'),(13,'Bahrain'),(14,'Bangladesh'),(15,'Barbados'),(16,'Belarus'),(17,'Belgium'),(18,'Belize'),(19,'Benin'),(20,'Bhutan'),(21,'Bolivia'),(22,'Bosnia Herzegovina'),(23,'Botswana'),(24,'Brazil'),(25,'Brunei'),(26,'Bulgaria'),(27,'Burkina'),(28,'Burundi'),(29,'Cambodia'),(30,'Cameroon'),(31,'Canada'),(32,'Cape Verde'),(33,'Central African Rep'),(34,'Chad'),(35,'Chile'),(36,'China'),(37,'Colombia'),(38,'Comoros'),(39,'Congo'),(40,'Congo {Democratic Rep}'),(41,'Costa Rica'),(42,'Croatia'),(43,'Cuba'),(44,'Cyprus'),(45,'Czech Republic'),(46,'Denmark'),(47,'Djibouti'),(48,'Dominica'),(49,'Dominican Republic'),(50,'East Timor'),(51,'Ecuador'),(52,'Egypt'),(53,'El Salvador'),(54,'Equatorial Guinea'),(55,'Eritrea'),(56,'Estonia'),(57,'Ethiopia'),(58,'Fiji'),(59,'Finland'),(60,'France'),(61,'Gabon'),(62,'Gambia'),(63,'Georgia'),(64,'Germany'),(65,'Ghana'),(66,'Greece'),(67,'Grenada'),(68,'Guatemala'),(69,'Guinea'),(70,'Guinea-Bissau'),(71,'Guyana'),(72,'Haiti'),(73,'Honduras'),(74,'Hungary'),(75,'Iceland'),(76,'India'),(77,'Indonesia'),(78,'Iran'),(79,'Iraq'),(80,'Ireland {Republic}'),(81,'Israel'),(82,'Italy'),(83,'Ivory Coast'),(84,'Jamaica'),(85,'Japan'),(86,'Jordan'),(87,'Kazakhstan'),(88,'Kenya'),(89,'Kiribati'),(90,'Korea North'),(91,'Korea South'),(92,'Kosovo'),(93,'Kuwait'),(94,'Kyrgyzstan'),(95,'Laos'),(96,'Latvia'),(97,'Lebanon'),(98,'Lesotho'),(99,'Liberia'),(100,'Libya'),(101,'Liechtenstein'),(102,'Lithuania'),(103,'Luxembourg'),(104,'Macedonia'),(105,'Madagascar'),(106,'Malawi'),(107,'Malaysia'),(108,'Maldives'),(109,'Mali'),(110,'Malta'),(111,'Marshall Islands'),(112,'Mauritania'),(113,'Mauritius'),(114,'Mexico'),(115,'Micronesia'),(116,'Moldova'),(117,'Monaco'),(118,'Mongolia'),(119,'Montenegro'),(120,'Morocco'),(121,'Mozambique'),(122,'Myanmar, {Burma}'),(123,'Namibia'),(124,'Nauru'),(125,'Nepal'),(126,'Netherlands'),(127,'New Zealand'),(128,'Nicaragua'),(129,'Niger'),(130,'Nigeria'),(131,'Norway'),(132,'Oman'),(133,'Pakistan'),(134,'Palau'),(135,'Panama'),(136,'Papua New Guinea'),(137,'Paraguay'),(138,'Peru'),(139,'Philippines'),(140,'Poland'),(141,'Portugal'),(142,'Qatar'),(143,'Romania'),(144,'Russian Federation'),(145,'Rwanda'),(146,'St Kitts & Nevis'),(147,'St Lucia'),(148,'Saint Vincent & the Grenadines'),(149,'Samoa'),(150,'San Marino'),(151,'Sao Tome & Principe'),(152,'Saudi Arabia'),(153,'Senegal'),(154,'Serbia'),(155,'Seychelles'),(156,'Sierra Leone'),(157,'Singapore'),(158,'Slovakia'),(159,'Slovenia'),(160,'Solomon Islands'),(161,'Somalia'),(162,'South Africa'),(163,'South Sudan'),(164,'Spain'),(165,'Sri Lanka'),(166,'Sudan'),(167,'Suriname'),(168,'Swaziland'),(169,'Sweden'),(170,'Switzerland'),(171,'Syria'),(172,'Taiwan'),(173,'Tajikistan'),(174,'Tanzania'),(175,'Thailand'),(176,'Togo'),(177,'Tonga'),(178,'Trinidad & Tobago'),(179,'Tunisia'),(180,'Turkey'),(181,'Turkmenistan'),(182,'Tuvalu'),(183,'Uganda'),(184,'Ukraine'),(185,'United Arab Emirates'),(186,'United Kingdom'),(187,'USA'),(188,'Uruguay'),(189,'Uzbekistan'),(190,'Vanuatu'),(191,'Vatican City'),(192,'Venezuela'),(193,'Vietnam'),(194,'Yemen'),(195,'Zambia'),(196,'Zimbabwe');
/*!40000 ALTER TABLE `mission_countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mission_teams`
--

DROP TABLE IF EXISTS `mission_teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mission_teams` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `language_code` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mission_teams`
--

LOCK TABLES `mission_teams` WRITE;
/*!40000 ALTER TABLE `mission_teams` DISABLE KEYS */;
INSERT INTO `mission_teams` VALUES (1,'Aid for Haiti','Dr. Sutherland\'s group','Tennessee',NULL),(2,'WSU-WHSO','Wayne State medical students','Detroit',NULL),(3,'ApParent Project','Dr. Parson\'s group - primarily operates in Port Au Prince','New York',NULL);
/*!40000 ALTER TABLE `mission_teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mission_trip_users`
--

DROP TABLE IF EXISTS `mission_trip_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mission_trip_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mission_trip_id` int NOT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `fk_mission_trip_users_user_id_users_id_idx` (`user_id`),
  KEY `fk_mission_trip_users_mission_trip_id_mission_trips_id_idx` (`mission_trip_id`),
  CONSTRAINT `fk_mission_trip_users_mission_trip_id_mission_trips_id` FOREIGN KEY (`mission_trip_id`) REFERENCES `mission_trips` (`id`) ON UPDATE RESTRICT,
  CONSTRAINT `fk_mission_trip_users_user_id_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mission_trip_users`
--

LOCK TABLES `mission_trip_users` WRITE;
/*!40000 ALTER TABLE `mission_trip_users` DISABLE KEYS */;
INSERT INTO `mission_trip_users` VALUES (1,2,4),(2,1,3);
/*!40000 ALTER TABLE `mission_trip_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mission_trips`
--

DROP TABLE IF EXISTS `mission_trips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mission_trips` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mission_team_id` int NOT NULL,
  `mission_city_id` int NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `fk_mission_trips_mission_team_idx` (`mission_team_id`),
  KEY `fk_mission_trips_mission_city_idx` (`mission_city_id`),
  CONSTRAINT `fk_mission_trips_mission_city` FOREIGN KEY (`mission_city_id`) REFERENCES `mission_cities` (`id`),
  CONSTRAINT `fk_mission_trips_mission_team` FOREIGN KEY (`mission_team_id`) REFERENCES `mission_teams` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mission_trips`
--

LOCK TABLES `mission_trips` WRITE;
/*!40000 ALTER TABLE `mission_trips` DISABLE KEYS */;
INSERT INTO `mission_trips` VALUES (1,1,2,'2025-11-04','2025-11-28'),(2,1,1,'2025-11-03','2025-11-20'),(3,1,1,'2025-12-10','2025-12-19');
/*!40000 ALTER TABLE `mission_trips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `network_status`
--

DROP TABLE IF EXISTS `network_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `network_status` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `val` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `network_status`
--

LOCK TABLES `network_status` WRITE;
/*!40000 ALTER TABLE `network_status` DISABLE KEYS */;
INSERT INTO `network_status` VALUES (1,'Status','Connection stable'),(2,'Download','42.23 mb'),(3,'Upload','9.58 mb'),(4,'Ping','21.802'),(5,'Last Available','2026.03.17');
/*!40000 ALTER TABLE `network_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_element_translations`
--

DROP TABLE IF EXISTS `page_element_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `page_element_translations` (
  `translation_id` int NOT NULL AUTO_INCREMENT,
  `element_id` int NOT NULL,
  `language_code` varchar(5) NOT NULL,
  `translation` text NOT NULL,
  PRIMARY KEY (`translation_id`),
  UNIQUE KEY `element_id_UNIQUE` (`element_id`),
  CONSTRAINT `fk_element_id` FOREIGN KEY (`element_id`) REFERENCES `page_elements` (`element_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_element_translations`
--

LOCK TABLES `page_element_translations` WRITE;
/*!40000 ALTER TABLE `page_element_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `page_element_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_elements`
--

DROP TABLE IF EXISTS `page_elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `page_elements` (
  `element_id` int NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL,
  `page_id` int NOT NULL,
  PRIMARY KEY (`element_id`),
  UNIQUE KEY `element_id_UNIQUE` (`element_id`),
  KEY `fk_page_1_idx` (`page_id`),
  CONSTRAINT `fk_page_1` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_elements`
--

LOCK TABLES `page_elements` WRITE;
/*!40000 ALTER TABLE `page_elements` DISABLE KEYS */;
/*!40000 ALTER TABLE `page_elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_age_classifications`
--

DROP TABLE IF EXISTS `patient_age_classifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_age_classifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `isDeleted` bit(1) NOT NULL DEFAULT b'0',
  `sortOrder` int NOT NULL,
  `language_code` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`),
  UNIQUE KEY `sortOrder_UNIQUE` (`sortOrder`),
  UNIQUE KEY `description_UNIQUE` (`description`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_age_classifications`
--

LOCK TABLES `patient_age_classifications` WRITE;
/*!40000 ALTER TABLE `patient_age_classifications` DISABLE KEYS */;
INSERT INTO `patient_age_classifications` VALUES (1,'infant','0-1','\0',1,NULL),(2,'child','2-12','\0',2,NULL),(3,'teen','13-17','\0',3,NULL),(4,'adult','18-64','\0',4,NULL),(5,'elder','65+','\0',5,NULL);
/*!40000 ALTER TABLE `patient_age_classifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_encounter_photos`
--

DROP TABLE IF EXISTS `patient_encounter_photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_encounter_photos` (
  `patient_encounter_id` int NOT NULL,
  `photo_id` int NOT NULL,
  PRIMARY KEY (`patient_encounter_id`,`photo_id`),
  UNIQUE KEY `id_photo_encntr_idx` (`photo_id`),
  KEY `patient_encounter_photos_pci_idx` (`patient_encounter_id`),
  CONSTRAINT `patient_encounter_photos_ibfk_1` FOREIGN KEY (`patient_encounter_id`) REFERENCES `patient_encounters` (`id`),
  CONSTRAINT `patient_encounter_photos_ibfk_2` FOREIGN KEY (`photo_id`) REFERENCES `photos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_encounter_photos`
--

LOCK TABLES `patient_encounter_photos` WRITE;
/*!40000 ALTER TABLE `patient_encounter_photos` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_encounter_photos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_encounter_tab_fields`
--

DROP TABLE IF EXISTS `patient_encounter_tab_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_encounter_tab_fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `patient_encounter_id` int NOT NULL,
  `tab_field_id` int NOT NULL,
  `tab_field_value` text NOT NULL,
  `date_taken` datetime NOT NULL,
  `chief_complaint_id` int DEFAULT NULL,
  `IsDeleted` datetime DEFAULT NULL,
  `DeletedByUserId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `fk_patient_encounter_tab_fields_user_idx` (`user_id`),
  KEY `fk_patient_encounter_tab_fields_patient_encounter_idx` (`patient_encounter_id`),
  KEY `fk_patient_encounter_tab_fields_tab_field_idx` (`tab_field_id`),
  KEY `fk_patient_encounter_tab_fields_chief_complaint_idx` (`chief_complaint_id`),
  KEY `fk_deleted_by_user_id_id` (`DeletedByUserId`),
  CONSTRAINT `fk_deleted_by_user_id_id` FOREIGN KEY (`DeletedByUserId`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_patient_encounter_tab_fields_chief_complaint` FOREIGN KEY (`chief_complaint_id`) REFERENCES `chief_complaints` (`id`),
  CONSTRAINT `fk_patient_encounter_tab_fields_patient_encounter` FOREIGN KEY (`patient_encounter_id`) REFERENCES `patient_encounters` (`id`),
  CONSTRAINT `fk_patient_encounter_tab_fields_tab_field` FOREIGN KEY (`tab_field_id`) REFERENCES `tab_fields` (`id`),
  CONSTRAINT `fk_patient_encounter_tab_fields_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_encounter_tab_fields`
--

LOCK TABLES `patient_encounter_tab_fields` WRITE;
/*!40000 ALTER TABLE `patient_encounter_tab_fields` DISABLE KEYS */;
INSERT INTO `patient_encounter_tab_fields` VALUES (1,4,75,35,'Test','2026-01-22 21:34:44',NULL,NULL,NULL),(2,4,75,26,'Now','2026-01-22 21:35:11',NULL,NULL,NULL),(3,4,75,29,'Good','2026-01-22 21:35:11',NULL,NULL,NULL);
/*!40000 ALTER TABLE `patient_encounter_tab_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_encounter_vitals`
--

DROP TABLE IF EXISTS `patient_encounter_vitals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_encounter_vitals` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `patient_encounter_id` int NOT NULL,
  `vital_id` int NOT NULL,
  `vital_value` float NOT NULL,
  `date_taken` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `user_id_idx` (`user_id`),
  KEY `patient_encounter_id_idx` (`patient_encounter_id`),
  KEY `vital_id_idx` (`vital_id`),
  CONSTRAINT `fk_patient_encounter_vitals_patient_encounter_id` FOREIGN KEY (`patient_encounter_id`) REFERENCES `patient_encounters` (`id`),
  CONSTRAINT `fk_patient_encounter_vitals_user_id_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_patient_encounter_vitals_vital_id_vitals_id` FOREIGN KEY (`vital_id`) REFERENCES `vitals` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_encounter_vitals`
--

LOCK TABLES `patient_encounter_vitals` WRITE;
/*!40000 ALTER TABLE `patient_encounter_vitals` DISABLE KEYS */;
INSERT INTO `patient_encounter_vitals` VALUES (1,4,68,3,96.8,'2026-01-06 21:22:20'),(2,4,68,7,154.322,'2026-01-06 21:22:20'),(3,4,68,15,1,'2026-01-06 21:22:20');
/*!40000 ALTER TABLE `patient_encounter_vitals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_encounters`
--

DROP TABLE IF EXISTS `patient_encounters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_encounters` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NOT NULL,
  `user_id_triage` int NOT NULL,
  `date_of_triage_visit` datetime NOT NULL,
  `date_of_medical_visit` datetime DEFAULT NULL,
  `date_of_pharmacy_visit` datetime DEFAULT NULL,
  `user_id_medical` int DEFAULT NULL,
  `user_id_pharmacy` int DEFAULT NULL,
  `patient_age_classification_id` int DEFAULT NULL,
  `mission_trip_id` int DEFAULT NULL,
  `is_diabetes_screened` tinyint(1) DEFAULT NULL,
  `user_id_diabetes_screen` int DEFAULT NULL,
  `date_of_diabetes_screen` datetime DEFAULT NULL,
  `isDeleted` datetime DEFAULT NULL,
  `deleted_by_user_id` int DEFAULT NULL,
  `reason_deleted` varchar(255) DEFAULT NULL,
  `language_code` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ID_UNIQUE` (`id`),
  KEY `patient_id_idx` (`patient_id`),
  KEY `fk_patient_encounter_patient_age_classification_id_idx` (`patient_age_classification_id`),
  KEY `fk_patient_encounters_id_mission_trip_id_idx` (`mission_trip_id`),
  KEY `fk_patient_encounters_user_id_users_id_diabetes_idx` (`user_id_diabetes_screen`),
  KEY `fk_patient_encounter_deletedbyuser_id_users_id` (`deleted_by_user_id`),
  KEY `fk_patient_encounter_user_id_users_id_nurse_idx` (`user_id_triage`),
  KEY `fk_patient_encounter_user_id_users_id_doc_idx` (`user_id_medical`),
  KEY `fk_patient_encounter_user_id_users_id_pharm_idx` (`user_id_pharmacy`),
  CONSTRAINT `fk_patient_encounter_deletedbyuser_id_users_id` FOREIGN KEY (`deleted_by_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_patient_encounter_patient_age_classification_id` FOREIGN KEY (`patient_age_classification_id`) REFERENCES `patient_age_classifications` (`id`),
  CONSTRAINT `fk_patient_encounter_patient_id_patients_id` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`),
  CONSTRAINT `fk_patient_encounter_user_id_users_id_doc` FOREIGN KEY (`user_id_medical`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_patient_encounter_user_id_users_id_nurse` FOREIGN KEY (`user_id_triage`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_patient_encounter_user_id_users_id_pharm` FOREIGN KEY (`user_id_pharmacy`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_patient_encounters_id_mission_trip_id` FOREIGN KEY (`mission_trip_id`) REFERENCES `mission_trips` (`id`),
  CONSTRAINT `fk_patient_encounters_user_id_users_id_diabetes` FOREIGN KEY (`user_id_diabetes_screen`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_encounters`
--

LOCK TABLES `patient_encounters` WRITE;
/*!40000 ALTER TABLE `patient_encounters` DISABLE KEYS */;
INSERT INTO `patient_encounters` VALUES (1,34,4,'2025-12-04 20:10:48',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(2,35,4,'2025-12-04 20:10:48',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(3,36,4,'2025-12-04 20:10:48',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(4,37,4,'2025-12-04 20:39:17',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(5,38,4,'2025-12-04 20:39:17',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(6,39,4,'2025-12-04 20:39:17',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(7,40,4,'2025-12-04 21:16:25',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(8,41,4,'2025-12-04 21:16:25',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(9,42,4,'2025-12-04 21:16:25',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(10,43,4,'2025-12-04 21:16:25',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(11,44,4,'2025-12-04 21:16:25',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(12,45,4,'2025-12-04 21:16:25',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(13,46,4,'2025-12-04 21:16:25',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(14,47,4,'2025-12-04 21:16:25',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(15,48,4,'2025-12-04 21:16:25',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(16,49,4,'2025-12-04 21:16:25',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(17,50,4,'2025-12-04 21:16:25',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(18,51,4,'2025-12-04 21:16:25',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(19,52,4,'2025-12-04 21:59:02',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(20,53,4,'2025-12-04 21:59:02',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(21,54,4,'2025-12-04 21:59:02',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(22,55,4,'2025-12-04 21:59:02',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(23,56,4,'2025-12-04 21:59:02',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(24,57,4,'2025-12-04 21:59:02',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(25,58,4,'2025-12-04 21:59:03',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(26,59,4,'2025-12-04 21:59:03',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(27,60,4,'2025-12-04 21:59:03',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(28,61,4,'2025-12-04 21:59:03',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(29,62,4,'2025-12-04 21:59:03',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(30,63,4,'2025-12-04 21:59:03',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(31,64,4,'2025-12-04 23:08:40',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(32,65,4,'2025-12-04 23:08:40',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(33,66,4,'2025-12-04 23:08:40',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(34,67,4,'2025-12-04 23:08:41',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(35,68,4,'2025-12-04 23:08:41',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(36,69,4,'2025-12-04 23:08:41',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:23',4,'Bulk patient wipe from manager page','en'),(37,70,4,'2025-12-04 23:08:41',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:24',4,'Bulk patient wipe from manager page','en'),(38,71,4,'2025-12-04 23:08:41',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:24',4,'Bulk patient wipe from manager page','en'),(39,72,4,'2025-12-04 23:08:41',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:24',4,'Bulk patient wipe from manager page','en'),(40,73,4,'2025-12-04 23:08:41',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:24',4,'Bulk patient wipe from manager page','en'),(41,74,4,'2025-12-04 23:08:41',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:24',4,'Bulk patient wipe from manager page','en'),(42,75,4,'2025-12-04 23:08:41',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2025-12-04 23:24:24',4,'Bulk patient wipe from manager page','en'),(43,76,4,'2025-12-04 23:24:31',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(44,77,4,'2025-12-04 23:24:31',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(45,78,4,'2025-12-04 23:24:31',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(46,79,4,'2025-12-04 23:24:31',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(47,80,4,'2025-12-04 23:24:31',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(48,81,4,'2025-12-04 23:24:31',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(49,82,4,'2025-12-04 23:24:31',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(50,83,4,'2025-12-04 23:24:31',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(51,84,4,'2025-12-04 23:24:31',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(52,85,4,'2025-12-04 23:24:31',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(53,86,4,'2025-12-04 23:24:31',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(54,87,4,'2025-12-04 23:24:31',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(55,88,4,'2025-12-08 03:21:37',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(56,89,4,'2025-12-08 03:21:37',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(57,90,4,'2025-12-08 03:21:37',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(58,91,4,'2025-12-08 03:21:37',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(59,92,4,'2025-12-08 03:21:38',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(60,93,4,'2025-12-08 03:21:38',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(61,94,4,'2025-12-08 03:21:38',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(62,95,4,'2025-12-08 03:21:38',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(63,96,4,'2025-12-08 03:21:38',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(64,97,4,'2025-12-08 03:21:38',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(65,98,4,'2025-12-08 03:21:38',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(66,99,4,'2025-12-08 03:21:38',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(67,100,4,'2026-01-06 21:17:11',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(68,101,4,'2026-01-06 21:22:21',NULL,NULL,NULL,NULL,5,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(69,102,4,'2026-01-06 21:25:51',NULL,NULL,NULL,NULL,4,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(70,103,4,'2026-01-08 20:34:55',NULL,NULL,NULL,NULL,4,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(71,104,4,'2026-01-08 21:13:56',NULL,NULL,NULL,NULL,5,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(72,105,4,'2026-01-08 21:17:01',NULL,NULL,NULL,NULL,2,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(73,106,4,'2026-01-08 21:35:31',NULL,NULL,NULL,NULL,4,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(74,107,4,'2026-01-13 21:24:25',NULL,NULL,NULL,NULL,2,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(75,108,4,'2026-01-22 21:32:45','2026-01-22 21:35:11',NULL,4,NULL,2,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(76,109,4,'2026-01-27 20:48:30',NULL,NULL,NULL,NULL,2,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(77,110,4,'2026-02-01 00:19:32',NULL,NULL,NULL,NULL,2,2,NULL,NULL,NULL,NULL,NULL,NULL,'en'),(78,111,4,'2026-03-17 16:25:57',NULL,NULL,NULL,NULL,2,2,NULL,NULL,NULL,NULL,NULL,NULL,'en');
/*!40000 ALTER TABLE `patient_encounters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_prescription_replacement_reasons`
--

DROP TABLE IF EXISTS `patient_prescription_replacement_reasons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_prescription_replacement_reasons` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_prescription_replacement_reasons`
--

LOCK TABLES `patient_prescription_replacement_reasons` WRITE;
/*!40000 ALTER TABLE `patient_prescription_replacement_reasons` DISABLE KEYS */;
INSERT INTO `patient_prescription_replacement_reasons` VALUES (1,'physician edit','the editing of a prescription as it\'s being prescribed by a physician'),(2,'pharmacist replacement','the replacement of a prescription by a pharmacist'),(3,'encounter edit','the editing of a prescription after the encounter has been closed');
/*!40000 ALTER TABLE `patient_prescription_replacement_reasons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_prescription_replacements`
--

DROP TABLE IF EXISTS `patient_prescription_replacements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_prescription_replacements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patient_prescription_id_original` int NOT NULL,
  `patient_prescription_id_replacement` int NOT NULL,
  `patient_prescription_replacement_reason_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `fk_prescriptionReplacements_id_original_prescriptions_id_idx` (`patient_prescription_id_original`),
  KEY `fk_prescriptionReplacements_id_replacement_prescriptions_id_idx` (`patient_prescription_id_replacement`),
  KEY `fk_prescriptionReplacements_replacementReason_id_reasons_id_idx` (`patient_prescription_replacement_reason_id`),
  CONSTRAINT `fk_prescriptionReplacements_id_original_prescriptions_id` FOREIGN KEY (`patient_prescription_id_original`) REFERENCES `patient_prescriptions` (`id`),
  CONSTRAINT `fk_prescriptionReplacements_id_replacement_prescriptions_id` FOREIGN KEY (`patient_prescription_id_replacement`) REFERENCES `patient_prescriptions` (`id`),
  CONSTRAINT `fk_prescriptionReplacements_replacementReason_id_reasons_id` FOREIGN KEY (`patient_prescription_replacement_reason_id`) REFERENCES `patient_prescription_replacement_reasons` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_prescription_replacements`
--

LOCK TABLES `patient_prescription_replacements` WRITE;
/*!40000 ALTER TABLE `patient_prescription_replacements` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_prescription_replacements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_prescriptions`
--

DROP TABLE IF EXISTS `patient_prescriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_prescriptions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `encounter_id` int NOT NULL,
  `medication_id` int NOT NULL,
  `concept_prescription_administrations_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  `amount` int DEFAULT NULL,
  `special_instructions` text,
  `isCounseled` bit(1) NOT NULL DEFAULT b'0',
  `date_taken` datetime NOT NULL,
  `date_dispensed` datetime DEFAULT NULL,
  `language_code` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `fk_patient_prescriptions_idx` (`encounter_id`),
  KEY `fk_patient_prescriptions_user_id__idx` (`user_id`),
  KEY `fk_patient_prescriptions_medications_idx` (`medication_id`),
  KEY `fk_patient_prescriptions_medication_administrations_idx` (`concept_prescription_administrations_id`),
  CONSTRAINT `fk_patient_prescriptions_concept_prescription_administrations` FOREIGN KEY (`concept_prescription_administrations_id`) REFERENCES `concept_prescription_administrations` (`id`),
  CONSTRAINT `fk_patient_prescriptions_encounter_id_patient_encounters_id` FOREIGN KEY (`encounter_id`) REFERENCES `patient_encounters` (`id`),
  CONSTRAINT `fk_patient_prescriptions_medications` FOREIGN KEY (`medication_id`) REFERENCES `medications` (`id`),
  CONSTRAINT `fk_patient_prescriptions_user_id_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_prescriptions`
--

LOCK TABLES `patient_prescriptions` WRITE;
/*!40000 ALTER TABLE `patient_prescriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_prescriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patients` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `age` date DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(255) NOT NULL,
  `photo_id` int DEFAULT NULL,
  `isDeleted` datetime DEFAULT NULL,
  `deleted_by_user_id` int DEFAULT NULL,
  `reason_deleted` varchar(255) DEFAULT NULL,
  `dm_first_name` varchar(255) DEFAULT NULL,
  `dm_last_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `user_id_idx` (`user_id`),
  KEY `patient_photo_id_idx` (`photo_id`),
  KEY `fk_patients_user_deleted_by_user_id_id` (`deleted_by_user_id`),
  CONSTRAINT `fk_patients_user_deleted_by_user_id_id` FOREIGN KEY (`deleted_by_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_patients_user_id_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `patients_ibfk_1` FOREIGN KEY (`photo_id`) REFERENCES `photos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients`
--

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES (1,1,'John','Doe','555-1234','1985-03-15','M','123 Main St','Springfield',NULL,NULL,NULL,NULL,'JN;AN','T'),(2,1,'Jane','Smith','555-5678','1990-07-22','F','456 Oak Ave','Shelbyville',NULL,NULL,NULL,NULL,'JN;AN','SM0;XMT'),(3,1,'Robert','Johnson','555-9012','1978-11-08','M','789 Pine Rd','Capital City',NULL,NULL,NULL,NULL,'RPRT','JNSN;ANSN'),(4,3,'John','Doe','555-1234','1985-03-15','M','123 Main St','Springfield',NULL,NULL,NULL,NULL,'JN;AN','T'),(5,3,'Jane','Smith','555-5678','1990-07-22','F','456 Oak Ave','Shelbyville',NULL,NULL,NULL,NULL,'JN;AN','SM0;XMT'),(6,3,'Robert','Johnson','555-9012','1978-11-08','M','789 Pine Rd','Capital City',NULL,NULL,NULL,NULL,'RPRT','JNSN;ANSN'),(7,3,'John','Doe','555-1234','1985-03-15','M','123 Main St','Springfield',NULL,NULL,NULL,NULL,'JN;AN','T'),(8,3,'Jane','Smith','555-5678','1990-07-22','F','456 Oak Ave','Shelbyville',NULL,NULL,NULL,NULL,'JN;AN','SM0;XMT'),(9,3,'Robert','Johnson','555-9012','1978-11-08','M','789 Pine Rd','Capital City',NULL,NULL,NULL,NULL,'RPRT','JNSN;ANSN'),(10,4,'John','Doe','555-1234','1985-03-15','M','123 Main St','Springfield',NULL,NULL,NULL,NULL,'JN;AN','T'),(11,4,'Jane','Smith','555-5678','1990-07-22','F','456 Oak Ave','Shelbyville',NULL,NULL,NULL,NULL,'JN;AN','SM0;XMT'),(12,4,'Robert','Johnson','555-9012','1978-11-08','M','789 Pine Rd','Capital City',NULL,NULL,NULL,NULL,'RPRT','JNSN;ANSN'),(13,4,'John','Doe','555-1234','1985-03-15','M','123 Main St','Springfield',NULL,NULL,NULL,NULL,'JN;AN','T'),(14,4,'Jane','Smith','555-5678','1990-07-22','F','456 Oak Ave','Shelbyville',NULL,NULL,NULL,NULL,'JN;AN','SM0;XMT'),(15,4,'Robert','Johnson','555-9012','1978-11-08','M','789 Pine Rd','Capital City',NULL,NULL,NULL,NULL,'RPRT','JNSN;ANSN'),(16,4,'John','Doe','555-1234','1985-03-15','M','123 Main St','Springfield',NULL,NULL,NULL,NULL,'JN;AN','T'),(17,4,'Jane','Smith','555-5678','1990-07-22','F','456 Oak Ave','Shelbyville',NULL,NULL,NULL,NULL,'JN;AN','SM0;XMT'),(18,4,'Robert','Johnson','555-9012','1978-11-08','M','789 Pine Rd','Capital City',NULL,NULL,NULL,NULL,'RPRT','JNSN;ANSN'),(19,4,'John','Doe','555-1234','1985-03-15','M','123 Main St','Springfield',NULL,NULL,NULL,NULL,'JN;AN','T'),(20,4,'Jane','Smith','555-5678','1990-07-22','F','456 Oak Ave','Shelbyville',NULL,NULL,NULL,NULL,'JN;AN','SM0;XMT'),(21,4,'Robert','Johnson','555-9012','1978-11-08','M','789 Pine Rd','Capital City',NULL,NULL,NULL,NULL,'RPRT','JNSN;ANSN'),(22,3,'John','Doe','555-1234','1985-03-15','M','123 Main St','Springfield',NULL,NULL,NULL,NULL,'JN;AN','T'),(23,3,'Jane','Smith','555-5678','1990-07-22','F','456 Oak Ave','Shelbyville',NULL,NULL,NULL,NULL,'JN;AN','SM0;XMT'),(24,3,'Robert','Johnson','555-9012','1978-11-08','M','789 Pine Rd','Capital City',NULL,NULL,NULL,NULL,'RPRT','JNSN;ANSN'),(25,3,'John','Doe','555-1234','1985-03-15','M','123 Main St','Springfield',NULL,NULL,NULL,NULL,'JN;AN','T'),(26,3,'Jane','Smith','555-5678','1990-07-22','F','456 Oak Ave','Shelbyville',NULL,NULL,NULL,NULL,'JN;AN','SM0;XMT'),(27,3,'Robert','Johnson','555-9012','1978-11-08','M','789 Pine Rd','Capital City',NULL,NULL,NULL,NULL,'RPRT','JNSN;ANSN'),(28,4,'John','Doe','555-1234','1985-03-15','M','123 Main St','Springfield',NULL,NULL,NULL,NULL,'JN;AN','T'),(29,4,'Jane','Smith','555-5678','1990-07-22','F','456 Oak Ave','Shelbyville',NULL,NULL,NULL,NULL,'JN;AN','SM0;XMT'),(30,4,'Robert','Johnson','555-9012','1978-11-08','M','789 Pine Rd','Capital City',NULL,NULL,NULL,NULL,'RPRT','JNSN;ANSN'),(31,4,'John','Doe','555-1234','1985-03-15','M','123 Main St','Springfield',NULL,NULL,NULL,NULL,'JN;AN','T'),(32,4,'Jane','Smith','555-5678','1990-07-22','F','456 Oak Ave','Shelbyville',NULL,NULL,NULL,NULL,'JN;AN','SM0;XMT'),(33,4,'Robert','Johnson','555-9012','1978-11-08','M','789 Pine Rd','Capital City',NULL,NULL,NULL,NULL,'RPRT','JNSN;ANSN'),(34,4,'John','Doe','555-1234','1985-03-15','M','123 Main St','Springfield',NULL,NULL,NULL,NULL,'JN;AN','T'),(35,4,'Jane','Smith','555-5678','1990-07-22','F','456 Oak Ave','Shelbyville',NULL,NULL,NULL,NULL,'JN;AN','SM0;XMT'),(36,4,'Robert','Johnson','555-9012','1978-11-08','M','789 Pine Rd','Capital City',NULL,NULL,NULL,NULL,'RPRT','JNSN;ANSN'),(37,4,'John','Doe','555-1234','1985-03-15','M','123 Main St','Springfield',NULL,NULL,NULL,NULL,'JN;AN','T'),(38,4,'Jane','Smith','555-5678','1990-07-22','F','456 Oak Ave','Shelbyville',NULL,NULL,NULL,NULL,'JN;AN','SM0;XMT'),(39,4,'Robert','Johnson','555-9012','1978-11-08','M','789 Pine Rd','Capital City',NULL,NULL,NULL,NULL,'RPRT','JNSN;ANSN'),(40,4,'John','Doe','555-1234','1985-03-15','M','123 Main St','Springfield',NULL,NULL,NULL,NULL,'JN;AN','T'),(41,4,'Jane','Smith','555-5678','1990-07-22','F','456 Oak Ave','Shelbyville',NULL,NULL,NULL,NULL,'JN;AN','SM0;XMT'),(42,4,'Robert','Johnson','555-9012','1978-11-08','M','789 Pine Rd','Capital City',NULL,NULL,NULL,NULL,'RPRT','JNSN;ANSN'),(43,4,'Maria','Garcia','555-3456','1992-05-30','F','321 Elm St','Metropolis',NULL,NULL,NULL,NULL,'MR','KRS;KRX'),(44,4,'Ahmed','Hassan','555-7890','1988-02-14','M','654 Oak Lane','Gotham',NULL,NULL,NULL,NULL,'AMT','HSN'),(45,4,'Sofia','Rodriguez','555-2468','2010-08-18','F','987 Birch Way','Shelbyville',NULL,NULL,NULL,NULL,'SF','RTRKS'),(46,4,'Michael','Thompson','555-1357','1995-09-25','M','147 Cedar Ln','Capital City',NULL,NULL,NULL,NULL,'MKL;MXL','TMPSN'),(47,4,'Priya','Patel','555-2579','1999-11-03','F','258 Spruce Ave','Metropolis',NULL,NULL,NULL,NULL,'PR','PTL'),(48,4,'David','Kim','555-3691','2012-04-12','M','369 Walnut St','Gotham',NULL,NULL,NULL,NULL,'TFT','KM'),(49,4,'Elena','Vasquez','555-4802','1987-01-29','F','741 Hickory Dr','Springfield',NULL,NULL,NULL,NULL,'ALN','FSKS'),(50,4,'Carlos','Mendez','555-5913','1980-06-16','M','852 Maple Terrace','Shelbyville',NULL,NULL,NULL,NULL,'KRLS','MNTS'),(51,4,'Amina','Okafor','555-6024','2015-03-07','F','963 Oak Street','Capital City',NULL,NULL,NULL,NULL,'AMN','AKFR'),(52,4,'John','Doe','555-1234','1985-03-15','M','123 Main St','Springfield',NULL,NULL,NULL,NULL,'JN;AN','T'),(53,4,'Jane','Smith','555-5678','1990-07-22','F','456 Oak Ave','Shelbyville',NULL,NULL,NULL,NULL,'JN;AN','SM0;XMT'),(54,4,'Robert','Johnson','555-9012','1978-11-08','M','789 Pine Rd','Capital City',NULL,NULL,NULL,NULL,'RPRT','JNSN;ANSN'),(55,4,'Maria','Garcia','555-3456','1992-05-30','F','321 Elm St','Metropolis',NULL,NULL,NULL,NULL,'MR','KRS;KRX'),(56,4,'Ahmed','Hassan','555-7890','1988-02-14','M','654 Oak Lane','Gotham',NULL,NULL,NULL,NULL,'AMT','HSN'),(57,4,'Sofia','Rodriguez','555-2468','2010-08-18','F','987 Birch Way','Shelbyville',NULL,NULL,NULL,NULL,'SF','RTRKS'),(58,4,'Michael','Thompson','555-1357','1995-09-25','M','147 Cedar Ln','Capital City',NULL,NULL,NULL,NULL,'MKL;MXL','TMPSN'),(59,4,'Priya','Patel','555-2579','1999-11-03','F','258 Spruce Ave','Metropolis',NULL,NULL,NULL,NULL,'PR','PTL'),(60,4,'David','Kim','555-3691','2012-04-12','M','369 Walnut St','Gotham',NULL,NULL,NULL,NULL,'TFT','KM'),(61,4,'Elena','Vasquez','555-4802','1987-01-29','F','741 Hickory Dr','Springfield',NULL,NULL,NULL,NULL,'ALN','FSKS'),(62,4,'Carlos','Mendez','555-5913','1980-06-16','M','852 Maple Terrace','Shelbyville',NULL,NULL,NULL,NULL,'KRLS','MNTS'),(63,4,'Amina','Okafor','555-6024','2015-03-07','F','963 Oak Street','Capital City',NULL,NULL,NULL,NULL,'AMN','AKFR'),(64,4,'John','Doe','555-1234','1985-03-15','M','123 Main St','Springfield',NULL,NULL,NULL,NULL,'JN;AN','T'),(65,4,'Jane','Smith','555-5678','1990-07-22','F','456 Oak Ave','Shelbyville',NULL,NULL,NULL,NULL,'JN;AN','SM0;XMT'),(66,4,'Robert','Johnson','555-9012','1978-11-08','M','789 Pine Rd','Capital City',NULL,NULL,NULL,NULL,'RPRT','JNSN;ANSN'),(67,4,'Maria','Garcia','555-3456','1992-05-30','F','321 Elm St','Metropolis',NULL,NULL,NULL,NULL,'MR','KRS;KRX'),(68,4,'Ahmed','Hassan','555-7890','1988-02-14','M','654 Oak Lane','Gotham',NULL,NULL,NULL,NULL,'AMT','HSN'),(69,4,'Sofia','Rodriguez','555-2468','2010-08-18','F','987 Birch Way','Shelbyville',NULL,NULL,NULL,NULL,'SF','RTRKS'),(70,4,'Michael','Thompson','555-1357','1995-09-25','M','147 Cedar Ln','Capital City',NULL,NULL,NULL,NULL,'MKL;MXL','TMPSN'),(71,4,'Priya','Patel','555-2579','1999-11-03','F','258 Spruce Ave','Metropolis',NULL,NULL,NULL,NULL,'PR','PTL'),(72,4,'David','Kim','555-3691','2012-04-12','M','369 Walnut St','Gotham',NULL,NULL,NULL,NULL,'TFT','KM'),(73,4,'Elena','Vasquez','555-4802','1987-01-29','F','741 Hickory Dr','Springfield',NULL,NULL,NULL,NULL,'ALN','FSKS'),(74,4,'Carlos','Mendez','555-5913','1980-06-16','M','852 Maple Terrace','Shelbyville',NULL,NULL,NULL,NULL,'KRLS','MNTS'),(75,4,'Amina','Okafor','555-6024','2015-03-07','F','963 Oak Street','Capital City',NULL,NULL,NULL,NULL,'AMN','AKFR'),(76,4,'John','Doe','555-1234','1985-03-15','M','123 Main St','Springfield',NULL,NULL,NULL,NULL,'JN;AN','T'),(77,4,'Jane','Smith','555-5678','1990-07-22','F','456 Oak Ave','Shelbyville',NULL,NULL,NULL,NULL,'JN;AN','SM0;XMT'),(78,4,'Robert','Johnson','555-9012','1978-11-08','M','789 Pine Rd','Capital City',NULL,NULL,NULL,NULL,'RPRT','JNSN;ANSN'),(79,4,'Maria','Garcia','555-3456','1992-05-30','F','321 Elm St','Metropolis',NULL,NULL,NULL,NULL,'MR','KRS;KRX'),(80,4,'Ahmed','Hassan','555-7890','1988-02-14','M','654 Oak Lane','Gotham',NULL,NULL,NULL,NULL,'AMT','HSN'),(81,4,'Sofia','Rodriguez','555-2468','2010-08-18','F','987 Birch Way','Shelbyville',NULL,NULL,NULL,NULL,'SF','RTRKS'),(82,4,'Michael','Thompson','555-1357','1995-09-25','M','147 Cedar Ln','Capital City',NULL,NULL,NULL,NULL,'MKL;MXL','TMPSN'),(83,4,'Priya','Patel','555-2579','1999-11-03','F','258 Spruce Ave','Metropolis',NULL,NULL,NULL,NULL,'PR','PTL'),(84,4,'David','Kim','555-3691','2012-04-12','M','369 Walnut St','Gotham',NULL,NULL,NULL,NULL,'TFT','KM'),(85,4,'Elena','Vasquez','555-4802','1987-01-29','F','741 Hickory Dr','Springfield',NULL,NULL,NULL,NULL,'ALN','FSKS'),(86,4,'Carlos','Mendez','555-5913','1980-06-16','M','852 Maple Terrace','Shelbyville',NULL,NULL,NULL,NULL,'KRLS','MNTS'),(87,4,'Amina','Okafor','555-6024','2015-03-07','F','963 Oak Street','Capital City',NULL,NULL,NULL,NULL,'AMN','AKFR'),(88,4,'John','Doe','555-1234','1985-03-15','M','123 Main St','Springfield',NULL,NULL,NULL,NULL,'JN;AN','T'),(89,4,'Jane','Smith','555-5678','1990-07-22','F','456 Oak Ave','Shelbyville',NULL,NULL,NULL,NULL,'JN;AN','SM0;XMT'),(90,4,'Robert','Johnson','555-9012','1978-11-08','M','789 Pine Rd','Capital City',NULL,NULL,NULL,NULL,'RPRT','JNSN;ANSN'),(91,4,'Maria','Garcia','555-3456','1992-05-30','F','321 Elm St','Metropolis',NULL,NULL,NULL,NULL,'MR','KRS;KRX'),(92,4,'Ahmed','Hassan','555-7890','1988-02-14','M','654 Oak Lane','Gotham',NULL,NULL,NULL,NULL,'AMT','HSN'),(93,4,'Sofia','Rodriguez','555-2468','2010-08-18','F','987 Birch Way','Shelbyville',NULL,NULL,NULL,NULL,'SF','RTRKS'),(94,4,'Michael','Thompson','555-1357','1995-09-25','M','147 Cedar Ln','Capital City',NULL,NULL,NULL,NULL,'MKL;MXL','TMPSN'),(95,4,'Priya','Patel','555-2579','1999-11-03','F','258 Spruce Ave','Metropolis',NULL,NULL,NULL,NULL,'PR','PTL'),(96,4,'David','Kim','555-3691','2012-04-12','M','369 Walnut St','Gotham',NULL,NULL,NULL,NULL,'TFT','KM'),(97,4,'Elena','Vasquez','555-4802','1987-01-29','F','741 Hickory Dr','Springfield',NULL,NULL,NULL,NULL,'ALN','FSKS'),(98,4,'Carlos','Mendez','555-5913','1980-06-16','M','852 Maple Terrace','Shelbyville',NULL,NULL,NULL,NULL,'KRLS','MNTS'),(99,4,'Amina','Okafor','555-6024','2015-03-07','F','963 Oak Street','Capital City',NULL,NULL,NULL,NULL,'AMN','AKFR'),(100,4,'tdt','asdas',NULL,'2026-01-07','Male','','Morne De L\' Hopital',NULL,NULL,NULL,NULL,'TT','ASTS'),(101,4,'Test','guy',NULL,'1945-07-06','Male','','Morne De L\' Hopital',NULL,NULL,NULL,NULL,'TST','K'),(102,4,'Test2','Person',NULL,'1980-11-06','Male','','Morne De L\' Hopital',NULL,NULL,NULL,NULL,'TST','PRSN'),(103,4,'Test','User',NULL,'1987-11-08','Male','','Morne De L\' Hopital',NULL,NULL,NULL,NULL,'TST','ASR'),(104,4,'Mr. Sir','Sir',NULL,'1946-01-08','Male','','Morne De L\' Hopital',NULL,NULL,NULL,NULL,'MRSR','SR'),(105,4,'Test','Person',NULL,'2014-01-08','Female','','Morne De L\' Hopital',NULL,NULL,NULL,NULL,'TST','PRSN'),(106,4,'LePatient','LeLastName',NULL,'1986-01-08','Male','','Morne De L\' Hopital',NULL,NULL,NULL,NULL,'LPTNT','LLSTNM'),(107,4,'Test','g',NULL,'2015-12-13','Male','','Morne De L\' Hopital',NULL,NULL,NULL,NULL,'TST','K'),(108,4,'Test','Person',NULL,'2013-12-22','Male','','Morne De L\' Hopital',NULL,NULL,NULL,NULL,'TST','PRSN'),(109,4,'Robert','asdas',NULL,'2013-11-27','Male','','Morne De L\' Hopital',NULL,NULL,NULL,NULL,'RPRT','ASTS'),(110,4,'ttt','nnn',NULL,'2019-06-30','Male','','Morne De L\' Hopital',NULL,NULL,NULL,NULL,'TT','NN'),(111,4,'ttt','dssd',NULL,'2013-12-17','Male','','Morne De L\' Hopital',NULL,NULL,NULL,NULL,'TT','TST');
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`femr`@`%`*/ /*!50003 TRIGGER `insertDmFirst` BEFORE INSERT ON `patients` FOR EACH ROW SET new.dm_first_name = dm(new.first_name) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`femr`@`%`*/ /*!50003 TRIGGER `insertDmLast` BEFORE INSERT ON `patients` FOR EACH ROW SET new.dm_last_name = dm(new.last_name) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`femr`@`%`*/ /*!50003 TRIGGER `updateDmFirst` BEFORE UPDATE ON `patients` FOR EACH ROW SET new.dm_first_name = dm(new.first_name) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`femr`@`%`*/ /*!50003 TRIGGER `updateDmLast` BEFORE UPDATE ON `patients` FOR EACH ROW SET new.dm_last_name = dm(new.last_name) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `photos`
--

DROP TABLE IF EXISTS `photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `photos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` varchar(3072) NOT NULL,
  `file_path` varchar(1024) NOT NULL,
  `insertTS` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `photo` longblob,
  `language_code` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photos`
--

LOCK TABLES `photos` WRITE;
/*!40000 ALTER TABLE `photos` DISABLE KEYS */;
/*!40000 ALTER TABLE `photos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `play_evolutions`
--

DROP TABLE IF EXISTS `play_evolutions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `play_evolutions` (
  `id` int NOT NULL,
  `hash` varchar(255) NOT NULL,
  `applied_at` timestamp NOT NULL,
  `apply_script` mediumtext,
  `revert_script` mediumtext,
  `state` varchar(255) DEFAULT NULL,
  `last_problem` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `play_evolutions`
--

LOCK TABLES `play_evolutions` WRITE;
/*!40000 ALTER TABLE `play_evolutions` DISABLE KEYS */;
INSERT INTO `play_evolutions` VALUES (1,'9075fbf3ed7865119345001c3c3fb99f26f12ca9','2025-11-05 00:11:31','CREATE  TABLE `users` (\n`id` INT NOT NULL AUTO_INCREMENT ,\n`first_name` VARCHAR(255) NOT NULL ,\n`last_name` VARCHAR(255) NULL ,\n`email` VARCHAR(255) NOT NULL ,\n`password` VARCHAR(255) NOT NULL ,\nPRIMARY KEY (`id`) ,\nUNIQUE INDEX `id_UNIQUE` (`id` ASC) ,\nUNIQUE INDEX `email_UNIQUE` (`email` ASC) );','DROP TABLE IF EXISTS users;','applied',''),(2,'01e9f90df1df02ded0e38976449c49e379321e83','2025-11-05 00:11:31','CREATE  TABLE `roles` (\n`id` INT NOT NULL AUTO_INCREMENT ,\n`name` VARCHAR(255) NOT NULL ,\nPRIMARY KEY (`id`) ,\nUNIQUE INDEX `id_UNIQUE` (`id` ASC) ,\nUNIQUE INDEX `name_UNIQUE` (`name` ASC) )\nDEFAULT CHARACTER SET = utf8;\n\nINSERT INTO `roles` (`name`) VALUES (\'Administrator\');\nINSERT INTO `roles` (`name`) VALUES (\'Physician\');\nINSERT INTO `roles` (`name`) VALUES (\'Pharmacist\');\nINSERT INTO `roles` (`name`) VALUES (\'Researcher\');','DROP TABLE IF EXISTS roles;','applied',''),(3,'d3e299658e6ea58835080855516dbeb648c04411','2025-11-05 00:11:31','CREATE  TABLE `user_roles` (\n`id` INT NOT NULL AUTO_INCREMENT ,\n`user_id` INT NOT NULL ,\n`role_id` INT NOT NULL ,\nPRIMARY KEY (`id`) ,\nUNIQUE INDEX `id_UNIQUE` (`id` ASC) ,\nINDEX `fk_user_roles_user_id_users_id` (`user_id` ASC) ,\nINDEX `fk_user_roles_role_id_roles_id` (`role_id` ASC) ,\nCONSTRAINT `fk_user_roles_user_id_users_id`\nFOREIGN KEY (`user_id` )\nREFERENCES `users` (`id` ),\nCONSTRAINT `fk_user_roles_role_id_roles_id`\nFOREIGN KEY (`role_id` )\nREFERENCES `roles` (`id` ))\nDEFAULT CHARACTER SET = utf8;','DROP TABLE IF EXISTS `user_roles`;','applied',''),(4,'ed498f25dbfdcc5ccce25a1ba21ab9d3249ef369','2025-11-05 00:11:31','CREATE TABLE `patients` (\n`id` INT NOT NULL AUTO_INCREMENT ,\n`first_name` VARCHAR(255) NOT NULL ,\n`last_name` VARCHAR(255) NOT NULL ,\n`age` INT NOT NULL ,\n`sex` VARCHAR(10) NOT NULL ,\n`address` VARCHAR(255) NOT NULL ,\n`city` VARCHAR(255) NOT NULL ,\nPRIMARY KEY  (`id`) ,\nUNIQUE INDEX `id_UNIQUE` (`id` ASC))\nDEFAULT CHARACTER SET = utf8;','DROP TABLE IF EXISTS `patients`;','applied',''),(5,'1188cdcaa1f811571689e5e11de3bc5eb21a5f3b','2025-11-05 00:11:31','ALTER TABLE `patients`\nADD COLUMN `user_id` INT NOT NULL AFTER `id` ,\nADD CONSTRAINT `fk_patients_user_id_users_id`\nFOREIGN KEY (`user_id` )\nREFERENCES `users` (`id` )\n, ADD INDEX `user_id_idx` (`user_id` ASC);','ALTER TABLE `patients` DROP FOREIGN KEY `fk_patients_user_id_users_id` ;\nALTER TABLE `patients` DROP COLUMN `user_id`\n, DROP INDEX `user_id_idx` ;','applied',''),(6,'e7d90427fee3b02e251f6ffb66b5192873b53356','2025-11-05 00:11:31','CREATE  TABLE `patient_encounters` (\n`id` INT NOT NULL AUTO_INCREMENT ,\n`patient_id` INT NOT NULL ,\n`user_id` INT NOT NULL ,\n`date_of_visit` DATETIME NOT NULL ,\n`chief_complaint` VARCHAR(255) NULL ,\nPRIMARY KEY (`id`) ,\nUNIQUE INDEX `ID_UNIQUE` (`id` ASC) ,\nINDEX `patient_id_idx` (`patient_id` ASC) ,\nINDEX `user_id_idx` (`user_id` ASC) ,\nCONSTRAINT `fk_patient_encounter_patient_id_patients_id`\nFOREIGN KEY (`patient_id` )\nREFERENCES `patients` (`id` ),\nCONSTRAINT `fk_patient_encounter_user_id_users_id`\nFOREIGN KEY (`user_id` )\nREFERENCES `users` (`id` ));','DROP TABLE IF EXISTS `patient_encounters`;','applied',''),(7,'c4efe3becf7f859503200dd8c3bc271838379a2f','2025-11-05 00:11:31','CREATE  TABLE `vitals` (\n`id` INT NOT NULL AUTO_INCREMENT ,\n`name` VARCHAR(255) NOT NULL ,\n`data_type` VARCHAR(255) NULL ,\n`unit_of_measurement` VARCHAR(255) NULL ,\nPRIMARY KEY (`id`));\n\nINSERT INTO `vitals` (`name`,`data_type`,`unit_of_measurement`)\nVALUES (\'Respiratory Rate\',\'int\',\'breaths/minute\');\n\nINSERT INTO `vitals` (`name`,`data_type`,`unit_of_measurement`)\nVALUES (\'Heart Rate\',\'int\',\'beats/minute\');\n\nINSERT INTO `vitals` (`name`,`data_type`,`unit_of_measurement`)\nVALUES (\'Temperature\',\'float\',\'Fahrenheit\');\n\nINSERT INTO `vitals` (`name`,`data_type`,`unit_of_measurement`)\nVALUES (\'Oxygen Saturation\',\'float\',\'percent\');\n\nINSERT INTO `vitals` (`name`,`data_type`,`unit_of_measurement`)\nVALUES (\'Height\',\'int\',\'feet\');\n\nINSERT INTO `vitals` (`name`,`data_type`,`unit_of_measurement`)\nVALUES (\'Height\',\'int\',\'inches\');\n\nINSERT INTO `vitals` (`name`,`data_type`,`unit_of_measurement`)\nVALUES (\'Weight\',\'float\',\'pounds\');\n\nINSERT INTO `vitals` (`name`,`data_type`,`unit_of_measurement`)\nVALUES (\'Blood Pressure\',\'int\',\'systolic\');\n\nINSERT INTO `vitals` (`name`,`data_type`,`unit_of_measurement`)\nVALUES (\'Blood Pressure\',\'int\',\'diastolic\');','DROP TABLE IF EXISTS `vitals`','applied',''),(8,'94bc3ddd10d109748ca079cc029dd4bc7a9d99be','2025-11-05 00:11:31','CREATE  TABLE `patient_encounter_vitals` (\n`id` INT NOT NULL AUTO_INCREMENT ,\n`user_id` INT NOT NULL ,\n`patient_encounter_id` INT NOT NULL ,\n`vital_id` INT NOT NULL ,\n`vital_value` FLOAT NOT NULL ,\n`date_taken` DATETIME NOT NULL ,\nPRIMARY KEY (`id`) ,\nUNIQUE INDEX `id_UNIQUE` (`id` ASC) ,\nINDEX `user_id_idx` (`user_id` ASC) ,\nINDEX `patient_encounter_id_idx` (`patient_encounter_id` ASC) ,\nINDEX `vital_id_idx` (`vital_id` ASC) ,\nCONSTRAINT `fk_patient_encounter_vitals_user_id_users_id`\nFOREIGN KEY (`user_id` )\nREFERENCES `users` (`id` ),\nCONSTRAINT `fk_patient_encounter_vitals_patient_encounter_id`       #properly named constraint not accepted -- too long\nFOREIGN KEY (`patient_encounter_id` )\nREFERENCES `patient_encounters` (`id` ),\nCONSTRAINT `fk_patient_encounter_vitals_vital_id_vitals_id`\nFOREIGN KEY (`vital_id` )\nREFERENCES `vitals` (`id` ));','DROP TABLE IF EXISTS `patient_encounter_vitals`','applied',''),(9,'54aa0b3b948dfee7191923d51ae352ec3c4d027e','2025-11-05 00:11:31','CREATE  TABLE `medications` (\n`id` INT NOT NULL AUTO_INCREMENT ,\n`name` VARCHAR(255) NULL ,\nPRIMARY KEY (`id`) ,\nUNIQUE INDEX `id_UNIQUE` (`id` ASC) ,\nUNIQUE INDEX `name_UNIQUE` (`name` ASC) );','DROP TABLE IF EXISTS `medications`','applied',''),(10,'54d823bb2d78ddc72c56b43d94669348550ced6d','2025-11-05 00:11:31','UPDATE `vitals`\nSET name=\"Height_Feet\"\nWHERE name=\"Height\"\nAND unit_of_measurement = \"feet\";\n\nUPDATE `vitals`\nSET name=\"Height_Inches\"\nWHERE name=\"Height\"\nAND unit_of_measurement = \"inches\";\n\nUPDATE `vitals`\nSET name=\"Heart_Rate\"\nWHERE name=\"Heart Rate\";\n\nUPDATE `vitals`\nSET name=\"Respiratory_Rate\"\nWHERE name=\"Respiratory Rate\";\n\nUPDATE `vitals`\nSET name=\"Oxygen_Saturation\"\nWHERE name=\"Oxygen Saturation\";\n\nUPDATE `vitals`\nSET name=\"Blood_Pressure_Systolic\"\nWHERE name=\"Blood Pressure\"\nAND unit_of_measurement = \"systolic\";\n\nUPDATE `vitals`\nSET name=\"Blood_Pressure_Diasolic\"\nWHERE name=\"Blood Pressure\"\nAND unit_of_measurement = \"diasolic\";\n\nUPDATE `vitals`\nSET unit_of_measurement=\"mmHg\"\nWHERE unit_of_measurement=\"diasolic\";\n\nUPDATE `vitals`\nSET unit_of_measurement=\"mmHg\"\nWHERE unit_of_measurement=\"systolic\";','UPDATE `vitals`\nSET name=\"Height\"\nWHERE name=\"Height Feet\"\nAND unit_of_measurement = \"feet\";\n\nUPDATE `vitals`\nSET name=\"Height\"\nWHERE name=\"Height_Inches\"\nAND unit_of_measurement = \"inches\";\n\nUPDATE `vitals`\nSET name=\"Heart Rate\"\nWHERE name=\"Heart_Rate\";\n\nUPDATE `vitals`\nSET name=\"Respiratory Rate\"\nWHERE name=\"Respiratory_Rate\";\n\nUPDATE `vitals`\nSET name=\"Oxygen Saturation\"\nWHERE name=\"Oxygen_Saturation\";\n\nUPDATE `vitals`\nSET name=\"Blood Pressure\"\nWHERE name=\"Blood_Pressure_Systolic\"\nAND unit_of_measurement = \"systolic\";\n\nUPDATE `vitals`\nSET name=\"Blood Pressure\"\nWHERE name=\"Blood_Pressure_Diasolic\"\nAND unit_of_measurement = \"diasolic\";\n\nUPDATE `vitals`\nSET unit_of_measurement=\"diasolic\"\nWHERE name=\"Blood_Pressure_Diasolic\";\n\nUPDATE `vitals`\nSET unit_of_measurement=\"systolic\"\nWHERE name=\"Blood_Pressure_Systolic\";','applied',''),(11,'da39a3ee5e6b4b0d3255bfef95601890afd80709','2025-11-05 00:11:31','','','applied',''),(12,'7dabdf1d57fc9899d0aededd39fae780efa4c1a1','2025-11-05 00:11:31','','DROP TABLE IF EXISTS `patient_prescriptions`','applied',''),(13,'e9fb59ba6218889e05b25bac81fb511fa982053f','2025-11-05 00:11:31','ALTER TABLE `patients`\nCHANGE COLUMN `sex` `sex` VARCHAR(10) NULL  ,\nCHANGE COLUMN `address` `address` VARCHAR(255) NULL  ;','ALTER TABLE `patients`\nCHANGE COLUMN `sex` `sex` VARCHAR(10) NOT NULL  ,\nCHANGE COLUMN `address` `address` VARCHAR(255) NOT NULL  ;','applied',''),(14,'656acf0b3339155a04f7450cb32b23eb3b596d79','2025-11-05 00:11:31','ALTER TABLE `patient_encounters`\nADD COLUMN `weeks_pregnant` INT(255) NULL DEFAULT NULL  AFTER `chief_complaint`;','ALTER TABLE `patient_encounters`\nDROP COLUMN `weeks_pregnant`;','applied',''),(15,'8acdaa681687e41328b22c11f49865b4cc052890','2025-11-05 00:11:32','UPDATE `vitals`\nSET `name`=\'bloodPressureDiastolic\'\nWHERE `id`=\'9\';','UPDATE `vitals`\nSET `name`=\'bloodPressureDiasolic\'\nWHERE `id`=\'9\';','applied',''),(16,'7b4967dfb3366d5493b8bf60a29ba704c2c98f95','2025-11-05 00:11:32','UPDATE `vitals` SET `name`=\'respiratoryRate\' WHERE `id`=\'1\';\nUPDATE `vitals` SET `name`=\'heartRate\' WHERE `id`=\'2\';\nUPDATE `vitals` SET `name`=\'temperature\' WHERE `id`=\'3\';\nUPDATE `vitals` SET `name`=\'oxygenSaturation\' WHERE `id`=\'4\';\nUPDATE `vitals` SET `name`=\'heightFeet\' WHERE `id`=\'5\';\nUPDATE `vitals` SET `name`=\'heightInches\' WHERE `id`=\'6\';\nUPDATE `vitals` SET `name`=\'weight\' WHERE `id`=\'7\';\nUPDATE `vitals` SET `name`=\'bloodPressureSystolic\' WHERE `id`=\'8\';\nUPDATE `vitals` SET `name`=\'bloodPressureDiastolic\' WHERE `id`=\'9\';','UPDATE `vitals` SET `name`=\'Respiratory_Rate\' WHERE `id`=\'1\';\nUPDATE `vitals` SET `name`=\'Heart_Rate\' WHERE `id`=\'2\';\nUPDATE `vitals` SET `name`=\'Temperature\' WHERE `id`=\'3\';\nUPDATE `vitals` SET `name`=\'Oxygen_Saturation\' WHERE `id`=\'4\';\nUPDATE `vitals` SET `name`=\'Height_Feet\' WHERE `id`=\'5\';\nUPDATE `vitals` SET `name`=\'Height_Inches\' WHERE `id`=\'6\';\nUPDATE `vitals` SET `name`=\'Weight\' WHERE `id`=\'7\';\nUPDATE `vitals` SET `name`=\'Blood_Pressure_Systolic\' WHERE `id`=\'8\';\nUPDATE `vitals` SET `name`=\'Blood_Pressure_Diastolic\' WHERE `id`=\'9\';','applied',''),(17,'3f1aaf25830fc7199b3655126300df44eb16f8f8','2025-11-05 00:11:32','CREATE TABLE `patient_prescriptions` (\n`id` INT NOT NULL AUTO_INCREMENT,\n`encounter_id` INT NOT NULL,\n`medication_id` INT NOT NULL,\n`user_id` INT NOT NULL,\n`amount` INT NOT NULL,\n`replaced` BIT NOT NULL DEFAULT 0,\n`reason` VARCHAR(255) NULL,\n`replacement_id` INT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC),\nINDEX `fk_patient_prescriptions_idx` (`encounter_id` ASC),\nINDEX `fk_patient_prescriptions_idx1` (`medication_id` ASC),\nINDEX `fk_patient_prescriptions_user_id__idx` (`user_id` ASC),\nCONSTRAINT `fk_patient_prescriptions_encounter_id_patient_encounters_id`\nFOREIGN KEY (`encounter_id`)\nREFERENCES `patient_encounters` (`id`),\nCONSTRAINT `fk_patient_prescriptions_medication_id_medications_id`\nFOREIGN KEY (`medication_id`)\nREFERENCES `medications` (`id`),\nCONSTRAINT `fk_patient_prescriptions_user_id_users_id`\nFOREIGN KEY (`user_id`)\nREFERENCES `users` (`id`));\n\nALTER TABLE `patient_prescriptions`\nADD INDEX `fk_patient_prescriptions_replacement_id_patent_prescription_idx` (`replacement_id` ASC);\nALTER TABLE `patient_prescriptions`\nADD CONSTRAINT `fk_patient_prescriptions_replacement_id_patient_prescriptions_id`\nFOREIGN KEY (`replacement_id`)\nREFERENCES `patient_prescriptions` (`id`);','DROP TABLE IF EXISTS `patient_prescriptions`','applied',''),(18,'9d521ff4284a1abb0e1fdcf704b9bd38e021e38e','2025-11-05 00:11:32','CREATE  TABLE `hpi_fields` (\n`id` INT NOT NULL AUTO_INCREMENT ,\n`name` VARCHAR(255) NOT NULL ,\nPRIMARY KEY (`id`) ,\nUNIQUE INDEX `id_UNIQUE` (`id` ASC) );\n\nINSERT INTO `hpi_fields` (`name`) VALUES (\'onset\');\nINSERT INTO `hpi_fields` (`name`) VALUES (\'onsetTime\');\nINSERT INTO `hpi_fields` (`name`) VALUES (\'severity\');\nINSERT INTO `hpi_fields` (`name`) VALUES (\'radiation\');\nINSERT INTO `hpi_fields` (`name`) VALUES (\'quality\');\nINSERT INTO `hpi_fields` (`name`) VALUES (\'provokes\');\nINSERT INTO `hpi_fields` (`name`) VALUES (\'palliates\');\nINSERT INTO `hpi_fields` (`name`) VALUES (\'timeOfDay\');\nINSERT INTO `hpi_fields` (`name`) VALUES (\'physicalExamination\');','DROP TABLE IF EXISTS `hpi_fields`','applied',''),(19,'005fa33d4b9140d777c1dc8bb21177d25f80c662','2025-11-05 00:11:32','CREATE  TABLE `patient_encounter_hpi_fields` (\n`id` INT NOT NULL AUTO_INCREMENT ,\n`user_id` INT NULL ,\n`patient_encounter_id` INT NULL ,\n`hpi_field_id` INT NULL ,\n`hpi_field_value` VARCHAR(255) NULL ,\n`date_taken` DATETIME NULL ,\nPRIMARY KEY (`id`) ,\nUNIQUE INDEX `id_UNIQUE` (`id` ASC) ,\nINDEX `fk_patient_encounter_hpi_fields_user_id_users_id_idx` (`user_id` ASC) ,\nINDEX `fk_patient_encounter_hpi_field_id_hpi_fields_id_idx` (`hpi_field_id` ASC) ,\nINDEX `fk_patient_encounter_hpi_fields_patient_encounter_id_idx` (`patient_encounter_id` ASC) ,\nCONSTRAINT `fk_patient_encounter_hpi_fields_user_id_users_id`\nFOREIGN KEY (`user_id` )\nREFERENCES `users` (`id` )\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nCONSTRAINT `fk_patient_encounter_hpi_fields_hpi_field_id_hpi_fields_id`\nFOREIGN KEY (`hpi_field_id` )\nREFERENCES `hpi_fields` (`id` )\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nCONSTRAINT `fk_patient_encounter_hpi_fields_patient_encounter_id`\nFOREIGN KEY (`patient_encounter_id` )\nREFERENCES `patient_encounters` (`id` )\nON DELETE NO ACTION\nON UPDATE NO ACTION);','DROP TABLE IF EXISTS `patient_encounter_hpi_fields`','applied',''),(20,'9d39ef04f08c695a5c364b653fc0b090d2ffeb40','2025-11-05 00:11:32','CREATE  TABLE `treatment_fields` (\n`id` INT NOT NULL AUTO_INCREMENT ,\n`name` VARCHAR(255) NOT NULL ,\nPRIMARY KEY (`id`) ,\nUNIQUE INDEX `id_UNIQUE` (`id` ASC) );\n\nINSERT INTO `treatment_fields` (`name`) VALUES (\'assessment\');\nINSERT INTO `treatment_fields` (`name`) VALUES (\'problem\');\nINSERT INTO `treatment_fields` (`name`) VALUES (\'treatment\');\nINSERT INTO `treatment_fields` (`name`) VALUES (\'familyHistory\');','DROP TABLE IF EXISTS `treatment_fields`','applied',''),(21,'0eb589f61537d38a5a306ce6a238547a3e7d29e0','2025-11-05 00:11:32','CREATE  TABLE `patient_encounter_treatment_fields` (\n`id` INT NOT NULL AUTO_INCREMENT ,\n`user_id` INT NOT NULL ,\n`patient_encounter_id` INT NOT NULL ,\n`treatment_field_id` INT NOT NULL ,\n`treatment_field_value` VARCHAR(255) NOT NULL ,\nPRIMARY KEY (`id`) ,\nUNIQUE INDEX `id_UNIQUE` (`id` ASC) ,\nINDEX `fk_patient_encounter_treatment_fields_user_id_users_id_idx` (`user_id` ASC) ,\nINDEX `fk_patient_encounter_treatment_fields_patient_encounter_id_idx` (`patient_encounter_id` ASC) ,\nINDEX `fk_patient_encounter_treatment_fields_treatment_id_idx` (`treatment_field_id` ASC) ,\nCONSTRAINT `fk_patient_encounter_treatment_fields_user_id_users_id`\nFOREIGN KEY (`user_id` )\nREFERENCES `users` (`id` )\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nCONSTRAINT `fk_patient_encounter_treatment_fields_patient_encounter_id`\nFOREIGN KEY (`patient_encounter_id` )\nREFERENCES `patient_encounters` (`id` )\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nCONSTRAINT `fk_patient_encounter_treatment_fields_treatment_id`\nFOREIGN KEY (`treatment_field_id` )\nREFERENCES `treatment_fields` (`id` )\nON DELETE NO ACTION\nON UPDATE NO ACTION);','DROP TABLE IF EXISTS `patient_encounter_treatment_fields`','applied',''),(22,'46d161fd3ad8611600afa41a3dee9da5709b8ad4','2025-11-05 00:11:32','ALTER TABLE `patient_encounter_treatment_fields`\nADD COLUMN `date_taken` DATETIME NOT NULL\nAFTER `treatment_field_value` ;','ALTER TABLE `patient_encounter_treatment_fields`\nDROP COLUMN `date_taken` ;','applied',''),(23,'4537f73a36eff95bbdec063bbc23652a52dfa570','2025-11-05 00:11:32','ALTER TABLE `patient_encounter_hpi_fields`\nDROP FOREIGN KEY `fk_patient_encounter_hpi_fields_hpi_field_id_hpi_fields_id` ,\nDROP FOREIGN KEY `fk_patient_encounter_hpi_fields_patient_encounter_id` ,\nDROP FOREIGN KEY `fk_patient_encounter_hpi_fields_user_id_users_id` ;\nALTER TABLE `patient_encounter_hpi_fields`\nCHANGE COLUMN `user_id` `user_id` INT(11) NOT NULL  ,\nCHANGE COLUMN `patient_encounter_id` `patient_encounter_id` INT(11) NOT NULL  ,\nCHANGE COLUMN `hpi_field_id` `hpi_field_id` INT(11) NOT NULL  ,\nCHANGE COLUMN `hpi_field_value` `hpi_field_value` VARCHAR(255) NOT NULL  ,\nCHANGE COLUMN `date_taken` `date_taken` DATETIME NOT NULL  ,\nADD CONSTRAINT `fk_patient_encounter_hpi_fields_hpi_field_id_hpi_fields_id`\nFOREIGN KEY (`hpi_field_id` )\nREFERENCES `hpi_fields` (`id` )\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nADD CONSTRAINT `fk_patient_encounter_hpi_fields_patient_encounter_id`\nFOREIGN KEY (`patient_encounter_id` )\nREFERENCES `patient_encounters` (`id` )\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nADD CONSTRAINT `fk_patient_encounter_hpi_fields_user_id_users_id`\nFOREIGN KEY (`user_id` )\nREFERENCES `users` (`id` )\nON DELETE NO ACTION\nON UPDATE NO ACTION;','ALTER TABLE `patient_encounter_hpi_fields`\nDROP FOREIGN KEY `fk_patient_encounter_hpi_fields_hpi_field_id_hpi_fields_id` ,\nDROP FOREIGN KEY `fk_patient_encounter_hpi_fields_patient_encounter_id` ,\nDROP FOREIGN KEY `fk_patient_encounter_hpi_fields_user_id_users_id` ;\nALTER TABLE `patient_encounter_hpi_fields`\nCHANGE COLUMN `user_id` `user_id` INT(11) NULL  ,\nCHANGE COLUMN `patient_encounter_id` `patient_encounter_id` INT(11) NULL  ,\nCHANGE COLUMN `hpi_field_id` `hpi_field_id` INT(11) NULL  ,\nCHANGE COLUMN `hpi_field_value` `hpi_field_value` VARCHAR(255) NULL  ,\nCHANGE COLUMN `date_taken` `date_taken` DATETIME NULL  ,\nADD CONSTRAINT `fk_patient_encounter_hpi_fields_hpi_field_id_hpi_fields_id`\nFOREIGN KEY (`hpi_field_id` )\nREFERENCES `hpi_fields` (`id` )\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nADD CONSTRAINT `fk_patient_encounter_hpi_fields_patient_encounter_id`\nFOREIGN KEY (`patient_encounter_id` )\nREFERENCES `patient_encounters` (`id` )\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nADD CONSTRAINT `fk_patient_encounter_hpi_fields_user_id_users_id`\nFOREIGN KEY (`user_id` )\nREFERENCES `users` (`id` )\nON DELETE NO ACTION\nON UPDATE NO ACTION;','applied',''),(24,'49b36e3d2374ce7eb5b4b30ab6bb1909093ebc84','2025-11-05 00:11:32','INSERT INTO `treatment_fields` (`name`)\nVALUES (\'prescription\');','DELETE FROM `treatment_fields`\nWHERE `id`=\'5\';','applied',''),(25,'9c8f24033b0e22a9427e3c84a08f8e8c0f165a4d','2025-11-05 00:11:32','ALTER TABLE `patients`\nCHANGE COLUMN `age` `age`\nVARCHAR(255) NOT NULL  ;\n\nUPDATE `patients`\nSET age = \'9999/05/05\'\nWHERE age IS NOT NULL;\n\nALTER TABLE `patients`\nCHANGE COLUMN `age` `age`\nDATE NOT NULL;','ALTER TABLE `patients`\nCHANGE COLUMN `age` `age`\nVARCHAR(255) NOT NULL  ;\n\nUPDATE `patients`\nSET age = \'99\'\nWHERE age IS NOT NULL;\n\nALTER TABLE `patients`\nCHANGE COLUMN `age` `age`\nint(11) NOT NULL;','applied',''),(26,'5029bae2446cb6122c22ba3c7f96c42856a81a55','2025-11-05 00:11:33','INSERT INTO `roles` (`id`, `name`) VALUES (\'5\', \'Nurse\');','DELETE FROM `user_roles`\nWHERE role_id=5\nDELETE FROM `roles`\nWHERE name=\'Nurse\'','applied',''),(27,'a868af806f69fa51117df3a9ed687df7a4139048','2025-11-05 00:11:33','ALTER TABLE `patient_prescriptions`\nDROP FOREIGN KEY `fk_patient_prescriptions_medication_id_medications_id` ;\n\nALTER TABLE `patient_prescriptions`\nDROP COLUMN `medication_id` , CHANGE\nCOLUMN `amount` `amount`\nINT(11) NULL;\n\nALTER TABLE `patient_prescriptions`\nADD COLUMN `medication_name` VARCHAR(255) NOT NULL\nAFTER `replacement_id` ;','ALTER TABLE `patient_prescriptions`\nADD COLUMN `medication_id` INT(11) NOT NULL\nAFTER `replacement_id` ;\n\nALTER TABLE `patient_prescriptions`\nADD CONSTRAINT `fk_patient_prescriptions_medication_id_medications_id`\nFOREIGN KEY (`medication_id` )\nREFERENCES `medications` (`id` )\nON DELETE NO ACTION\nON UPDATE NO ACTION\n;\n\n\nALTER TABLE `patient_prescriptions`\nCHANGE COLUMN `amount` `amount`\nINT(11) NOT NULL  ;\n\nALTER TABLE `patient_prescriptions`\nDROP COLUMN `medication_name` ;','applied',''),(28,'d31c63b9038611e40e489239bc637a6d8e1ef0da','2025-11-05 00:11:33','DELETE FROM `patient_encounter_treatment_fields`\nWHERE `treatment_field_id` = \'5\';\n\nDELETE FROM `treatment_fields`\nWHERE `id`=\'5\';','INSERT INTO `treatment_fields` (`name`)\nVALUES (\'prescription\');','applied',''),(29,'ce4e46f393d479af5697d51352a01d391d9dc0c6','2025-11-05 00:11:33','ALTER TABLE `patient_encounters`\nADD COLUMN is_pregnant BOOL ;','ALTER TABLE `patient_encounters`\nDROP COLUMN is_pregnant;','applied',''),(30,'09a71506929bf4014289e9fbc3abf99da840b8b7','2025-11-05 00:11:33','ALTER TABLE `patient_encounter_hpi_fields`\nCHANGE COLUMN `hpi_field_value` `hpi_field_value` TEXT NOT NULL;','ALTER TABLE `patient_encounter_hpi_fields`\nCHANGE COLUMN `hpi_field_value` `hpi_field_value` VARCHAR(255) NOT NULL;','applied',''),(31,'62c2a808051a347f037ccbae6bc94a9bac911dd1','2025-11-05 00:11:33','ALTER TABLE `patient_encounter_treatment_fields`\nCHANGE COLUMN `treatment_field_value` `treatment_field_value` TEXT NOT NULL;\n\nALTER TABLE `patient_encounters`\nCHANGE COLUMN `chief_complaint` `chief_complaint` TEXT NULL DEFAULT NULL;','ALTER TABLE `patient_encounter_treatment_fields`\nCHANGE COLUMN `treatment_field_value` `treatment_field_value` VARCHAR(255) NOT NULL;\n\nALTER TABLE `femr`.`patient_encounters`\nCHANGE COLUMN `chief_complaint` `chief_complaint` VARCHAR(255) NULL DEFAULT NULL;','applied',''),(32,'432625c644b012247a93d8073471521d19607e03','2025-11-05 00:11:33','ALTER TABLE `patient_prescriptions`\nADD COLUMN `date_taken` DATETIME NOT NULL  AFTER `medication_name` ;\n\nUPDATE `patient_prescriptions`\nSET `date_taken` = \"0000-00-00 00:00:01\"\nWHERE `date_taken` IS NOT NULL;','ALTER TABLE `patient_prescriptions`\nDROP COLUMN `date_taken` ;','applied',''),(33,'4b35759c6558b6f1f80ee5483a4a1f20e13cf6a1','2025-11-05 00:11:33','INSERT INTO `vitals` (`id`, `name`, `data_type`, `unit_of_measurement`)\nVALUES (\'10\', \'glucose\', \'int\', \'mg/dl\');','DELETE FROM `patient_encounter_vitals`\nWHERE `vital_id` = 10;\n\nDELETE FROM `vitals`\nWHERE `id` =10;','applied',''),(34,'b384a60348cad179bc4d1f165892c32d3b1958f9','2025-11-05 00:11:33','INSERT INTO `hpi_fields` (`name`)\nVALUES (\'narrative\');','DELETE FROM `patient_encounter_hpi_fields`\nWHERE `hpi_field_id` = 10;\n\nDELETE FROM `hpi_fields`\nWHERE `id` = 10;','applied',''),(35,'67cb382e80f5625fbf03044bea672739541d3136','2025-11-05 00:11:34','CREATE  TABLE `pmh_fields` (\n`id` INT NOT NULL AUTO_INCREMENT ,\n`name` VARCHAR(255) NOT NULL ,\nPRIMARY KEY (`id`) ,\nUNIQUE INDEX `id_UNIQUE` (`id` ASC) );\n\nINSERT INTO `pmh_fields` (`name`) VALUES (\'medicalSurgicalHistory\');\nINSERT INTO `pmh_fields` (`name`) VALUES (\'socialHistory\');\nINSERT INTO `pmh_fields` (`name`) VALUES (\'currentMedication\');\nINSERT INTO `pmh_fields` (`name`) VALUES (\'familyHistory\');','DROP TABLE IF EXISTS `pmh_fields`;','applied',''),(36,'694867b590d56e00fe08392c3d90e3045c716127','2025-11-05 00:11:34','CREATE  TABLE `patient_encounter_pmh_fields` (\n`id` INT NOT NULL AUTO_INCREMENT ,\n`user_id` INT NULL ,\n`patient_encounter_id` INT NULL ,\n`pmh_field_id` INT NULL ,\n`pmh_field_value` VARCHAR(255) NULL ,\n`date_taken` DATETIME NULL ,\nPRIMARY KEY (`id`) ,\nUNIQUE INDEX `id_UNIQUE` (`id` ASC) ,\nINDEX `fk_patient_encounter_pmh_fields_user_id_users_id_idx` (`user_id` ASC) ,\nINDEX `fk_patient_encounter_pmh_field_id_pmh_fields_id_idx` (`pmh_field_id` ASC) ,\nINDEX `fk_patient_encounter_pmh_fields_patient_encounter_id_idx` (`patient_encounter_id` ASC) ,\nCONSTRAINT `fk_patient_encounter_pmh_fields_user_id_users_id`\nFOREIGN KEY (`user_id` )\nREFERENCES `users` (`id` )\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nCONSTRAINT `fk_patient_encounter_pmh_fields_pmh_field_id_pmh_fields_id`\nFOREIGN KEY (`pmh_field_id` )\nREFERENCES `pmh_fields` (`id` )\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nCONSTRAINT `fk_patient_encounter_pmh_fields_patient_encounter_id`\nFOREIGN KEY (`patient_encounter_id` )\nREFERENCES `patient_encounters` (`id` )\nON DELETE NO ACTION\nON UPDATE NO ACTION);','DROP TABLE IF EXISTS `patient_encounter_pmh_fields`;','applied',''),(37,'250388aba2193d8be976261601f40df0b6b2b911','2025-11-05 00:11:34','ALTER TABLE `patient_encounter_pmh_fields`\nDROP FOREIGN KEY `fk_patient_encounter_pmh_fields_pmh_field_id_pmh_fields_id` ,\nDROP FOREIGN KEY `fk_patient_encounter_pmh_fields_patient_encounter_id` ,\nDROP FOREIGN KEY `fk_patient_encounter_pmh_fields_user_id_users_id` ;\nALTER TABLE `patient_encounter_pmh_fields`\nCHANGE COLUMN `user_id` `user_id` INT(11) NOT NULL  ,\nCHANGE COLUMN `patient_encounter_id` `patient_encounter_id` INT(11) NOT NULL  ,\nCHANGE COLUMN `pmh_field_id` `pmh_field_id` INT(11) NOT NULL  ,\nCHANGE COLUMN `pmh_field_value` `pmh_field_value` VARCHAR(255) NOT NULL  ,\nCHANGE COLUMN `date_taken` `date_taken` DATETIME NOT NULL  ,\nADD CONSTRAINT `fk_patient_encounter_pmh_fields_pmh_field_id_pmh_fields_id`\nFOREIGN KEY (`pmh_field_id` )\nREFERENCES `pmh_fields` (`id` )\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nADD CONSTRAINT `fk_patient_encounter_pmh_fields_patient_encounter_id`\nFOREIGN KEY (`patient_encounter_id` )\nREFERENCES `patient_encounters` (`id` )\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nADD CONSTRAINT `fk_patient_encounter_pmh_fields_user_id_users_id`\nFOREIGN KEY (`user_id` )\nREFERENCES `users` (`id` )\nON DELETE NO ACTION\nON UPDATE NO ACTION;','ALTER TABLE `patient_encounter_pmh_fields`\nDROP FOREIGN KEY `fk_patient_encounter_pmh_fields_pmh_field_id_pmh_fields_id` ,\nDROP FOREIGN KEY `fk_patient_encounter_pmh_fields_patient_encounter_id` ,\nDROP FOREIGN KEY `fk_patient_encounter_pmh_fields_user_id_users_id` ;\nALTER TABLE `patient_encounter_pmh_fields`\nCHANGE COLUMN `user_id` `user_id` INT(11) NULL  ,\nCHANGE COLUMN `patient_encounter_id` `patient_encounter_id` INT(11) NULL  ,\nCHANGE COLUMN `pmh_field_id` `pmh_field_id` INT(11) NULL  ,\nCHANGE COLUMN `pmh_field_value` `pmh_field_value` VARCHAR(255) NULL  ,\nCHANGE COLUMN `date_taken` `date_taken` DATETIME NULL  ,\nADD CONSTRAINT `fk_patient_encounter_pmh_fields_pmh_field_id_pmh_fields_id`\nFOREIGN KEY (`pmh_field_id` )\nREFERENCES `pmh_fields` (`id` )\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nADD CONSTRAINT `fk_patient_encounter_pmh_fields_patient_encounter_id`\nFOREIGN KEY (`patient_encounter_id` )\nREFERENCES `patient_encounters` (`id` )\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nADD CONSTRAINT `fk_patient_encounter_pmh_fields_user_id_users_id`\nFOREIGN KEY (`user_id` )\nREFERENCES `users` (`id` )\nON DELETE NO ACTION\nON UPDATE NO ACTION;','applied',''),(38,'8c2d0c7d92e8bbc16e0ced881e3900eab1de612b','2025-11-05 00:11:34','ALTER TABLE `patient_encounter_pmh_fields`\nCHANGE COLUMN `pmh_field_value` `pmh_field_value` TEXT NOT NULL;','ALTER TABLE `patient_encounter_pmh_fields`\nCHANGE COLUMN `pmh_field_value` `pmh_field_value` VARCHAR(255) NOT NULL;','applied',''),(39,'df37fed9047198194755a2e2c9caac782b42642c','2025-11-05 00:11:34','DELETE `patient_encounter_hpi_fields` FROM `patient_encounter_hpi_fields`\nLEFT JOIN `hpi_fields`\nON `patient_encounter_hpi_fields`.`hpi_field_id` = `hpi_fields`.`id`\nWHERE `hpi_fields`.`name` = \"onsetTime\";\n\nDELETE FROM `hpi_fields`\nWHERE `name`=\"onsetTime\";\n\nDELETE `patient_encounter_treatment_fields` FROM `patient_encounter_treatment_fields`\nLEFT JOIN `treatment_fields`\nON `patient_encounter_treatment_fields`.`treatment_field_id` = `treatment_fields`.`id`\nWHERE `treatment_fields`.`name` = \"familyHistory\";\n\nDELETE FROM `treatment_fields`\nWHERE `name`=\"familyHistory\";','INSERT INTO `hpi_fields` (`name`) VALUES (\'onsetTime\');\n\nINSERT INTO `treatment_fields` (`name`) VALUES (\'familyHistory\');','applied',''),(40,'2bcca6e06214e9e43ab2f406a6f446a14563ac7a','2025-11-05 00:11:34','ALTER TABLE `users`\nADD COLUMN `last_login` DATETIME NOT NULL AFTER `password`;\n\nUPDATE `users`\nSET last_login = \'9999-01-01\'','ALTER TABLE `users`\nDROP COLUMN `last_login`;','applied',''),(41,'cb43cfd55490738209362e6d7aaf9104f19ba2b0','2025-11-05 00:11:34','ALTER TABLE `users`\nADD COLUMN `isDeleted` BIT(1) NOT NULL DEFAULT 0  AFTER `last_login` ;\n\nALTER TABLE `treatment_fields`\nADD COLUMN `isDeleted` BIT(1) NOT NULL DEFAULT 0  AFTER `name` ;\n\nALTER TABLE `vitals`\nADD COLUMN `isDeleted` BIT(1) NOT NULL DEFAULT 0  AFTER `unit_of_measurement` ;\n\nALTER TABLE `pmh_fields`\nADD COLUMN `isDeleted` BIT(1) NOT NULL DEFAULT 0  AFTER `name` ;\n\nALTER TABLE `hpi_fields`\nADD COLUMN `isDeleted` BIT(1) NOT NULL DEFAULT 0  AFTER `name` ;','ALTER TABLE `users`\nDROP COLUMN `isDeleted` ;\n\nALTER TABLE `treatment_fields`\nDROP COLUMN `isDeleted` ;\n\nALTER TABLE `vitals`\nDROP COLUMN `isDeleted` ;\n\nALTER TABLE `pmh_fields`\nDROP COLUMN `isDeleted` ;\n\nALTER TABLE `hpi_fields`\nDROP COLUMN `isDeleted` ;','applied',''),(42,'afcea4007d6c8cd84f3b1c416d5f5947e5c8731b','2025-11-05 00:11:34','CREATE TABLE `photos`\n(\nid INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT ,\ndescription VARCHAR(3072) NOT NULL,\nfile_path VARCHAR(1024) NOT NULL\n);\n\nCREATE TABLE `patient_encounter_photos`\n(\npatient_encounter_id INT(11) NOT NULL,\nphoto_id INT(11) NOT NULL,\nPRIMARY KEY (patient_encounter_id, photo_id)\n);\nCREATE UNIQUE INDEX id_photo_encntr_idx ON patient_encounter_photos ( photo_id );\nCREATE INDEX patient_encounter_photos_pci_idx ON `patient_encounter_photos`  ( patient_encounter_id);\n\nALTER TABLE `patients`\nADD COLUMN `photo_id` INT(11) NULL DEFAULT NULL  AFTER `city` ;\n\nCREATE INDEX patient_photo_id_idx ON `patients` ( photo_id );\n\n\nALTER TABLE `patients` ADD FOREIGN KEY ( photo_id ) REFERENCES photos ( id );\nALTER TABLE `patient_encounter_photos` ADD FOREIGN KEY ( patient_encounter_id ) REFERENCES patient_encounters ( id );\nALTER TABLE `patient_encounter_photos` ADD FOREIGN KEY ( photo_id ) REFERENCES photos ( id );\n\nALTER TABLE `photos`\nADD COLUMN `insertTS` TIMESTAMP DEFAULT CURRENT_TIMESTAMP;','DROP TABLE IF EXISTS `patient_encounter_photos`;\nDROP TABLE IF EXISTS `photos`;\nALTER TABLE `patients` DROP COLUMN `photo_id`;','applied',''),(43,'b2de2ceb7621bd3ea829520d0a44e67366ab7afa','2025-11-05 00:11:34','ALTER TABLE `users`\nADD COLUMN `isPasswordReset` BIT(1) NOT NULL DEFAULT 0 AFTER `isDeleted` ;','ALTER TABLE `users`\nDROP COLUMN `isPasswordReset` ;','applied',''),(44,'716cf93f03d10d8fa41b22b8731ffb724cf7b373','2025-11-05 00:11:34','INSERT INTO `roles` (`name`) VALUES (\'SuperUser\');','DELETE FROM `roles`\nWHERE `name` = \"SuperUser\";','applied',''),(45,'fa76c642ace9e71ca33b33d77ae6e5f111436759','2025-11-05 00:11:34','CREATE TABLE `custom_field_types` (\n`id` INT NOT NULL AUTO_INCREMENT,\n`name` VARCHAR(255) NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC),\nUNIQUE INDEX `name_UNIQUE` (`name` ASC));\n\nCREATE TABLE `custom_tabs` (\n`id` INT NOT NULL AUTO_INCREMENT,\n`name` VARCHAR(255) NOT NULL,\n`user_id` INT NOT NULL,\n`date_created` DATETIME NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC),\nINDEX `fk_custom_tabs_user_id_idx` (`user_id` ASC),\nCONSTRAINT `fk_custom_tabs_user_id`\nFOREIGN KEY (`user_id`)\nREFERENCES `users` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION);\n\nCREATE TABLE `custom_fields` (\n`id` INT NOT NULL AUTO_INCREMENT,\n`name` VARCHAR(255) NOT NULL,\n`user_id` INT NOT NULL,\n`date_created` DATETIME NOT NULL,\n`custom_tab_id` INT NOT NULL,\n`custom_type_id` INT NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC),\nINDEX `fk_custom_fields_custom_tab_id_idx` (`custom_tab_id` ASC),\nINDEX `fk_custom_fields_custom_type_id_idx` (`custom_type_id` ASC),\nINDEX `fk_custom_fields_user_id_idx` (`user_id` ASC),\nCONSTRAINT `fk_custom_fields_custom_tab_id`\nFOREIGN KEY (`custom_tab_id`)\nREFERENCES `custom_tabs` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nCONSTRAINT `fk_custom_fields_custom_type_id`\nFOREIGN KEY (`custom_type_id`)\nREFERENCES `custom_field_types` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nCONSTRAINT `fk_custom_fields_user_id`\nFOREIGN KEY (`user_id`)\nREFERENCES `users` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION);\n\nCREATE TABLE `patient_encounter_custom_fields` (\n`id` INT NOT NULL AUTO_INCREMENT,\n`user_id` INT NOT NULL,\n`patient_encounter_id` INT NOT NULL,\n`custom_field_id` INT NOT NULL,\n`custom_field_value` VARCHAR(255) NOT NULL,\n`date_taken` DATETIME NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC),\nINDEX `fk_patient_encounter_custom_fields_user_id_idx` (`user_id` ASC),\nINDEX `fk_patient_encounter_custom_fields_pe_id_idx` (`patient_encounter_id` ASC),\nINDEX `fk_patient_encounter_custom_fields_custom_field_id_idx` (`custom_field_id` ASC),\nCONSTRAINT `fk_patient_encounter_custom_fields_user_id`\nFOREIGN KEY (`user_id`)\nREFERENCES `users` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nCONSTRAINT `fk_patient_encounter_custom_fields_pe_id`\nFOREIGN KEY (`patient_encounter_id`)\nREFERENCES `patient_encounters` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nCONSTRAINT `fk_patient_encounter_custom_fields_custom_field_id`\nFOREIGN KEY (`custom_field_id`)\nREFERENCES `custom_fields` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION);','DROP TABLE `patient_encounter_custom_fields`;\nDROP TABLE `custom_fields`;\nDROP TABLE `custom_tabs`;\nDROP TABLE `custom_field_types`;','applied',''),(46,'bee230ee625c1989e7f62e143d09b3d363d32133','2025-11-05 00:11:35','ALTER TABLE `custom_tabs`\nADD COLUMN `isDeleted` BIT(1) NOT NULL DEFAULT 0 AFTER `date_created`,\nADD UNIQUE INDEX `name_UNIQUE` (`name` ASC);','ALTER TABLE `custom_tabs`\nDROP COLUMN `isDeleted`,\nDROP INDEX `name_UNIQUE` ;','applied',''),(47,'4ccd1d736b8ac6413fb0b719f371a53f90a23eba','2025-11-05 00:11:35','ALTER TABLE `custom_fields`\nADD COLUMN `isDeleted` BIT(1) NOT NULL DEFAULT 0 AFTER `custom_type_id`;','ALTER TABLE `custom_fields`\nDROP COLUMN `isDeleted`;','applied',''),(48,'b208f162b90eacd03b2eeebacfb096ead6bcef70','2025-11-05 00:11:35','CREATE TABLE `custom_field_sizes` (\n`id` INT NOT NULL AUTO_INCREMENT,\n`name` VARCHAR(255) NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC),\nUNIQUE INDEX `name_UNIQUE` (`name` ASC));\n\nALTER TABLE `custom_fields`\nADD COLUMN `custom_size_id` INT(11) NOT NULL AFTER `isDeleted`,\nADD INDEX `fk_custom_fields_custom_size_id_idx` (`custom_size_id` ASC);\nALTER TABLE `custom_fields`\nADD CONSTRAINT `fk_custom_fields_custom_size_id`\nFOREIGN KEY (`custom_size_id`)\nREFERENCES `custom_field_sizes` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;','ALTER TABLE `custom_fields`\nDROP FOREIGN KEY `fk_custom_fields_custom_size_id`;\n\nALTER TABLE `custom_fields`\nDROP INDEX `fk_custom_fields_custom_size_id_idx` ;\n\nALTER TABLE `custom_fields`\nDROP COLUMN `custom_size_id`;\n\nDROP TABLE `custom_field_sizes`;','applied',''),(49,'99303f10d061b9706ab791cd2e1669308bae9373','2025-11-05 00:11:35','ALTER TABLE `custom_fields`\nADD COLUMN `sort_order` INT NULL AFTER `custom_size_id`;','ALTER TABLE `custom_fields`\nDROP COLUMN `sort_order`;','applied',''),(50,'3f20cbb58b23b75edd0fdf2c41d66c3d891c5a3b','2025-11-05 00:11:35','ALTER TABLE `custom_fields`\nADD UNIQUE INDEX `order_UNIQUE` (`sort_order` ASC);','ALTER TABLE `custom_fields`\nDROP INDEX `sort_order_UNIQUE` ;','applied',''),(51,'60a901f1a5355b0f787ec286369c59aad91aaadc','2025-11-05 00:11:35','ALTER TABLE `custom_fields`\nADD UNIQUE INDEX `name_UNIQUE` (`name` ASC);','ALTER TABLE `custom_fields`\nDROP INDEX `name_UNIQUE` ;','applied',''),(52,'585665f6d4ba863e6d050ef4d5d526431d666d40','2025-11-05 00:11:35','ALTER TABLE `custom_fields`\nADD COLUMN `placeholder` VARCHAR(255) NULL AFTER `sort_order`;','ALTER TABLE `custom_fields`\nDROP COLUMN `placeholder`;','applied',''),(53,'fb3aa9d6c4b07e7afefb97474cf86e1b29e0b732','2025-11-05 00:11:35','ALTER TABLE `custom_tabs`\nADD COLUMN `left_column_size` INT NOT NULL DEFAULT 0 AFTER `isDeleted`,\nADD COLUMN `right_column_size` INT NOT NULL DEFAULT 0 AFTER `left_column_size`;','ALTER TABLE `custom_tabs`\nDROP COLUMN `right_column_size`,\nDROP COLUMN `left_column_size`;','applied',''),(54,'f5d937f0c06c272707f07168dd27377302a0cd41','2025-11-05 00:11:35','ALTER TABLE `custom_fields`\nDROP INDEX `order_UNIQUE` ;','ALTER TABLE `custom_fields`\nADD UNIQUE INDEX `sort_order_UNIQUE` (`sort_order` ASC);','applied',''),(55,'147c8395c3633d984f0906a693d2a8d07632ff36','2025-11-05 00:11:35','ALTER TABLE `medications`\nADD COLUMN `quantity_current` INT(255) NULL DEFAULT NULL AFTER `name`,\nADD COLUMN `quantity_initial` INT(255) NULL DEFAULT NULL AFTER `quantity_current`;\n\nALTER TABLE `medications`\nADD COLUMN `isDeleted` BIT(1) NULL DEFAULT 0 AFTER `quantity_initial` ,\nDROP INDEX `name_UNIQUE` ;\n\nALTER TABLE `patient_prescriptions`\nDROP COLUMN `reason`,\nDROP COLUMN `replaced`;\n\nALTER TABLE `patient_encounters`\nDROP COLUMN `is_pregnant`;\n\nALTER TABLE `patient_encounters`\nADD COLUMN `date_of_medical_visit` DATETIME NULL DEFAULT NULL AFTER `weeks_pregnant`,\nADD COLUMN `date_of_pharmacy_visit` DATETIME NULL AFTER `date_of_medical_visit`;\n\nUPDATE `patient_encounters`\nSET `date_of_medical_visit` = \"1000-01-01 00:00:00\"\nWHERE id is not null;\n\nUPDATE `patient_encounters`\nSET `date_of_pharmacy_visit` = \"1000-01-01 00:00:00\"\nWHERE id is not null;','ALTER TABLE `medications`\nDROP COLUMN `quantity_initial`,\nDROP COLUMN `quantity_current`;\n\nALTER TABLE `medications`\nDROP COLUMN `isDeleted`,\nADD UNIQUE INDEX `name_UNIQUE` (`name` ASC);\n\nALTER TABLE `patient_prescriptions`\nADD COLUMN `replaced` BIT(1) NULL AFTER `date_taken`;\n\nALTER TABLE `patient_encounters`\nADD COLUMN `is_pregnant` TINYINT(1) NULL DEFAULT NULL AFTER `weeks_pregnant`;\n\nALTER TABLE `patient_encounters`\nDROP COLUMN `date_of_pharmacy_visit`,\nDROP COLUMN `date_of_medical_visit`;','applied',''),(56,'6c3537e0a186b26eaef9b16de2f9fd89796c2065','2025-11-05 00:11:35','CREATE TABLE `tab_fields` (\n`id` INT NOT NULL AUTO_INCREMENT,\n`name` VARCHAR(255) NOT NULL,\n`isDeleted` BIT(1) NOT NULL DEFAULT b\'0\',\n`tab_id` INT(11) NULL DEFAULT NULL,\n`type_id` INT(11) NULL DEFAULT NULL,\n`size_id` INT(11) NULL DEFAULT NULL,\n`sort_order` INT(11) NULL DEFAULT NULL,\n`placeholder` VARCHAR(255) NULL DEFAULT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC));\n\nINSERT INTO tab_fields (`name`, `isDeleted`)\nSELECT `name`, `isDeleted`\nfrom hpi_fields;\n\nINSERT INTO tab_fields (`name`, `isDeleted`)\nSELECT `name`, `isDeleted`\nfrom treatment_fields;\n\nINSERT INTO tab_fields (`name`, `isDeleted`)\nSELECT `name`, `isDeleted`\nfrom pmh_fields;\n\nINSERT INTO tab_fields (`name`, `isDeleted`, `tab_id`, `type_id`, `size_id`, `sort_order`, `placeholder`)\nSELECT `name`, `isDeleted`, `custom_tab_id`, `custom_type_id`, `custom_size_id`, `sort_order`, `placeholder`\nfrom custom_fields;\n\n\nCREATE TABLE `patient_encounter_tab_fields`(\n`id` INT NOT NULL AUTO_INCREMENT,\n`user_id` INT(11) NOT NULL,\n`patient_encounter_id` INT(11) NOT NULL,\n`tab_field_id` INT(11) NOT NULL,\n`tab_field_value` TEXT NOT NULL,\n`date_taken` DATETIME NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE`(`id` ASC));\n\nINSERT INTO patient_encounter_tab_fields(`user_id`, `patient_encounter_id`, `tab_field_id`, `tab_field_value`, `date_taken`)\nSELECT pehf.`user_id`, pehf.`patient_encounter_id`, tf.`id`, pehf.`hpi_field_value`, pehf.`date_taken`\nFROM patient_encounter_hpi_fields pehf\nINNER JOIN `hpi_fields` hf ON pehf.`hpi_field_id` = hf.`id`\nINNER JOIN `tab_fields` tf ON hf.`name` = tf.`name`;\n\nINSERT INTO patient_encounter_tab_fields(`user_id`, `patient_encounter_id`, `tab_field_id`, `tab_field_value`, `date_taken`)\nSELECT pepf.`user_id`, pepf.`patient_encounter_id`, tf.`id`, pepf.`pmh_field_value`, pepf.`date_taken`\nFROM patient_encounter_pmh_fields pepf\nINNER JOIN `pmh_fields` pf ON pepf.`pmh_field_id` = pf.`id`\nINNER JOIN `tab_fields` tf ON pf.`name` = tf.`name`;\n\nINSERT INTO patient_encounter_tab_fields(`user_id`, `patient_encounter_id`, `tab_field_id`, `tab_field_value`, `date_taken`)\nSELECT petf.`user_id`, petf.`patient_encounter_id`, tf.`id`, petf.`treatment_field_value`, petf.`date_taken`\nFROM patient_encounter_treatment_fields petf\nINNER JOIN `treatment_fields` trtf ON petf.`treatment_field_id` = trtf.`id`\nINNER JOIN `tab_fields` tf ON trtf.`name` = tf.`name`;\n\nINSERT INTO patient_encounter_tab_fields(`user_id`, `patient_encounter_id`, `tab_field_id`, `tab_field_value`, `date_taken`)\nSELECT pecf.`user_id`, pecf.`patient_encounter_id`, tf.`id`, pecf.`custom_field_value`, pecf.`date_taken`\nFROM patient_encounter_custom_fields pecf\nINNER JOIN `custom_fields` cf ON pecf.`custom_field_id` = cf.`id`\nINNER JOIN `tab_fields` tf ON cf.`name` = tf.`name`;\n\n\nDROP TABLE `patient_encounter_hpi_fields`;\nDROP TABLE `patient_encounter_custom_fields`;\nDROP TABLE `patient_encounter_pmh_fields`;\nDROP TABLE `patient_encounter_treatment_fields`;\nDROP TABLE `hpi_fields`;\nDROP TABLE `custom_fields`;\nDROP TABLE `pmh_fields`;\nDROP TABLE `treatment_fields`;\n\nALTER TABLE `custom_field_sizes`\nRENAME TO  `tab_field_sizes` ;\nALTER TABLE `custom_field_types`\nRENAME TO  `tab_field_types` ;\nALTER TABLE `custom_tabs`\nRENAME TO  `tabs` ;\n\nALTER TABLE `patient_encounter_tab_fields`\nADD INDEX `fk_patient_encounter_tab_fields_user_idx` (`user_id` ASC),\nADD INDEX `fk_patient_encounter_tab_fields_patient_encounter_idx` (`patient_encounter_id` ASC),\nADD INDEX `fk_patient_encounter_tab_fields_tab_field_idx` (`tab_field_id` ASC);\nALTER TABLE `patient_encounter_tab_fields`\nADD CONSTRAINT `fk_patient_encounter_tab_fields_user`\nFOREIGN KEY (`user_id`)\nREFERENCES `users` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;\nALTER TABLE `patient_encounter_tab_fields`\nADD CONSTRAINT `fk_patient_encounter_tab_fields_patient_encounter`\nFOREIGN KEY (`patient_encounter_id`)\nREFERENCES `patient_encounters` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;\nALTER TABLE `patient_encounter_tab_fields`\nADD CONSTRAINT `fk_patient_encounter_tab_fields_tab_field`\nFOREIGN KEY (`tab_field_id`)\nREFERENCES `tab_fields` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;\n\nALTER TABLE `tab_fields`\nADD INDEX `fk_tab_fields_tab_idx` (`tab_id` ASC),\nADD INDEX `fk_tab_fields_type_idx` (`type_id` ASC),\nADD INDEX `fk_tab_fields_size_idx` (`size_id` ASC);\nALTER TABLE `tab_fields`\nADD CONSTRAINT `fk_tab_fields_tab`\nFOREIGN KEY (`tab_id`)\nREFERENCES `tabs` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nADD CONSTRAINT `fk_tab_fields_type`\nFOREIGN KEY (`type_id`)\nREFERENCES `tab_field_types` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nADD CONSTRAINT `fk_tab_fields_size`\nFOREIGN KEY (`size_id`)\nREFERENCES `tab_field_sizes` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;','# WARNING: THESE DOWNS ARE VERY DESTRUCTIVE - YOU WILL LOSE\n# ALL PATIENT ENCOUNTER FIELD DATA!!!!!!!!!!!!!\n\nALTER TABLE `tab_fields`\nDROP FOREIGN KEY `fk_tab_fields_size`,\nDROP FOREIGN KEY `fk_tab_fields_type`,\nDROP FOREIGN KEY `fk_tab_fields_tab`;\nALTER TABLE `tab_fields`\nDROP INDEX `fk_tab_fields_size_idx` ,\nDROP INDEX `fk_tab_fields_type_idx` ,\nDROP INDEX `fk_tab_fields_tab_idx` ;\n\nALTER TABLE `patient_encounter_tab_fields`\nDROP FOREIGN KEY `fk_patient_encounter_tab_fields_user`,\nDROP FOREIGN KEY `fk_patient_encounter_tab_fields_patient_encounter`,\nDROP FOREIGN KEY `fk_patient_encounter_tab_fields_tab_field`;\nALTER TABLE `patient_encounter_tab_fields`\nDROP INDEX `fk_patient_encounter_tab_fields_tab_field_idx` ,\nDROP INDEX `fk_patient_encounter_tab_fields_patient_encounter_idx` ,\nDROP INDEX `fk_patient_encounter_tab_fields_user_idx` ;\n\n\nALTER TABLE  `tab_field_sizes`\nRENAME TO `custom_field_sizes`;\nALTER TABLE  `tab_field_types`\nRENAME TO `custom_field_types`;\nALTER TABLE  `tabs`\nRENAME TO `custom_tabs`;\n\nCREATE TABLE `treatment_fields` (\n`id` int(11) NOT NULL AUTO_INCREMENT,\n`name` varchar(255) NOT NULL,\n`isDeleted` bit(1) NOT NULL DEFAULT b\'0\',\nPRIMARY KEY (`id`),\nUNIQUE KEY `id_UNIQUE` (`id`)\n) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;\n\nLOCK TABLES `treatment_fields` WRITE;\nINSERT INTO `treatment_fields` VALUES (1,\'assessment\',\'\\0\'),(2,\'problem\',\'\\0\'),(3,\'treatment\',\'\\0\');\nUNLOCK TABLES;\n\nCREATE TABLE `patient_encounter_treatment_fields` (\n`id` int(11) NOT NULL AUTO_INCREMENT,\n`user_id` int(11) NOT NULL,\n`patient_encounter_id` int(11) NOT NULL,\n`treatment_field_id` int(11) NOT NULL,\n`treatment_field_value` text NOT NULL,\n`date_taken` datetime NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE KEY `id_UNIQUE` (`id`),\nKEY `fk_patient_encounter_treatment_fields_user_id_users_id_idx` (`user_id`),\nKEY `fk_patient_encounter_treatment_fields_patient_encounter_id_idx` (`patient_encounter_id`),\nKEY `fk_patient_encounter_treatment_fields_treatment_id_idx` (`treatment_field_id`),\nCONSTRAINT `fk_patient_encounter_treatment_fields_patient_encounter_id` FOREIGN KEY (`patient_encounter_id`) REFERENCES `patient_encounters` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,\nCONSTRAINT `fk_patient_encounter_treatment_fields_treatment_id` FOREIGN KEY (`treatment_field_id`) REFERENCES `treatment_fields` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,\nCONSTRAINT `fk_patient_encounter_treatment_fields_user_id_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION\n) ENGINE=InnoDB DEFAULT CHARSET=latin1;\n\nCREATE TABLE `pmh_fields` (\n`id` int(11) NOT NULL AUTO_INCREMENT,\n`name` varchar(255) NOT NULL,\n`isDeleted` bit(1) NOT NULL DEFAULT b\'0\',\nPRIMARY KEY (`id`),\nUNIQUE KEY `id_UNIQUE` (`id`)\n) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;\n\nLOCK TABLES `pmh_fields` WRITE;\nINSERT INTO `pmh_fields` VALUES (1,\'medicalSurgicalHistory\',\'\\0\'),(2,\'socialHistory\',\'\\0\'),(3,\'currentMedication\',\'\\0\'),(4,\'familyHistory\',\'\\0\');\nUNLOCK TABLES;\n\nCREATE TABLE `patient_encounter_pmh_fields` (\n`id` int(11) NOT NULL AUTO_INCREMENT,\n`user_id` int(11) NOT NULL,\n`patient_encounter_id` int(11) NOT NULL,\n`pmh_field_id` int(11) NOT NULL,\n`pmh_field_value` text NOT NULL,\n`date_taken` datetime NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE KEY `id_UNIQUE` (`id`),\nKEY `fk_patient_encounter_pmh_fields_user_id_users_id_idx` (`user_id`),\nKEY `fk_patient_encounter_pmh_field_id_pmh_fields_id_idx` (`pmh_field_id`),\nKEY `fk_patient_encounter_pmh_fields_patient_encounter_id_idx` (`patient_encounter_id`),\nCONSTRAINT `fk_patient_encounter_pmh_fields_patient_encounter_id` FOREIGN KEY (`patient_encounter_id`) REFERENCES `patient_encounters` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,\nCONSTRAINT `fk_patient_encounter_pmh_fields_pmh_field_id_pmh_fields_id` FOREIGN KEY (`pmh_field_id`) REFERENCES `pmh_fields` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,\nCONSTRAINT `fk_patient_encounter_pmh_fields_user_id_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION\n) ENGINE=InnoDB DEFAULT CHARSET=latin1;\n\n\nCREATE TABLE `hpi_fields` (\n`id` int(11) NOT NULL AUTO_INCREMENT,\n`name` varchar(255) NOT NULL,\n`isDeleted` bit(1) NOT NULL DEFAULT b\'0\',\nPRIMARY KEY (`id`),\nUNIQUE KEY `id_UNIQUE` (`id`)\n) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;\n\n\nLOCK TABLES `hpi_fields` WRITE;\nINSERT INTO `hpi_fields` VALUES (1,\'onset\',\'\\0\'),(3,\'severity\',\'\\0\'),(4,\'radiation\',\'\\0\'),(5,\'quality\',\'\\0\'),(6,\'provokes\',\'\\0\'),(7,\'palliates\',\'\\0\'),(8,\'timeOfDay\',\'\\0\'),(9,\'physicalExamination\',\'\\0\'),(10,\'narrative\',\'\\0\');\nUNLOCK TABLES;\n\n\n\nCREATE TABLE `patient_encounter_hpi_fields` (\n`id` int(11) NOT NULL AUTO_INCREMENT,\n`user_id` int(11) NOT NULL,\n`patient_encounter_id` int(11) NOT NULL,\n`hpi_field_id` int(11) NOT NULL,\n`hpi_field_value` text NOT NULL,\n`date_taken` datetime NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE KEY `id_UNIQUE` (`id`),\nKEY `fk_patient_encounter_hpi_fields_user_id_users_id_idx` (`user_id`),\nKEY `fk_patient_encounter_hpi_field_id_hpi_fields_id_idx` (`hpi_field_id`),\nKEY `fk_patient_encounter_hpi_fields_patient_encounter_id_idx` (`patient_encounter_id`),\nCONSTRAINT `fk_patient_encounter_hpi_fields_hpi_field_id_hpi_fields_id` FOREIGN KEY (`hpi_field_id`) REFERENCES `hpi_fields` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,\nCONSTRAINT `fk_patient_encounter_hpi_fields_patient_encounter_id` FOREIGN KEY (`patient_encounter_id`) REFERENCES `patient_encounters` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,\nCONSTRAINT `fk_patient_encounter_hpi_fields_user_id_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION\n) ENGINE=InnoDB DEFAULT CHARSET=latin1;\n\n\n\n\n\nCREATE TABLE `custom_fields` (\n`id` int(11) NOT NULL AUTO_INCREMENT,\n`name` varchar(255) NOT NULL,\n`user_id` int(11) NOT NULL,\n`date_created` datetime NOT NULL,\n`custom_tab_id` int(11) NOT NULL,\n`custom_type_id` int(11) NOT NULL,\n`isDeleted` bit(1) NOT NULL DEFAULT b\'0\',\n`custom_size_id` int(11) NOT NULL,\n`sort_order` int(11) DEFAULT NULL,\n`placeholder` varchar(255) DEFAULT NULL,\nPRIMARY KEY (`id`),\nUNIQUE KEY `id_UNIQUE` (`id`),\nUNIQUE KEY `name_UNIQUE` (`name`),\nKEY `fk_custom_fields_custom_tab_id_idx` (`custom_tab_id`),\nKEY `fk_custom_fields_custom_type_id_idx` (`custom_type_id`),\nKEY `fk_custom_fields_user_id_idx` (`user_id`),\nKEY `fk_custom_fields_custom_size_id_idx` (`custom_size_id`),\nCONSTRAINT `fk_custom_fields_custom_size_id` FOREIGN KEY (`custom_size_id`) REFERENCES tab_field_sizes (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,\nCONSTRAINT `fk_custom_fields_custom_tab_id` FOREIGN KEY (`custom_tab_id`) REFERENCES `custom_tabs` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,\nCONSTRAINT `fk_custom_fields_custom_type_id` FOREIGN KEY (`custom_type_id`) REFERENCES `custom_field_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,\nCONSTRAINT `fk_custom_fields_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION\n) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;\n\n\nCREATE TABLE `patient_encounter_custom_fields` (\n`id` int(11) NOT NULL AUTO_INCREMENT,\n`user_id` int(11) NOT NULL,\n`patient_encounter_id` int(11) NOT NULL,\n`custom_field_id` int(11) NOT NULL,\n`custom_field_value` varchar(255) NOT NULL,\n`date_taken` datetime NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE KEY `id_UNIQUE` (`id`),\nKEY `fk_patient_encounter_custom_fields_user_id_idx` (`user_id`),\nKEY `fk_patient_encounter_custom_fields_pe_id_idx` (`patient_encounter_id`),\nKEY `fk_patient_encounter_custom_fields_custom_field_id_idx` (`custom_field_id`),\nCONSTRAINT `fk_patient_encounter_custom_fields_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,\nCONSTRAINT `fk_patient_encounter_custom_fields_pe_id` FOREIGN KEY (`patient_encounter_id`) REFERENCES `patient_encounters` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,\nCONSTRAINT `fk_patient_encounter_custom_fields_custom_field_id` FOREIGN KEY (`custom_field_id`) REFERENCES `custom_fields` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION\n) ENGINE=InnoDB DEFAULT CHARSET=latin1;\n\nINSERT INTO custom_fields(`name`, `user_id`, `date_created`, `custom_tab_id`, `custom_type_id`, `isDeleted`, `custom_size_id`, `sort_order`, `placeholder`)\nSELECT `name`, \'1\', \'1511-08-02\', `tab_id`, `type_id`, `isDeleted`, `size_id`, `sort_order`, `placeholder`\nFROM tab_fields\nWHERE `tab_id` IS NOT NULL;\n\n\nDROP TABLE `tab_fields`;\n\n\nDROP TABLE `patient_encounter_tab_fields`;','applied',''),(57,'93153ca25b1b47d20adc0fb5851d1978c93a20ea','2025-11-05 00:11:37','ALTER TABLE `patient_encounters`\nADD COLUMN `user_id_medical` INT(11) NULL DEFAULT NULL AFTER `date_of_pharmacy_visit`,\nADD COLUMN `user_id_pharmacy` INT(11) NULL DEFAULT NULL AFTER `user_id_medical`;\n\nALTER TABLE `patient_encounters`\nADD CONSTRAINT `fk_patient_encounter_user_id_users_id_doc`\nFOREIGN KEY (`user_id`)\nREFERENCES `users` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nADD CONSTRAINT `fk_patient_encounter_user_id_users_id_pharm`\nFOREIGN KEY (`user_id`)\nREFERENCES `users` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;','ALTER TABLE `patient_encounters`\nDROP COLUMN `user_id_pharmacy`,\nDROP COLUMN `user_id_medical`;\n\nALTER TABLE `patient_encounters`\nDROP FOREIGN KEY `fk_patient_encounter_user_id_users_id_pharm`,\nDROP FOREIGN KEY `fk_patient_encounter_user_id_users_id_doc`;','applied',''),(58,'5fd772012beb0dd59a705527968ef13dd9b90105','2025-11-05 00:11:37','#Create chief complaints table\nCREATE TABLE `chief_complaints` (\n`id` INT NOT NULL AUTO_INCREMENT,\n`value` TEXT NOT NULL,\n`patient_encounter_id` INT(11) NOT NULL,\nPRIMARY KEY (`id`),\nINDEX `fk_chief_complaints_patient_encounter_id_idx` (`patient_encounter_id` ASC),\nCONSTRAINT `fk_chief_complaints_patient_encounter_id`\nFOREIGN KEY (`patient_encounter_id`)\nREFERENCES `patient_encounters` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION);\n\n#Move chief complaints to their new home\nINSERT INTO `chief_complaints` (`value`, `patient_encounter_id`)\nSELECT pe.`chief_complaint`, pe.`id`\nFROM `patient_encounters` as pe\nWHERE pe.`chief_complaint` <> \'\';\n\n#Remove the column from the patient encounter table\nALTER TABLE `patient_encounters`\nDROP COLUMN `chief_complaint`;\n\n#Create a join table to track fields and chief complaints\nCREATE TABLE `patient_encounter_tab_field_chief_complaints` (\n`id` INT(11) NOT NULL AUTO_INCREMENT,\n`patient_encounter_tab_field_id` INT(11) NOT NULL,\n`chief_complaint_id` INT(11) NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC),\nINDEX `fk_patient_encounter_tab_field_petfid_idx` (`patient_encounter_tab_field_id` ASC),\nINDEX `fk_patient_encounter_tab_field_ccid_idx` (`chief_complaint_id` ASC),\nCONSTRAINT `fk_patient_encounter_tab_field_petfid`\nFOREIGN KEY (`patient_encounter_tab_field_id`)\nREFERENCES `patient_encounter_tab_fields` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nCONSTRAINT `fk_patient_encounter_tab_field_ccid`\nFOREIGN KEY (`chief_complaint_id`)\nREFERENCES `chief_complaints` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION);','#Add chief complaint field\nALTER TABLE `patient_encounters`\nADD COLUMN `chief_complaint` TEXT NULL;\n\n#Add chief complaint column\nUPDATE `patient_encounters` AS pe\nLEFT JOIN `chief_complaints` AS cc\nON pe.`id` = cc.`patient_encounter_id`\nSET pe.`chief_complaint` = cc.`value`;\n\n#Remove join table (destructive - won\'t get data back)\nDROP TABLE `patient_encounter_tab_field_chief_complaints`;\n\n#Remove chief complaint table\nDROP TABLE `chief_complaints`;','applied',''),(59,'6f654117f2135022e24af9bc8475a4edfbdbe5d4','2025-11-05 00:11:37','CREATE TABLE `system_settings` (\n`id` INT(11) NOT NULL AUTO_INCREMENT,\n`name` VARCHAR(255) NOT NULL,\n`isActive` BIT(1) NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC));','DROP TABLE `system_settings`;','applied',''),(60,'6a82820b64b4cca35a9b1a4ff0b09c62043efa85','2025-11-05 00:11:37','DROP TABLE `patient_encounter_tab_field_chief_complaints`;\n\nALTER TABLE `patient_encounter_tab_fields`\nADD COLUMN `chief_complaint_id` INT(11) NULL DEFAULT NULL AFTER `date_taken`,\nADD INDEX `fk_patient_encounter_tab_fields_chief_complaint_idx` (`chief_complaint_id` ASC);\nALTER TABLE `patient_encounter_tab_fields`\nADD CONSTRAINT `fk_patient_encounter_tab_fields_chief_complaint`\nFOREIGN KEY (`chief_complaint_id`)\nREFERENCES `chief_complaints` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;','#Create a join table to track fields and chief complaints\nCREATE TABLE `patient_encounter_tab_field_chief_complaints` (\n`id` INT(11) NOT NULL AUTO_INCREMENT,\n`patient_encounter_tab_field_id` INT(11) NOT NULL,\n`chief_complaint_id` INT(11) NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC),\nINDEX `fk_patient_encounter_tab_field_petfid_idx` (`patient_encounter_tab_field_id` ASC),\nINDEX `fk_patient_encounter_tab_field_ccid_idx` (`chief_complaint_id` ASC),\nCONSTRAINT `fk_patient_encounter_tab_field_petfid`\nFOREIGN KEY (`patient_encounter_tab_field_id`)\nREFERENCES `patient_encounter_tab_fields` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nCONSTRAINT `fk_patient_encounter_tab_field_ccid`\nFOREIGN KEY (`chief_complaint_id`)\nREFERENCES `chief_complaints` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION);\n\n\nUPDATE `patient_encounter_tab_fields`\nSET `chief_complaint_id` = null\nWHERE `chief_complaint_id` IS NOT NULL;\n\nALTER TABLE `patient_encounter_tab_fields`\nDROP FOREIGN KEY `fk_patient_encounter_tab_fields_chief_complaint`;\nALTER TABLE `patient_encounter_tab_fields`\nDROP COLUMN `chief_complaint_id`,\nDROP INDEX `fk_patient_encounter_tab_fields_chief_complaint_idx` ;','applied',''),(61,'fe6593ec092ce3b1905c4d865404050db9096599','2025-11-05 00:11:37','ALTER TABLE `patient_encounters`\nDROP FOREIGN KEY `fk_patient_encounter_user_id_users_id`,\nDROP FOREIGN KEY `fk_patient_encounter_user_id_users_id_doc`,\nDROP FOREIGN KEY `fk_patient_encounter_user_id_users_id_pharm`;\nALTER TABLE `patient_encounters`\nCHANGE COLUMN `user_id` `user_id_triage` INT(11) NOT NULL,\nCHANGE COLUMN `date_of_visit` `date_of_triage_visit` DATETIME NOT NULL;\nALTER TABLE `patient_encounters`\nADD CONSTRAINT `fk_patient_encounter_user_id_users_id`\nFOREIGN KEY (`user_id_triage`)\nREFERENCES `users` (`id`),\nADD CONSTRAINT `fk_patient_encounter_user_id_users_id_doc`\nFOREIGN KEY (`user_id_triage`)\nREFERENCES `users` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nADD CONSTRAINT `fk_patient_encounter_user_id_users_id_pharm`\nFOREIGN KEY (`user_id_triage`)\nREFERENCES `users` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;','ALTER TABLE `patient_encounters`\nDROP FOREIGN KEY `fk_patient_encounter_user_id_users_id`,\nDROP FOREIGN KEY `fk_patient_encounter_user_id_users_id_doc`,\nDROP FOREIGN KEY `fk_patient_encounter_user_id_users_id_pharm`;\nALTER TABLE `patient_encounters`\nCHANGE COLUMN `user_id_triage` `user_id` INT(11) NOT NULL,\nCHANGE COLUMN `date_of_triage_visit` `date_of_visit` DATETIME NOT NULL;\nALTER TABLE `patient_encounters`\nADD CONSTRAINT `fk_patient_encounter_user_id_users_id`\nFOREIGN KEY (`user_id`)\nREFERENCES `users` (`id`),\nADD CONSTRAINT `fk_patient_encounter_user_id_users_id_doc`\nFOREIGN KEY (`user_id`)\nREFERENCES `users` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nADD CONSTRAINT `fk_patient_encounter_user_id_users_id_pharm`\nFOREIGN KEY (`user_id`)\nREFERENCES `users` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;','applied',''),(62,'5a8aa0ed9e700496e54a1a43fec1b23661cc91c6','2025-11-05 00:11:37','ALTER TABLE `tabs`\nDROP FOREIGN KEY `fk_custom_tabs_user_id`;\nALTER TABLE `tabs`\nCHANGE COLUMN `user_id` `user_id` INT(11) NULL ;\nALTER TABLE `tabs`\nADD CONSTRAINT `fk_custom_tabs_user_id`\nFOREIGN KEY (`user_id`)\nREFERENCES `users` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;\n\nDELETE FROM `tab_fields`;\n\nALTER TABLE `tabs`\nADD COLUMN `isCustom` BIT(1) NOT NULL AFTER `right_column_size`;\n\nALTER TABLE `tab_fields`\nDROP FOREIGN KEY `fk_tab_fields_tab`;\nALTER TABLE `tab_fields`\nCHANGE COLUMN `tab_id` `tab_id` INT(11) NOT NULL ;\nALTER TABLE `tab_fields`\nADD CONSTRAINT `fk_tab_fields_tab`\nFOREIGN KEY (`tab_id`)\nREFERENCES `tabs` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;','ALTER TABLE `tabs`\nDROP FOREIGN KEY `fk_custom_tabs_user_id`;\nALTER TABLE `tabs`\nCHANGE COLUMN `user_id` `user_id` INT(11) NOT NULL ;\nALTER TABLE `tabs`\nADD CONSTRAINT `fk_custom_tabs_user_id`\nFOREIGN KEY (`user_id`)\nREFERENCES `users` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;\n\nALTER TABLE `tabs`\nDROP COLUMN `isCustom`;\n\nALTER TABLE `tab_fields`\nDROP FOREIGN KEY `fk_tab_fields_tab`;\nALTER TABLE `tab_fields`\nCHANGE COLUMN `tab_id` `tab_id` INT(11) NULL ;\nALTER TABLE `tab_fields`\nADD CONSTRAINT `fk_tab_fields_tab`\nFOREIGN KEY (`tab_id`)\nREFERENCES `tabs` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;','applied',''),(63,'fe3d7ed8980af6957e6029f6bf2549cde3873104','2025-11-05 00:11:38','CREATE TABLE `medication_forms` (\n`id`        INT UNSIGNED NOT NULL AUTO_INCREMENT,\n`form_name` VARCHAR(45)  NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC),\nUNIQUE INDEX `form_name_UNIQUE` (`form_name` ASC));\n\nALTER TABLE `medications`\nADD COLUMN `medication_forms_id` INT(11) UNSIGNED NULL DEFAULT NULL\nAFTER `isDeleted`,\nADD INDEX `fk_medications_medication_forms_idx` (`medication_forms_id` ASC);\nALTER TABLE `medications`\nADD CONSTRAINT `fk_medications_medication_forms`\nFOREIGN KEY (`medication_forms_id`)\nREFERENCES `medication_forms` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;\n\nCREATE TABLE `medication_active_drugs` (\n`id`                              INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,\n`medication_measurement_units_id` INT(11)          NOT NULL,\n`medication_active_drug_names_id` INT(11)          NOT NULL,\n`isDenominator`                   BIT(1)           NOT NULL,\n`value`                           INT(11)          NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC));\n\nCREATE TABLE `medication_medication_active_drugs` (\n`id`                         INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,\n`medications_id`             INT(11)          NOT NULL,\n`medication_active_drugs_id` INT(11) UNSIGNED NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC),\nINDEX `fk_medication_medication_active_drugs_medication_active_dru_idx` (`medication_active_drugs_id` ASC),\nINDEX `fk_medication_medication_active_drugs_medications_idx` (`medications_id` ASC),\nCONSTRAINT `fk_medication_medication_active_drugs_medications`\nFOREIGN KEY (`medications_id`)\nREFERENCES `medications` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nCONSTRAINT `fk_medication_medication_active_drugs_medication_active_drugs`\nFOREIGN KEY (`medication_active_drugs_id`)\nREFERENCES `medication_active_drugs` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION);\n\nCREATE TABLE `medication_measurement_units` (\n`id`        INT UNSIGNED NOT NULL AUTO_INCREMENT,\n`unit_name` VARCHAR(45)  NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC),\nUNIQUE INDEX `unit_name_UNIQUE` (`unit_name` ASC));\n\nCREATE TABLE `medication_active_drug_names` (\n`id`   INT UNSIGNED NOT NULL AUTO_INCREMENT,\n`name` VARCHAR(45)  NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC),\nUNIQUE INDEX `name_UNIQUE` (`name` ASC));\n\nALTER TABLE `medication_active_drugs`\nCHANGE COLUMN `medication_measurement_units_id` `medication_measurement_units_id` INT(11) UNSIGNED NOT NULL,\nCHANGE COLUMN `medication_active_drug_names_id` `medication_active_drug_names_id` INT(11) UNSIGNED NOT NULL,\nADD INDEX `fk_medication_active_drugs_medication_measurement_units_idx` (`medication_measurement_units_id` ASC),\nADD INDEX `fk_medication_active_drugs_medication_active_drug_names_idx` (`medication_active_drug_names_id` ASC);\nALTER TABLE `medication_active_drugs`\nADD CONSTRAINT `fk_medication_active_drugs_medication_measurement_units`\nFOREIGN KEY (`medication_measurement_units_id`)\nREFERENCES `medication_measurement_units` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nADD CONSTRAINT `fk_medication_active_drugs_medication_active_drug_names`\nFOREIGN KEY (`medication_active_drug_names_id`)\nREFERENCES `medication_active_drug_names` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;','ALTER TABLE `medications`\nDROP FOREIGN KEY `fk_medications_medication_forms`;\n\nDROP TABLE `medication_forms`;\n\nALTER TABLE `medications`\nDROP COLUMN `medication_forms_id`,\nDROP INDEX `fk_medications_medication_forms_idx` ;\n\nALTER TABLE `medication_medication_active_drugs`\nDROP FOREIGN KEY `fk_medication_medication_active_drugs_medication_active_drugs`,\nDROP FOREIGN KEY `fk_medication_medication_active_drugs_medications`;\n\nDROP TABLE `medication_medication_active_drugs`;\n\nALTER TABLE `medication_active_drugs`\nDROP FOREIGN KEY `fk_medication_active_drugs_medication_active_drug_names`,\nDROP FOREIGN KEY `fk_medication_active_drugs_medication_measurement_units`;\n\nDROP TABLE `medication_active_drugs`;\n\nDROP TABLE `medication_active_drug_names`;\n\nDROP TABLE `medication_measurement_units`;','applied',''),(64,'ae68d483ab23a879e12b30a58b166fcd7e3b85c6','2025-11-05 00:11:38','ALTER TABLE `patient_prescriptions`\nCHANGE COLUMN `replacement_id` `replacement_id` INT(11) NULL DEFAULT NULL AFTER `date_taken`,\nADD COLUMN `special_instructions` TEXT NULL DEFAULT NULL AFTER `medication_name`;\n\nALTER TABLE `patient_prescriptions`\nADD COLUMN `medication_id` INT(11) NULL AFTER `encounter_id`;\n\nALTER TABLE `patient_prescriptions`\nADD INDEX `fk_patient_prescriptions_medications_idx` (`medication_id` ASC);\nALTER TABLE `patient_prescriptions`\nADD CONSTRAINT `fk_patient_prescriptions_medications`\nFOREIGN KEY (`medication_id`)\nREFERENCES `medications` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;\n\nINSERT INTO `medications` (`name`)\nSELECT `medication_name`\nFROM `patient_prescriptions`;\n\nUPDATE `patient_prescriptions` as pp\nJOIN `medications` as m ON pp.`medication_name` = m.`name`\nSET pp.`medication_id` = m.`id`;\n\nALTER TABLE `patient_prescriptions`\nDROP COLUMN `medication_name`,\nCHANGE COLUMN `medication_id` `medication_id` INT(11) NOT NULL ;\n\nCREATE TABLE `medication_administrations` (\n`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,\n`name` VARCHAR(255) NOT NULL,\nPRIMARY KEY (`id`));\n\nALTER TABLE `patient_prescriptions`\nADD COLUMN `medication_administrations_id` INT(11) NULL AFTER `medication_id`;\n\nALTER TABLE `patient_prescriptions`\nCHANGE COLUMN `medication_administrations_id` `medication_administrations_id` INT(11) UNSIGNED NULL DEFAULT NULL ,\nADD INDEX `fk_patient_prescriptions_medication_administrations_idx` (`medication_administrations_id` ASC);\nALTER TABLE `patient_prescriptions`\nADD CONSTRAINT `fk_patient_prescriptions_medication_administrations`\nFOREIGN KEY (`medication_administrations_id`)\nREFERENCES `medication_administrations` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;','ALTER TABLE `patient_prescriptions`\nADD COLUMN `medication_name` VARCHAR(255) NOT NULL AFTER `replacement_id`;\n\nUPDATE `patient_prescriptions` as pp\nJOIN `medications` as m ON pp.`medication_id` = m.`id`\nSET pp.`medication_name` = m.`name`;\n\nALTER TABLE `patient_prescriptions`\nDROP FOREIGN KEY `fk_patient_prescriptions_medication_administrations`;\nALTER TABLE `patient_prescriptions`\nDROP INDEX `fk_patient_prescriptions_medication_administrations_idx`;\n\nDROP TABLE `medication_administrations`;\n\nALTER TABLE `patient_prescriptions`\nDROP FOREIGN KEY `fk_patient_prescriptions_medications`;\n\nALTER TABLE `patient_prescriptions`\nDROP COLUMN `medication_id`;\n\nALTER TABLE `patient_prescriptions`\nDROP COLUMN `medication_administrations_id`;\n\nALTER TABLE `patient_prescriptions`\nDROP COLUMN `special_instructions`;','applied',''),(65,'f9ac19efbf8fa9bb2b6fb5bd12d0b505c668ae81','2025-11-05 00:11:39','ALTER TABLE `users`\nADD COLUMN `notes` VARCHAR(255) NULL DEFAULT NULL AFTER `isPasswordReset`;','ALTER TABLE `users`\nDROP COLUMN `notes`;','applied',''),(66,'0cb593ec9e661054e67df1e36c03c5bc5c877585','2025-11-05 00:11:39','ALTER TABLE `medication_forms`\nCHANGE COLUMN `form_name` `name` VARCHAR(45) NOT NULL ,\nADD COLUMN `description` VARCHAR(45) NULL DEFAULT NULL AFTER `name`,\nADD COLUMN `isDeleted` BIT(1) NULL DEFAULT 0 AFTER `description`;','ALTER TABLE `medication_forms`\nDROP COLUMN `isDeleted`,\nDROP COLUMN `description`,\nCHANGE COLUMN `name` `form_name` VARCHAR(45) NOT NULL ;','applied',''),(67,'42f5a7519689171db70def2e7dd15a65b2f0d051','2025-11-05 00:11:39','ALTER TABLE `medication_measurement_units`\nCHANGE COLUMN `unit_name` `name` VARCHAR(45) NOT NULL ,\nADD COLUMN `description` VARCHAR(45) NULL DEFAULT NULL AFTER `name`,\nADD COLUMN `isDeleted` BIT(1) NULL DEFAULT 0 AFTER `description`;','ALTER TABLE `medication_measurement_units`\nDROP COLUMN `isDeleted`,\nDROP COLUMN `description`,\nCHANGE COLUMN `name` `unit_name` VARCHAR(45) NOT NULL ;','applied',''),(68,'f8ade25bfaf013abbc8b1427f22662f8fcc721ad','2025-11-05 00:11:39','CREATE TABLE `patient_age_classifications` (\n`id` INT NOT NULL AUTO_INCREMENT,\n`name` VARCHAR(45) NOT NULL,\n`description` VARCHAR(255) NULL DEFAULT NULL,\n`isDeleted` BIT(1) NOT NULL DEFAULT 0,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC),\nUNIQUE INDEX `name_UNIQUE` (`name` ASC),\nUNIQUE INDEX `description_UNIQUE` (`description` ASC));\n\nALTER TABLE `patient_encounters`\nADD COLUMN `patient_age_classification_id` INT(11) NULL AFTER `user_id_pharmacy`,\nADD INDEX `fk_patient_encounter_patient_age_classification_id_idx` (`patient_age_classification_id` ASC);\nALTER TABLE `patient_encounters`\nADD CONSTRAINT `fk_patient_encounter_patient_age_classification_id`\nFOREIGN KEY (`patient_age_classification_id`)\nREFERENCES `patient_age_classifications` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;\n\nALTER TABLE `patients`\nCHANGE COLUMN `age` `age` DATE NULL ;','ALTER TABLE `patient_encounters`\nDROP FOREIGN KEY `fk_patient_encounter_patient_age_classification_id`;\nALTER TABLE `patient_encounters`\nDROP COLUMN `patient_age_classification_id`,\nDROP INDEX `fk_patient_encounter_patient_age_classification_id_idx` ;\n\nDROP TABLE `patient_age_classifications`;\n\nALTER TABLE `patients`\nCHANGE COLUMN `age` `age` DATE NOT NULL ;','applied',''),(69,'8b86a066d2210d528bdf9e26e36a752a3408cf86','2025-11-05 00:11:39','ALTER TABLE `patient_encounters`\nDROP FOREIGN KEY `fk_patient_encounter_patient_age_classification_id`;\n\nALTER TABLE `patient_age_classifications`\nCHANGE COLUMN `id` `id` INT(11) NOT NULL ,\nADD COLUMN `sortOrder` INT NOT NULL AUTO_INCREMENT AFTER `isDeleted`,\nADD UNIQUE INDEX `sortOrder_UNIQUE` (`sortOrder` ASC);\n\nALTER TABLE `patient_encounters`\nADD CONSTRAINT `fk_patient_encounter_patient_age_classification_id`\nFOREIGN KEY (`patient_age_classification_id`)\nREFERENCES `patient_age_classifications` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;','ALTER TABLE `patient_age_classifications`\nDROP COLUMN `sortOrder`,\nDROP INDEX `sortOrder_UNIQUE` ;','applied',''),(70,'e553b066b1f95829e334a30cb5f1dda33d7358e5','2025-11-05 00:11:39','ALTER TABLE `patient_encounters`\nDROP FOREIGN KEY `fk_patient_encounter_patient_age_classification_id`;\n\nALTER TABLE `patient_age_classifications`\nCHANGE COLUMN `id` `id` INT(11) NOT NULL AUTO_INCREMENT ,\nCHANGE COLUMN `sortOrder` `sortOrder` INT(11) NOT NULL ;\n\nALTER TABLE `patient_encounters`\nADD CONSTRAINT `fk_patient_encounter_patient_age_classification_id`\nFOREIGN KEY (`patient_age_classification_id`)\nREFERENCES `patient_age_classifications` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;','ALTER TABLE `patient_age_classifications`\nCHANGE COLUMN `id` `id` INT(11) NOT NULL ,\nCHANGE COLUMN `sortOrder` `sortOrder` INT(11) NOT NULL AUTO_INCREMENT ;','applied',''),(71,'085ee2e419daf9faaea5c878901927ae7dfa4e2f','2025-11-05 00:11:40','ALTER TABLE `patient_prescriptions`\nADD COLUMN `isCounseled` BIT(1) NOT NULL AFTER `special_instructions`;\n\nALTER TABLE `patient_prescriptions`\nCHANGE COLUMN `isCounseled` `isCounseled` BIT(1) NOT NULL DEFAULT false ,\nADD COLUMN `isDispensed` BIT(1) NOT NULL DEFAULT false AFTER `isCounseled`;\n\nCREATE TABLE `mission_cities` (\n`id` INT NOT NULL AUTO_INCREMENT,\n`name` VARCHAR(255) NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC));\n\nCREATE TABLE `mission_countries` (\n`id` INT NOT NULL AUTO_INCREMENT,\n`name` VARCHAR(255) NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC));\n\nCREATE TABLE `mission_teams` (\n`id` INT NOT NULL AUTO_INCREMENT,\n`name` VARCHAR(255) NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC));\n\nALTER TABLE `mission_teams`\nADD COLUMN `location` VARCHAR(255) NULL DEFAULT NULL AFTER `name`;\n\nALTER TABLE `mission_teams`\nADD COLUMN `description` VARCHAR(255) NULL DEFAULT NULL AFTER `name`;\n\nALTER TABLE `mission_cities`\nCHANGE COLUMN `id` `id` INT(10) NOT NULL AUTO_INCREMENT ,\nADD COLUMN `mission_country_id` INT(10) NOT NULL AFTER `name`,\nADD INDEX `fk_mission_cities_1_idx` (`mission_country_id` ASC);\nALTER TABLE `mission_cities`\nADD CONSTRAINT `fk_mission_cities_1`\nFOREIGN KEY (`mission_country_id`)\nREFERENCES `mission_countries` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;\n\nCREATE TABLE `mission_trips` (\n`id` INT NOT NULL AUTO_INCREMENT,\n`mission_team_id` INT NOT NULL,\n`mission_city_id` INT NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC),\nINDEX `fk_mission_trips_mission_team_idx` (`mission_team_id` ASC),\nINDEX `fk_mission_trips_mission_city_idx` (`mission_city_id` ASC),\nCONSTRAINT `fk_mission_trips_mission_team`\nFOREIGN KEY (`mission_team_id`)\nREFERENCES `mission_teams` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nCONSTRAINT `fk_mission_trips_mission_city`\nFOREIGN KEY (`mission_city_id`)\nREFERENCES `mission_cities` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION);\n\nALTER TABLE `patient_encounters`\nADD COLUMN `mission_trip_id` INT(11) NULL AFTER `patient_age_classification_id`,\nADD INDEX `fk_patient_encounters_id_mission_trip_id_idx` (`mission_trip_id` ASC);\n\nALTER TABLE `patient_encounters`\nADD CONSTRAINT `fk_patient_encounters_id_mission_trip_id`\nFOREIGN KEY (`mission_trip_id`)\nREFERENCES `mission_trips` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;\n\nALTER TABLE `mission_trips`\nADD COLUMN `isCurrent` BIT(1) NOT NULL DEFAULT FALSE AFTER `mission_city_id`;\n\nALTER TABLE `mission_trips`\nADD COLUMN `start_date` DATE NOT NULL AFTER `isCurrent`,\nADD COLUMN `end_date` DATE NOT NULL AFTER `start_date`;','ALTER TABLE `patient_prescriptions`\nDROP COLUMN `isCounseled`;\n\nALTER TABLE `patient_prescriptions`\nDROP COLUMN `isDispensed`;\n\nALTER TABLE `patient_encounters`\nDROP FOREIGN KEY `fk_patient_encounters_id_mission_trip_id`;\n\nALTER TABLE `patient_encounters`\nDROP COLUMN `mission_trip_id`,\nDROP INDEX `fk_patient_encounters_id_mission_trip_id_idx` ;\n\nDROP TABLE `mission_trips`;\n\nDROP TABLE `mission_cities`;\n\nDROP TABLE `mission_countries`;\n\nDROP TABLE `mission_teams`;','applied',''),(72,'17ad5a28d57176c08b4080e263a94163dc1b5764','2025-11-05 00:11:40','CREATE TABLE `diagnoses` (\n`id` INT NOT NULL,\n`name` VARCHAR(255) NOT NULL,\nPRIMARY KEY (`id`));\n\nALTER TABLE `diagnoses`\nCHANGE COLUMN `id` `id` INT(11) NOT NULL AUTO_INCREMENT ;','DROP TABLE `diagnoses`;','applied',''),(73,'8c1b65d9c21a9f5c44c540f2d229e84919ba40dd','2025-11-05 00:11:40','ALTER TABLE `users`\nCHANGE COLUMN `last_login` `last_login` DATETIME NULL;\n\nALTER TABLE `chief_complaints`\nADD COLUMN `sort_order` INT NULL AFTER `patient_encounter_id`;','UPDATE `users`	SET `last_login` = now() WHERE `last_login` is NULL;\n\nALTER TABLE `users`\nCHANGE COLUMN `last_login` `last_login` DATETIME NOT NULL;\n\nALTER TABLE `chief_complaints`\nDROP COLUMN `sort_order`;','applied',''),(74,'7102939778dcb692d2c8afbd81c319da7f64a473','2025-11-05 00:11:40','SET @code=0;\nUPDATE chief_complaints\nSET sort_order = (SELECT @code:=@code+1 AS code);','UPDATE chief_complaints\nSET sort_order = NULL;','applied',''),(75,'b9650f4086b3d9283c27ad61d7230e644d839f59','2025-11-05 00:11:40','CREATE TABLE `login_attempts` (\n`id` INT(11) NOT NULL AUTO_INCREMENT,\n`user_id` INT(11) NULL,\n`ip_address` BINARY(16) NOT NULL,\n`date` DATETIME NOT NULL,\n`isSuccessful` BIT(1) NOT NULL,\n`username_attempt` VARCHAR(255) NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC),\nCONSTRAINT `login_attempts_user_id_users_id`\nFOREIGN KEY (`id`)\nREFERENCES `users` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION);\n\nALTER TABLE `medication_administrations` ADD `daily_modifier` DECIMAL(5, 2) NOT NULL;\n\nALTER TABLE `patient_prescriptions`\nDROP FOREIGN KEY `fk_patient_prescriptions_medication_administrations`;\n\nALTER TABLE `medication_administrations`\nCHANGE COLUMN `id` `id` INT(11) NOT NULL AUTO_INCREMENT ,\nADD UNIQUE INDEX `id_UNIQUE` (`id` ASC);\n\nALTER TABLE `patient_prescriptions`\nCHANGE COLUMN `medication_administrations_id` `medication_administrations_id` INT(11) NULL DEFAULT NULL ;\n\nALTER TABLE `patient_prescriptions`\nADD CONSTRAINT `fk_patient_prescriptions_medication_administrations`\nFOREIGN KEY (`medication_administrations_id`)\nREFERENCES `medication_administrations` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;\n\nALTER TABLE `patient_encounters`\nADD COLUMN `user_id_diabetes_screen` INT(11) NULL DEFAULT NULL,\nADD COLUMN `date_of_diabetes_screen` DATETIME NULL DEFAULT NULL,\nADD INDEX `fk_patient_encounters_user_id_users_id_diabetes_idx` (`user_id_diabetes_screen` ASC);\nALTER TABLE `patient_encounters`\nADD CONSTRAINT `fk_patient_encounters_user_id_users_id_diabetes`\nFOREIGN KEY (`user_id_diabetes_screen`)\nREFERENCES `users` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;','DROP TABLE `login_attempts`;\n\nALTER TABLE `medication_administrations` DROP COLUMN `daily_modifier`;\n\nALTER TABLE `patient_prescriptions`\nDROP FOREIGN KEY `fk_patient_prescriptions_medication_administrations`;\n\nALTER TABLE `medication_administrations`\nCHANGE COLUMN `id` `id` INT(10) UNSIGNED NOT NULL ,\nDROP INDEX `id_UNIQUE` ;\n\nALTER TABLE `patient_prescriptions`\nCHANGE COLUMN `medication_administrations_id` `medication_administrations_id` INT(11) UNSIGNED NULL ;\n\n\nALTER TABLE `patient_prescriptions`\nADD CONSTRAINT `fk_patient_prescriptions_medication_administrations`\nFOREIGN KEY (`medication_administrations_id`)\nREFERENCES `medication_administrations` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;\n\nALTER TABLE `patient_encounters`\nDROP FOREIGN KEY `fk_patient_encounters_user_id_users_id_diabetes`;\nALTER TABLE `patient_encounters`\nDROP COLUMN `date_of_diabetes_screen`,\nDROP COLUMN `user_id_diabetes_screen`,\nDROP INDEX `fk_patient_encounters_user_id_users_id_diabetes_idx` ;','applied',''),(76,'6d73f75c3154a6d6bc115a507ab0ce881f33b686','2025-11-05 00:11:41','ALTER TABLE `login_attempts`\nCHANGE COLUMN `date` `date_of_attempt` DATETIME NOT NULL ;','ALTER TABLE `login_attempts`\nCHANGE COLUMN `date_of_attempt` `date` DATETIME NOT NULL ;','applied',''),(77,'f7e2f9858502683349a54436e26c952663452f28','2025-11-05 00:11:41','ALTER TABLE `login_attempts`\nDROP FOREIGN KEY `login_attempts_user_id_users_id`;\nALTER TABLE `login_attempts`\nADD INDEX `login_attempts_user_id_users_id_idx` (`user_id` ASC);\nALTER TABLE `login_attempts`\nADD CONSTRAINT `login_attempts_user_id_users_id`\nFOREIGN KEY (`user_id`)\nREFERENCES `users` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;','','applied',''),(78,'433ddb4f17b3675d131585048ca616c57258ab30','2025-11-05 00:11:41','ALTER TABLE `medications`\nDROP COLUMN `quantity_initial`,\nDROP COLUMN `quantity_current`;\n\nCREATE TABLE `medication_inventories` (\n`id` INT(11) NOT NULL AUTO_INCREMENT,\n`quantity_current` INT(255) NOT NULL,\n`quantity_initial` INT(255) NOT NULL,\n`mission_trip_id` INT(11) NOT NULL,\n`medication_id` INT(11) NOT NULL,\nPRIMARY KEY (`id`),\nINDEX `fk_medication_inventory_mission_trips_id_idx` (`mission_trip_id` ASC),\nINDEX `fk_medication_inventory_medications_id_idx` (`medication_id` ASC),\nCONSTRAINT `fk_medication_inventory_mission_trips_id`\nFOREIGN KEY (`mission_trip_id`)\nREFERENCES `mission_trips` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nCONSTRAINT `fk_medication_inventory_medications_id`\nFOREIGN KEY (`medication_id`)\nREFERENCES `medications` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION);\n\nALTER TABLE `medication_inventories`\nDROP FOREIGN KEY `fk_medication_inventory_mission_trips_id`,\nDROP FOREIGN KEY `fk_medication_inventory_medications_id`;\nALTER TABLE `medication_inventories`\nADD CONSTRAINT `fk_medication_inventory_mission_trips_id`\nFOREIGN KEY (`mission_trip_id`)\nREFERENCES `mission_trips` (`id`)\nON DELETE RESTRICT\nON UPDATE RESTRICT,\nADD CONSTRAINT `fk_medication_inventory_medications_id`\nFOREIGN KEY (`medication_id`)\nREFERENCES `medications` (`id`)\nON DELETE RESTRICT\nON UPDATE RESTRICT;','ALTER TABLE `medications`\nADD COLUMN `quantity_current` INT(255) NULL DEFAULT NULL,\nADD COLUMN `quantity_initial` INT(255) NULL DEFAULT NULL;\n\nDROP TABLE `medication_inventories`;','applied',''),(79,'79a1f0114974a51f0adf6b05856ff712a2e8b887','2025-11-05 00:11:41','CREATE TABLE `patient_prescription_replacement_reasons` (\n`id` INT(11) NOT NULL AUTO_INCREMENT,\n`name` VARCHAR(255) NOT NULL,\n`description` VARCHAR(255) NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC));\n\nCREATE TABLE `patient_prescription_replacements` (\n`id` INT(11) NOT NULL AUTO_INCREMENT,\n`patient_prescription_id_original` INT(11) NOT NULL,\n`patient_prescription_id_replacement` INT(11) NOT NULL,\n`patient_prescription_replacement_reason_id` INT(11) NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC),\nINDEX `fk_prescriptionReplacements_id_original_prescriptions_id_idx` (`patient_prescription_id_original` ASC),\nINDEX `fk_prescriptionReplacements_id_replacement_prescriptions_id_idx` (`patient_prescription_id_replacement` ASC),\nINDEX `fk_prescriptionReplacements_replacementReason_id_reasons_id_idx` (`patient_prescription_replacement_reason_id` ASC),\nCONSTRAINT `fk_prescriptionReplacements_id_original_prescriptions_id`\nFOREIGN KEY (`patient_prescription_id_original`)\nREFERENCES `patient_prescriptions` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nCONSTRAINT `fk_prescriptionReplacements_id_replacement_prescriptions_id`\nFOREIGN KEY (`patient_prescription_id_replacement`)\nREFERENCES `patient_prescriptions` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nCONSTRAINT `fk_prescriptionReplacements_replacementReason_id_reasons_id`\nFOREIGN KEY (`patient_prescription_replacement_reason_id`)\nREFERENCES `patient_prescription_replacement_reasons` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION);\n\nINSERT INTO `patient_prescription_replacement_reasons` (`name`, `description`) VALUES (\'physician edit\', \'the editing of a prescription as it\\\'s being prescribed by a physician\');\nINSERT INTO `patient_prescription_replacement_reasons` (`name`, `description`) VALUES (\'pharmacist replacement\', \'the replacement of a prescription by a pharmacist\');\nINSERT INTO `patient_prescription_replacement_reasons` (`name`, `description`) VALUES (\'encounter edit\', \'the editing of a prescription after the encounter has been closed\');','DROP TABLE `patient_prescription_replacements`;\n\nDROP TABLE `patient_prescription_replacement_reasons`;','applied',''),(80,'c4706b2fdee1a72faf0c2f5f4f81f7b211ce5a6a','2025-11-05 00:11:41','INSERT INTO `patient_prescription_replacements`\n(\n`patient_prescription_id_original`,\n`patient_prescription_id_replacement`,\n`patient_prescription_replacement_reason_id`\n)\nSELECT\n`pp`.`id`,\n`pp`.`replacement_id`,\n`pprr`.`id`\nFROM `patient_prescriptions` pp, `patient_prescription_replacement_reasons` pprr\nWHERE `replacement_id` IS NOT NULL\nAND `pprr`.`name` = \'pharmacist replacement\';','UPDATE `patient_prescriptions` pp\nINNER JOIN `patient_prescription_replacements` ppr\nON pp.`id` = ppr.`patient_prescription_id_original`\nSET pp.`replacement_id` = ppr.`patient_prescription_id_replacement`;','applied',''),(81,'99a6a72d0ba07571b6c44ccfea1b942932b7daa9','2025-11-05 00:11:41','ALTER TABLE `patient_prescriptions`\nDROP FOREIGN KEY `fk_patient_prescriptions_replacement_id_patient_prescriptions_id`;\nALTER TABLE `patient_prescriptions`\nDROP COLUMN `replacement_id`,\nDROP INDEX `fk_patient_prescriptions_replacement_id_patent_prescription_idx` ;','ALTER TABLE `patient_prescriptions`\nADD COLUMN `replacement_id` INT(11) NULL DEFAULT NULL AFTER `date_taken`,\nADD INDEX `fk_patient_prescriptions_replacement_id_patent_prescription_idx` (`replacement_id` ASC);\nALTER TABLE `patient_prescriptions`\nADD CONSTRAINT `fk_patient_prescriptions_replacement_id_patient_prescriptions_id`\nFOREIGN KEY (`replacement_id`)\nREFERENCES `patient_prescriptions` (`id`)\nON DELETE RESTRICT\nON UPDATE RESTRICT;','applied',''),(82,'a1c70605e62af9ae52285fd84fe60b658cb286b0','2025-11-05 00:11:41','ALTER TABLE `patient_prescriptions`\nADD COLUMN `date_dispensed` DATETIME NULL DEFAULT NULL AFTER `date_taken`;\n\nCREATE TABLE `mission_trip_users` (\n`id` INT(11) NOT NULL AUTO_INCREMENT,\n`mission_trip_id` INT(11) NOT NULL,\n`user_id` INT(11) NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC),\nINDEX `fk_mission_trip_users_user_id_users_id_idx` (`user_id` ASC),\nINDEX `fk_mission_trip_users_mission_trip_id_mission_trips_id_idx` (`mission_trip_id` ASC),\nCONSTRAINT `fk_mission_trip_users_user_id_users_id`\nFOREIGN KEY (`user_id`)\nREFERENCES `users` (`id`)\nON DELETE NO ACTION\nON UPDATE RESTRICT,\nCONSTRAINT `fk_mission_trip_users_mission_trip_id_mission_trips_id`\nFOREIGN KEY (`mission_trip_id`)\nREFERENCES `mission_trips` (`id`)\nON DELETE NO ACTION\nON UPDATE RESTRICT);','ALTER TABLE `patient_prescriptions`\nDROP COLUMN `date_dispensed`;\n\nDROP TABLE `mission_trip_users`;','applied',''),(83,'58c7e7fb0be9358bff80635dec556ce5c9f43b27','2025-11-05 00:11:42','UPDATE patient_prescriptions pp\nINNER JOIN patient_encounters pe ON\npp.encounter_id = pe.id\nSET pp.date_dispensed = pe.date_of_pharmacy_visit\nWHERE NOT EXISTS(\nSELECT * FROM patient_prescription_replacements ppr\nWHERE ppr.patient_prescription_id_original = pp.id\n);\n\nALTER TABLE `mission_trips`\nDROP COLUMN `isCurrent`;','UPDATE patient_prescriptions pp\nSET pp.date_dispensed = NULL;\n\nALTER TABLE `mission_trips`\nADD COLUMN `isCurrent` BIT(1) NOT NULL DEFAULT b\'0\';','applied',''),(84,'ac2322787491212fda61b0c15f6163871a99ecd4','2025-11-05 00:11:42','ALTER TABLE `patient_prescriptions`\nDROP COLUMN `isDispensed`;','ALTER TABLE `patient_prescriptions`\nADD COLUMN `isDispensed` BIT(1) NOT NULL DEFAULT false;','applied',''),(85,'7fa10cf1430f74f5652f20a7d2d17fbda86a625a','2025-11-05 00:11:42','ALTER TABLE `users`\n\nADD COLUMN `passwordCreatedDate` DATETIME NOT NULL AFTER `password`,\nADD COLUMN `date_created` DATETIME DEFAULT \'0000-01-01 00:00:00\' AFTER `last_login`,\nADD COLUMN `created_by` INT AFTER `date_created`;\n\nUPDATE `users`\nSET date_created = \'0000-01-01 00:00:00\';\n\nUPDATE `users`\nSET passwordCreatedDate = \'0000-01-01 00:00:00\';\n\nINSERT INTO vitals (name, data_type, unit_of_measurement)\nVALUES (\'weeksPregnant\', \'integer\', \'weeks\');\n\nINSERT INTO patient_encounter_vitals (user_id, patient_encounter_id, vital_id, vital_value, date_taken)\nSELECT user_id_triage,\nid,\n( SELECT id FROM vitals WHERE name = \'weeksPregnant\') as vital_id,\nweeks_pregnant,\ndate_of_triage_visit\nFROM patient_encounters\nWHERE weeks_pregnant IS NOT NULL;\n\nALTER TABLE patient_encounters DROP COLUMN weeks_pregnant;','ALTER TABLE `users`\nDROP COLUMN `passwordCreatedDate`,\nDROP COLUMN `date_created`,\nDROP COLUMN `created_by`;\n\nALTER TABLE `patient_encounters`\nADD COLUMN `weeks_pregnant` INT(255) NULL DEFAULT NULL  AFTER `date_of_triage_visit`;\n\nUPDATE patient_encounters pe, patient_encounter_vitals pev\nSET pe.weeks_pregnant = pev.vital_value\nWHERE pe.id = pev.patient_encounter_id\nAND pev.vital_id = (SELECT id FROM vitals WHERE name = \'weeksPregnant\');\n\nDELETE FROM patient_encounter_vitals WHERE vital_id IN\n(SELECT id FROM vitals WHERE name = \'weeksPregnant\');\n\nDELETE FROM vitals WHERE name = \'weeksPregnant\';','applied',''),(86,'a599f86390f31555b8d3299f365287624e6c4f99','2025-11-05 00:11:42','ALTER TABLE `patients`\nADD COLUMN `isDeleted` DATETIME NULL DEFAULT NULL AFTER `photo_id`;','ALTER TABLE `patients`\nDROP COLUMN `isDeleted`;','applied',''),(87,'358f09556e4bc5ed473bf3f69e4b16ebe35e6838','2025-11-05 00:11:42','ALTER TABLE `patients`\nADD COLUMN `deleted_by_user_id` INT(11) NULL DEFAULT NULL  AFTER `isDeleted`;\nALTER TABLE `medication_inventories`\nADD COLUMN `isDeleted` DATETIME NULL DEFAULT NULL AFTER `medication_id`;','ALTER TABLE `patients`\nDROP COLUMN `deleted_by_user_id`;\nALTER TABLE `medication_inventories`\nDROP COLUMN `isDeleted`;','applied',''),(88,'8e321d68d61827374324798cc9f3e26b82963062','2025-11-05 00:11:42','ALTER TABLE `patients`\nADD CONSTRAINT `fk_patients_user_deleted_by_user_id_id`\nFOREIGN KEY (`deleted_by_user_id` )\nREFERENCES `users` (`id` )\nON DELETE NO ACTION\nON UPDATE NO ACTION;','ALTER TABLE `patients`\nDROP FOREIGN KEY fk_patients_user_deleted_by_user_id_id;','applied',''),(89,'d6bccafac9dac5624703dcfc79d92d8f9c875f20','2025-11-05 00:11:42','ALTER TABLE `medication_administrations`\nCHANGE COLUMN `daily_modifier` `daily_modifier` DECIMAL(9,6) NOT NULL ;','ALTER TABLE `medication_administrations`\nCHANGE COLUMN `daily_modifier` `daily_modifier` DECIMAL(5,2) NOT NULL ;','applied',''),(90,'318e982c9436d1e3a43700b90cde2bf4a067bdf7','2025-11-05 00:11:42','ALTER TABLE `medication_administrations`\nRENAME TO  `concept_prescription_administrations` ;\n\nALTER TABLE `patient_prescriptions`\nDROP FOREIGN KEY `fk_patient_prescriptions_medication_administrations`;\nALTER TABLE `patient_prescriptions`\nCHANGE COLUMN `medication_administrations_id` `concept_prescription_administrations_id` INT(11) NULL DEFAULT NULL ;\n\nALTER TABLE `patient_prescriptions`\nADD CONSTRAINT `fk_patient_prescriptions_concept_prescription_administrations`\nFOREIGN KEY (`concept_prescription_administrations_id`)\nREFERENCES `concept_prescription_administrations` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;\n\nALTER TABLE `diagnoses`\nRENAME TO  `concept_diagnoses` ;','ALTER TABLE `patient_prescriptions`\nDROP FOREIGN KEY `fk_patient_prescriptions_concept_prescription_administrations`;\n\nALTER TABLE `patient_prescriptions`\nCHANGE COLUMN `concept_prescription_administrations_id` `medication_administrations_id` INT(11) NULL DEFAULT NULL ;\n\nALTER TABLE `patient_prescriptions`\nADD CONSTRAINT `fk_patient_prescriptions_medication_administrations`\nFOREIGN KEY (`medication_administrations_id`)\nREFERENCES `concept_prescription_administrations` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;\n\nALTER TABLE  `concept_prescription_administrations`\nRENAME TO `medication_administrations`;\n\nALTER TABLE `concept_diagnoses`\nRENAME TO  `diagnoses` ;','applied',''),(91,'83eb20d5a91b8f379bcd0d69487ddc0996ad93d4','2025-11-05 00:11:42','ALTER TABLE `medication_forms`\nRENAME TO  `concept_medication_forms` ;\n\nALTER TABLE `medications`\nDROP FOREIGN KEY `fk_medications_medication_forms`;\n\nALTER TABLE `medications`\nCHANGE COLUMN `medication_forms_id` `concept_medication_forms_id` INT(11) UNSIGNED NULL DEFAULT NULL ;\n\nALTER TABLE `medications`\nADD CONSTRAINT `fk_medications_concept_medication_forms`\nFOREIGN KEY (`concept_medication_forms_id`)\nREFERENCES `concept_medication_forms` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;','ALTER TABLE `medications`\nDROP FOREIGN KEY `fk_medications_concept_medication_forms`;\nALTER TABLE `medications`\nCHANGE COLUMN `concept_medication_forms_id` `medication_forms_id` INT(11) UNSIGNED NULL DEFAULT NULL ;\nALTER TABLE `medications`\nADD CONSTRAINT `fk_medications_medication_forms`\nFOREIGN KEY (`medication_forms_id`)\nREFERENCES `concept_medication_forms` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;\n\nALTER TABLE `concept_medication_forms`\nRENAME TO  `medication_forms` ;','applied',''),(92,'117e06b0724bbfbb22576e5901954908c6b23052','2025-11-05 00:11:42','ALTER TABLE `medication_measurement_units`\nRENAME TO  `concept_medication_units` ;\n\nALTER TABLE `medication_active_drugs`\nDROP FOREIGN KEY `fk_medication_active_drugs_medication_measurement_units`;\n\nALTER TABLE `medication_active_drugs`\nCHANGE COLUMN `medication_measurement_units_id` `concept_medication_units_id` INT(11) UNSIGNED NOT NULL ;\n\nALTER TABLE `medication_active_drugs`\nADD CONSTRAINT `fk_medication_active_drugs_concept_medication_units`\nFOREIGN KEY (`concept_medication_units_id`)\nREFERENCES `concept_medication_units` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;','ALTER TABLE `medication_active_drugs`\nDROP FOREIGN KEY `fk_medication_active_drugs_concept_medication_units`;\n\nALTER TABLE `medication_active_drugs`\nCHANGE COLUMN `concept_medication_units_id` `medication_measurement_units_id` INT(11) UNSIGNED NOT NULL ;\n\nALTER TABLE `medication_active_drugs`\nADD CONSTRAINT `fk_medication_active_drugs_medication_measurement_units`\nFOREIGN KEY (`medication_measurement_units_id`)\nREFERENCES `concept_medication_units` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;\n\nALTER TABLE `concept_medication_units`\nRENAME TO  `medication_measurement_units` ;','applied',''),(93,'a887792c550f080a4d89edcb15c66fe040c8553d','2025-11-05 00:11:43','ALTER TABLE `medication_active_drug_names`\nRENAME TO  `medication_generics` ;\n\nALTER TABLE `medication_active_drugs`\nDROP FOREIGN KEY `fk_medication_active_drugs_medication_active_drug_names`;\n\nALTER TABLE `medication_active_drugs`\nCHANGE COLUMN `medication_active_drug_names_id` `medication_generics_id` INT(11) UNSIGNED NOT NULL ;\n\nALTER TABLE `medication_active_drugs`\nADD CONSTRAINT `fk_medication_active_drugs_medication_generics`\nFOREIGN KEY (`medication_generics_id`)\nREFERENCES `medication_generics` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;','ALTER TABLE `medication_active_drugs`\nDROP FOREIGN KEY `fk_medication_active_drugs_medication_generics`;\n\nALTER TABLE `medication_active_drugs`\nCHANGE COLUMN `medication_generics_id` `medication_active_drug_names_id` INT(11) UNSIGNED NOT NULL ;\n\nALTER TABLE `medication_active_drugs`\nADD CONSTRAINT `fk_medication_active_drugs_medication_active_drug_names`\nFOREIGN KEY (`medication_active_drug_names_id`)\nREFERENCES `medication_generics` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;\n\nALTER TABLE `medication_generics`\nRENAME TO  `medication_active_drug_names` ;','applied',''),(94,'d61138549b4c2eee820e2a8166da3107c2c35519','2025-11-05 00:11:43','ALTER TABLE `medication_active_drugs`\nRENAME TO  `medication_generic_strengths` ;\n\nALTER TABLE `medication_medication_active_drugs`\nDROP FOREIGN KEY `fk_medication_medication_active_drugs_medication_active_drugs`;\nALTER TABLE `medication_medication_active_drugs`\nCHANGE COLUMN `medication_active_drugs_id` `medication_generic_strength_id` INT(11) UNSIGNED NOT NULL ;\nALTER TABLE `medication_medication_active_drugs`\nADD CONSTRAINT `fk_medication_medication_generic_strengths`\nFOREIGN KEY (`medication_generic_strength_id`)\nREFERENCES `medication_generic_strengths` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;','ALTER TABLE `medication_medication_active_drugs`\nDROP FOREIGN KEY `fk_medication_medication_generic_strengths`;\nALTER TABLE `medication_medication_active_drugs`\nCHANGE COLUMN `medication_generic_strength_id` `medication_active_drugs_id` INT(11) UNSIGNED NOT NULL ;\nALTER TABLE `medication_medication_active_drugs`\nADD CONSTRAINT `fk_medication_medication_active_drugs_medication_active_drugs`\nFOREIGN KEY (`medication_active_drugs_id`)\nREFERENCES `medication_generic_strengths` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;\n\n\nALTER TABLE `medication_generic_strengths`\nRENAME TO  `medication_active_drugs` ;','applied',''),(95,'6b333c63d8187b2cf4bc8b8c257567db3da1245b','2025-11-05 00:11:43','ALTER TABLE `medication_medication_active_drugs`\nRENAME TO  `medication_medication_generic_strengths` ;\n\nALTER TABLE `medication_medication_generic_strengths`\nDROP FOREIGN KEY `fk_medication_medication_active_drugs_medications`;\n\nALTER TABLE `medication_medication_generic_strengths`\nADD CONSTRAINT `fk_medication_medication_generic_strengths_medications`\nFOREIGN KEY (`medications_id`)\nREFERENCES `medications` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;','ALTER TABLE `medication_medication_generic_strengths`\nDROP FOREIGN KEY `fk_medication_medication_generic_strengths_medications`;\n\nALTER TABLE `medication_medication_generic_strengths`\nADD CONSTRAINT `fk_medication_medication_active_drugs_medications`\nFOREIGN KEY (`medication_generic_strength_id`)\nREFERENCES `medication_generic_strengths` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;\n\nALTER TABLE `medication_medication_generic_strengths`\nRENAME TO  `medication_medication_active_drugs` ;','applied',''),(96,'54ce0b5746f723f3a0f1d0f0a2e5fa3e424001a5','2025-11-05 00:11:43','CREATE TABLE `concept_medications` (\n`id` INT(11) NOT NULL AUTO_INCREMENT,\n`name` VARCHAR(255) NULL DEFAULT NULL,\n`isDeleted` BIT(1) NULL DEFAULT b\'0\',\n`concept_medication_form_id` INT(11) UNSIGNED NULL DEFAULT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC),\nINDEX `fk_concept_medications_concept_medication_forms_idx` (`concept_medication_form_id` ASC),\nCONSTRAINT `fk_concept_medications_concept_medication_forms`\nFOREIGN KEY (`concept_medication_form_id`)\nREFERENCES `concept_medication_forms` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION);\n\nCREATE TABLE `concept_medication_generics` (\n`id` INT(10) NOT NULL AUTO_INCREMENT,\n`name` VARCHAR(45) NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC),\nUNIQUE INDEX `name_UNIQUE` (`name` ASC));\n\nCREATE TABLE `concept_medication_generic_strengths` (\n`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,\n`concept_medication_unit_id` INT(11) UNSIGNED NOT NULL,\n`concept_medication_generic_id` INT(11) NOT NULL,\n`isDenominator` BIT(1) NOT NULL DEFAULT b\'0\',\n`value` INT(11) NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC),\nINDEX `fk_concept_generic_strengths_concept_units_idx` (`concept_medication_unit_id` ASC),\nINDEX `fk_concept_generic_strengths_concept_generics_idx` (`concept_medication_generic_id` ASC),\nCONSTRAINT `fk_concept_generic_strengths_concept_units`\nFOREIGN KEY (`concept_medication_unit_id`)\nREFERENCES `concept_medication_units` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nCONSTRAINT `fk_concept_generic_strengths_concept_generics`\nFOREIGN KEY (`concept_medication_generic_id`)\nREFERENCES `concept_medication_generics` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION);\n\nCREATE TABLE `concept_medication_concept_generic_strengths` (\n`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,\n`concept_medication_id` INT(11) NOT NULL,\n`concept_medication_generic_strength_id` INT(11) UNSIGNED NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC),\nINDEX `fk_concept_medication_concept_generic_strengths_idx` (`concept_medication_generic_strength_id` ASC),\nINDEX `fk_concept_generic_strengths_concept_medications_idx` (`concept_medication_id` ASC),\nCONSTRAINT `fk_concept_medication_concept_generic_strengths`\nFOREIGN KEY (`concept_medication_generic_strength_id`)\nREFERENCES `concept_medication_generic_strengths` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nCONSTRAINT `fk_concept_generic_strengths_concept_medications`\nFOREIGN KEY (`concept_medication_id`)\nREFERENCES `concept_medications` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION);','DROP TABLE `concept_medication_concept_generic_strengths`;\n\nDROP TABLE `concept_medication_generic_strengths`;\n\nDROP TABLE `concept_medication_generics`;\n\nDROP TABLE `concept_medications`;','applied',''),(97,'fddbf49361fd7f98e29aacda33a59f2847fad3c6','2025-11-05 00:11:43','ALTER TABLE `concept_medication_generic_strengths`\nCHANGE COLUMN `value` `value` DECIMAL(10,4) NOT NULL ;\n\nALTER TABLE `medication_generic_strengths`\nCHANGE COLUMN `value` `value` DECIMAL(10,4) NOT NULL ;','ALTER TABLE `concept_medication_generic_strengths`\nCHANGE COLUMN `value` `value` INT(11) NOT NULL ;\n\nALTER TABLE `medication_generic_strengths`\nCHANGE COLUMN `value` `value` INT(11) NOT NULL ;','applied',''),(98,'1ed0102c6c98905bd6fcf08bb0843bbdd829e494','2025-11-05 00:11:43','ALTER TABLE `patient_encounters`\nADD COLUMN `is_diabetes_screened` BOOL NULL DEFAULT NULL AFTER `mission_trip_id`;\n\nALTER TABLE `patients`\nADD COLUMN `reason_deleted` VARCHAR(255) NULL DEFAULT NULL AFTER `deleted_by_user_id`;','ALTER TABLE `patient_encounters`\nDROP COLUMN `is_diabetes_screened`;\n\nALTER TABLE `patients`\nDROP COLUMN `reason_deleted`;','applied',''),(99,'e7193ad8f5c4a183a303c91a494100ce47fb615a','2025-11-05 00:11:43','ALTER TABLE patients ADD COLUMN phone_number VARCHAR(20) NULL DEFAULT NULL AFTER last_name;','ALTER TABLE patients DROP COLUMN phone_number;','applied',''),(100,'3557673967dfeef648280c0002a794071cde1372','2025-11-05 00:11:43','ALTER TABLE `play_evolutions`\nCHANGE COLUMN `apply_script` `apply_script` MEDIUMTEXT NULL DEFAULT NULL ,\nCHANGE COLUMN `revert_script` `revert_script` MEDIUMTEXT NULL DEFAULT NULL ,\nCHANGE COLUMN `last_problem` `last_problem` MEDIUMTEXT NULL DEFAULT NULL ;','ALTER TABLE `play_evolutions`\nCHANGE COLUMN `apply_script` `apply_script` TEXT NULL DEFAULT NULL ,\nCHANGE COLUMN `revert_script` `revert_script` TEXT NULL DEFAULT NULL ,\nCHANGE COLUMN `last_problem` `last_problem` TEXT NULL DEFAULT NULL ;','applied',''),(101,'b382595f2861e1589ecab35f0ff98598b726dbd6','2025-11-05 00:11:43','ALTER TABLE `system_settings` ADD COLUMN description VARCHAR(250);','ALTER TABLE `system_settings` DROP COLUMN `description`;','applied',''),(102,'95606ddc74ca59c076d44e1182877323821bd89c','2025-11-05 00:11:43','UPDATE `tab_fields`\nSET name=\"procedure_counseling\"\nWHERE name=\"treatment\"','UPDATE `tab_fields`\nSET name=\"treatment\"\nWHERE name=\"procedure_counseling\"','applied',''),(103,'a1d50a0eea6bb7cd850dfcbe1185ba33cb22bc0b','2025-11-05 00:11:43','ALTER TABLE `photos`\nADD COLUMN `photo` LONGBLOB NULL AFTER `insertTS`;','ALTER TABLE `photos` DROP COLUMN `photo`;','applied',''),(104,'72e2b50d0e9ef996babb89eaa2bc749ddc9c6042','2025-11-05 00:11:43','ALTER TABLE `patient_encounter_tab_fields`\nADD COLUMN `IsDeleted` DATETIME NULL AFTER `chief_complaint_id`,\nADD COLUMN `DeletedByUserId` INTEGER NULL AFTER `IsDeleted`,\nADD CONSTRAINT `fk_deleted_by_user_id_id`\nFOREIGN KEY (`DeletedByUserId`)\nREFERENCES `users` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;','ALTER TABLE `patient_encounter_tab_fields`\nDROP COLUMN `IsDeleted`,\nDROP FOREIGN KEY `fk_deleted_by_user_id_id`,\nDROP COLUMN `DeletedByUserId`;','applied',''),(105,'1b42f256dc406995d81404968b270723194f5842','2025-11-05 00:11:43','ALTER TABLE `medication_inventories`\nADD COLUMN `timeAdded` DATETIME NULL,\nADD COLUMN `createdBy` INT(11) NULL;','ALTER TABLE `medication_inventories`\nDROP COLUMN `timeAdded`,\nDROP COLUMN `createdBy`;','applied',''),(106,'bffd4bdd178053ef00e3c1330714dff6b686a8bd','2025-11-05 00:11:43','ALTER TABLE `medication_inventories`\nADD CONSTRAINT `fk_created_by_user_id_user_id`\nFOREIGN KEY (`createdBy`)\nREFERENCES `users` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;','ALTER TABLE `medication_inventories`\nDROP FOREIGN KEY `fk_created_by_user_id_user_id`;','applied',''),(107,'16804419c8c254e1d4ffbcd9478a666b4ca82919','2025-11-05 00:11:44','CREATE  TABLE `feedback` (\n`id` INT NOT NULL AUTO_INCREMENT ,\n`date` DATE NOT NULL ,\n`feedback` TEXT NOT NULL ,\nPRIMARY KEY (`id`) );','DROP TABLE IF EXISTS feedback;','applied',''),(108,'41713b4b262dc81124bf93fac2f9fe01df77a5a0','2025-11-05 00:11:44','ALTER TABLE `patient_encounters`\nADD COLUMN `isDeleted` DATETIME NULL DEFAULT NULL AFTER `date_of_diabetes_screen`;\nALTER TABLE `patient_encounters`\nADD COLUMN `deleted_by_user_id` INT(11) NULL DEFAULT NULL  AFTER `isDeleted`;\nALTER TABLE `patient_encounters`\nADD COLUMN `reason_deleted` VARCHAR(255) NULL DEFAULT NULL AFTER `deleted_by_user_id`;\n\nALTER TABLE `patient_encounters`\nADD CONSTRAINT `fk_patient_encounter_deletedbyuser_id_users_id`\nFOREIGN KEY (`deleted_by_user_id`)\nREFERENCES `users` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;','ALTER TABLE `patient_encounters`\nDROP FOREIGN KEY `fk_patient_encounter_deletedbyuser_id_users_id`;\n\nALTER TABLE `patient_encounters`\nDROP COLUMN `isDeleted`;\nALTER TABLE `patient_encounters`\nDROP COLUMN `deleted_by_user_id`;\nALTER TABLE `patient_encounters`\nDROP COLUMN `reason_deleted`;','applied',''),(109,'e5bd5221cab1dd4c4319f3887a82a5be14eaf64b','2025-11-05 00:11:44','ALTER TABLE `patient_encounters`\nDROP FOREIGN KEY `fk_patient_encounter_user_id_users_id_pharm`,\nDROP FOREIGN KEY `fk_patient_encounter_user_id_users_id_doc`,\nDROP FOREIGN KEY `fk_patient_encounter_user_id_users_id`;\n# --- ALTER TABLE `patient_encounters`\n# --- DROP INDEX `fk_patient_encounter_user_id_users_id_pharm` ;\nALTER TABLE `patient_encounters`\nDROP INDEX `user_id_idx` ;\n\nALTER TABLE `patient_encounters`\nADD INDEX `fk_patient_encounter_user_id_users_id_nurse_idx` (`user_id_triage` ASC),\nADD INDEX `fk_patient_encounter_user_id_users_id_doc_idx` (`user_id_medical` ASC),\nADD INDEX `fk_patient_encounter_user_id_users_id_pharm_idx` (`user_id_pharmacy` ASC);\nALTER TABLE `patient_encounters`\nADD CONSTRAINT `fk_patient_encounter_user_id_users_id_nurse`\nFOREIGN KEY (`user_id_triage`)\nREFERENCES `users` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nADD CONSTRAINT `fk_patient_encounter_user_id_users_id_doc`\nFOREIGN KEY (`user_id_medical`)\nREFERENCES `users` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nADD CONSTRAINT `fk_patient_encounter_user_id_users_id_pharm`\nFOREIGN KEY (`user_id_pharmacy`)\nREFERENCES `users` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;','ALTER TABLE `patient_encounters`\nDROP FOREIGN KEY `fk_patient_encounter_user_id_users_id_pharm`,\nDROP FOREIGN KEY `fk_patient_encounter_user_id_users_id_nurse`,\nDROP FOREIGN KEY `fk_patient_encounter_user_id_users_id_doc`;\nALTER TABLE `patient_encounters`\nDROP INDEX `fk_patient_encounter_user_id_users_id_pharm_idx` ,\nDROP INDEX `fk_patient_encounter_user_id_users_id_doc_idx` ,\nDROP INDEX `fk_patient_encounter_user_id_users_id_nurse_idx` ;\n\nALTER TABLE `patient_encounters`\nADD INDEX `fk_patient_encounter_user_id_users_id_pharm_idx` (`user_id_triage` ASC);\nALTER TABLE `patient_encounters`\nADD CONSTRAINT `fk_patient_encounter_user_id_users_id_pharm`\nFOREIGN KEY (`user_id_triage`)\nREFERENCES `users` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nADD CONSTRAINT `fk_patient_encounter_user_id_users_id_doc`\nFOREIGN KEY (`user_id_triage`)\nREFERENCES `users` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION,\nADD CONSTRAINT `fk_patient_encounter_user_id_users_id`\nFOREIGN KEY (`user_id_triage`)\nREFERENCES `users` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;\n\n# --- ALTER TABLE `patient_encounters`\n# --- DROP INDEX `fk_patient_encounter_user_id_users_id_pharm_idx` ,\n# --- ADD INDEX `fk_patient_encounter_user_id_users_id_pharm` (`user_id_triage` ASC);\n\nALTER TABLE `patient_encounters`\nDROP INDEX `fk_patient_encounter_user_id_users_id_pharm_idx` ,\nADD INDEX `user_id_idx` (`user_id_triage` ASC);','applied',''),(110,'e54ea6841d8245f41ea899a657451b38ac1cda8f','2025-11-05 00:11:44','DROP FUNCTION IF EXISTS `dm` ;\n\nCREATE FUNCTION `dm`(st VARCHAR(55)) RETURNS varchar(128) CHARSET utf8\nNO SQL\nBEGIN\nDECLARE length, first, last, pos, prevpos, is_slavo_germanic SMALLINT;;\nDECLARE pri, sec VARCHAR(45) DEFAULT \'\';;\nDECLARE ch CHAR(1);;\n-- returns the double metaphone code OR codes for given string\n-- if there is a secondary dm it is separated with a semicolon\n-- there are no checks done on the input string, but it should be a single word OR name.\n--  st is short for string. I usually prefer descriptive over short, but this var is used a lot!\nSET first = 3;;\nSET length = CHAR_LENGTH(st);;\nSET last = first + length -1;;\nSET st = CONCAT(REPEAT(\'-\', first -1), UCASE(st), REPEAT(\' \', 5));; --  pad st so we can index beyond the begining AND end of the input string\nSET is_slavo_germanic = (st LIKE \'%W%\' OR st LIKE \'%K%\' OR st LIKE \'%CZ%\');;  -- the check for \'%W%\' will catch WITZ\nSET pos = first;; --  pos is short for position\n-- skip these silent letters when at start of word\nIF SUBSTRING(st, first, 2) IN (\'GN\', \'KN\', \'PN\', \'WR\', \'PS\') THEN\nSET pos = pos + 1;;\nEND IF;;\n--  Initial \'X\' is pronounced \'Z\' e.g. \'Xavier\'\nIF SUBSTRING(st, first, 1) = \'X\' THEN\nSET pri = \'S\', sec = \'S\', pos = pos  + 1;; -- \'Z\' maps to \'S\'\nEND IF;;\n--  main loop through chars IN st\nWHILE pos <= last DO\n-- print str(pos) + \'\\t\' + SUBSTRING(st, pos)\nSET prevpos = pos;;\nSET ch = SUBSTRING(st, pos, 1);; --  ch is short for character\nCASE\nWHEN ch IN (\'A\', \'E\', \'I\', \'O\', \'U\', \'Y\') THEN\nIF pos = first THEN --  all init vowels now map to \'A\'\nSET pri = CONCAT(pri, \'A\'), sec = CONCAT(sec, \'A\'), pos = pos  + 1;; -- nxt = (\'A\', 1)\nELSE\nSET pos = pos + 1;;\nEND IF;;\nWHEN ch = \'B\' THEN\n-- \'-mb\', e.g\', \'dumb\', already skipped over... see \'M\' below\nIF SUBSTRING(st, pos+1, 1) = \'B\' THEN\nSET pri = CONCAT(pri, \'P\'), sec = CONCAT(sec, \'P\'), pos = pos  + 2;; -- nxt = (\'P\', 2)\nELSE\nSET pri = CONCAT(pri, \'P\'), sec = CONCAT(sec, \'P\'), pos = pos  + 1;; -- nxt = (\'P\', 1)\nEND IF;;\nWHEN ch = \'C\' THEN\n--  various germanic\nIF (pos > (first + 1) AND SUBSTRING(st, pos-2, 1) NOT IN (\'A\', \'E\', \'I\', \'O\', \'U\', \'Y\') AND SUBSTRING(st, pos-1, 3) = \'ACH\' AND\n(SUBSTRING(st, pos+2, 1) NOT IN (\'I\', \'E\') OR SUBSTRING(st, pos-2, 6) IN (\'BACHER\', \'MACHER\'))) THEN\nSET pri = CONCAT(pri, \'K\'), sec = CONCAT(sec, \'K\'), pos = pos  + 2;; -- nxt = (\'K\', 2)\n--  special case \'CAESAR\'\nELSEIF pos = first AND SUBSTRING(st, first, 6) = \'CAESAR\' THEN\nSET pri = CONCAT(pri, \'S\'), sec = CONCAT(sec, \'S\'), pos = pos  + 2;; -- nxt = (\'S\', 2)\nELSEIF SUBSTRING(st, pos, 4) = \'CHIA\' THEN -- italian \'chianti\'\nSET pri = CONCAT(pri, \'K\'), sec = CONCAT(sec, \'K\'), pos = pos  + 2;; -- nxt = (\'K\', 2)\nELSEIF SUBSTRING(st, pos, 2) = \'CH\' THEN\n--  find \'michael\'\nIF pos > first AND SUBSTRING(st, pos, 4) = \'CHAE\' THEN\nSET pri = CONCAT(pri, \'K\'), sec = CONCAT(sec, \'X\'), pos = pos  + 2;; -- nxt = (\'K\', \'X\', 2)\nELSEIF pos = first AND (SUBSTRING(st, pos+1, 5) IN (\'HARAC\', \'HARIS\') OR\nSUBSTRING(st, pos+1, 3) IN (\'HOR\', \'HYM\', \'HIA\', \'HEM\')) AND SUBSTRING(st, first, 5) != \'CHORE\' THEN\nSET pri = CONCAT(pri, \'K\'), sec = CONCAT(sec, \'K\'), pos = pos  + 2;; -- nxt = (\'K\', 2)\n-- germanic, greek, OR otherwise \'ch\' for \'kh\' sound\nELSEIF SUBSTRING(st, first, 4) IN (\'VAN \', \'VON \') OR SUBSTRING(st, first, 3) = \'SCH\'\nOR SUBSTRING(st, pos-2, 6) IN (\'ORCHES\', \'ARCHIT\', \'ORCHID\')\nOR SUBSTRING(st, pos+2, 1) IN (\'T\', \'S\')\nOR ((SUBSTRING(st, pos-1, 1) IN (\'A\', \'O\', \'U\', \'E\') OR pos = first)\nAND SUBSTRING(st, pos+2, 1) IN (\'L\', \'R\', \'N\', \'M\', \'B\', \'H\', \'F\', \'V\', \'W\', \' \')) THEN\nSET pri = CONCAT(pri, \'K\'), sec = CONCAT(sec, \'K\'), pos = pos  + 2;; -- nxt = (\'K\', 2)\nELSE\nIF pos > first THEN\nIF SUBSTRING(st, first, 2) = \'MC\' THEN\nSET pri = CONCAT(pri, \'K\'), sec = CONCAT(sec, \'K\'), pos = pos  + 2;; -- nxt = (\'K\', 2)\nELSE\nSET pri = CONCAT(pri, \'X\'), sec = CONCAT(sec, \'K\'), pos = pos  + 2;; -- nxt = (\'X\', \'K\', 2)\nEND IF;;\nELSE\nSET pri = CONCAT(pri, \'X\'), sec = CONCAT(sec, \'X\'), pos = pos  + 2;; -- nxt = (\'X\', 2)\nEND IF;;\nEND IF;;\n-- e.g, \'czerny\'\nELSEIF SUBSTRING(st, pos, 2) = \'CZ\' AND SUBSTRING(st, pos-2, 4) != \'WICZ\' THEN\nSET pri = CONCAT(pri, \'S\'), sec = CONCAT(sec, \'X\'), pos = pos  + 2;; -- nxt = (\'S\', \'X\', 2)\n-- e.g., \'focaccia\'\nELSEIF SUBSTRING(st, pos+1, 3) = \'CIA\' THEN\nSET pri = CONCAT(pri, \'X\'), sec = CONCAT(sec, \'X\'), pos = pos  + 3;; -- nxt = (\'X\', 3)\n-- double \'C\', but not IF e.g. \'McClellan\'\nELSEIF SUBSTRING(st, pos, 2) = \'CC\' AND NOT (pos = (first +1) AND SUBSTRING(st, first, 1) = \'M\') THEN\n-- \'bellocchio\' but not \'bacchus\'\nIF SUBSTRING(st, pos+2, 1) IN (\'I\', \'E\', \'H\') AND SUBSTRING(st, pos+2, 2) != \'HU\' THEN\n-- \'accident\', \'accede\' \'succeed\'\nIF (pos = first +1 AND SUBSTRING(st, first) = \'A\') OR\nSUBSTRING(st, pos-1, 5) IN (\'UCCEE\', \'UCCES\') THEN\nSET pri = CONCAT(pri, \'KS\'), sec = CONCAT(sec, \'KS\'), pos = pos  + 3;; -- nxt = (\'KS\', 3)\n-- \'bacci\', \'bertucci\', other italian\nELSE\nSET pri = CONCAT(pri, \'X\'), sec = CONCAT(sec, \'X\'), pos = pos  + 3;; -- nxt = (\'X\', 3)\nEND IF;;\nELSE\nSET pri = CONCAT(pri, \'K\'), sec = CONCAT(sec, \'K\'), pos = pos  + 2;; -- nxt = (\'K\', 2)\nEND IF;;\nELSEIF SUBSTRING(st, pos, 2) IN (\'CK\', \'CG\', \'CQ\') THEN\nSET pri = CONCAT(pri, \'K\'), sec = CONCAT(sec, \'K\'), pos = pos  + 2;; -- nxt = (\'K\', \'K\', 2)\nELSEIF SUBSTRING(st, pos, 2) IN (\'CI\', \'CE\', \'CY\') THEN\n-- italian vs. english\nIF SUBSTRING(st, pos, 3) IN (\'CIO\', \'CIE\', \'CIA\') THEN\nSET pri = CONCAT(pri, \'S\'), sec = CONCAT(sec, \'X\'), pos = pos  + 2;; -- nxt = (\'S\', \'X\', 2)\nELSE\nSET pri = CONCAT(pri, \'S\'), sec = CONCAT(sec, \'S\'), pos = pos  + 2;; -- nxt = (\'S\', 2)\nEND IF;;\nELSE\n-- name sent IN \'mac caffrey\', \'mac gregor\nIF SUBSTRING(st, pos+1, 2) IN (\' C\', \' Q\', \' G\') THEN\nSET pri = CONCAT(pri, \'K\'), sec = CONCAT(sec, \'K\'), pos = pos  + 3;; -- nxt = (\'K\', 3)\nELSE\nIF SUBSTRING(st, pos+1, 1) IN (\'C\', \'K\', \'Q\') AND SUBSTRING(st, pos+1, 2) NOT IN (\'CE\', \'CI\') THEN\nSET pri = CONCAT(pri, \'K\'), sec = CONCAT(sec, \'K\'), pos = pos  + 2;; -- nxt = (\'K\', 2)\nELSE --  default for \'C\'\nSET pri = CONCAT(pri, \'K\'), sec = CONCAT(sec, \'K\'), pos = pos  + 1;; -- nxt = (\'K\', 1)\nEND IF;;\nEND IF;;\nEND IF;;\n-- ELSEIF ch = \'Ç\' THEN --  will never get here with st.encode(\'ascii\', \'replace\') above\n-- SET pri = CONCAT(pri, \'5\'), sec = CONCAT(sec, \'5\'), pos = pos  + 1;; -- nxt = (\'S\', 1)\nWHEN ch = \'D\' THEN\nIF SUBSTRING(st, pos, 2) = \'DG\' THEN\nIF SUBSTRING(st, pos+2, 1) IN (\'I\', \'E\', \'Y\') THEN -- e.g. \'edge\'\nSET pri = CONCAT(pri, \'J\'), sec = CONCAT(sec, \'J\'), pos = pos  + 3;; -- nxt = (\'J\', 3)\nELSE\nSET pri = CONCAT(pri, \'TK\'), sec = CONCAT(sec, \'TK\'), pos = pos  + 2;; -- nxt = (\'TK\', 2)\nEND IF;;\nELSEIF SUBSTRING(st, pos, 2) IN (\'DT\', \'DD\') THEN\nSET pri = CONCAT(pri, \'T\'), sec = CONCAT(sec, \'T\'), pos = pos  + 2;; -- nxt = (\'T\', 2)\nELSE\nSET pri = CONCAT(pri, \'T\'), sec = CONCAT(sec, \'T\'), pos = pos  + 1;; -- nxt = (\'T\', 1)\nEND IF;;\nWHEN ch = \'F\' THEN\nIF SUBSTRING(st, pos+1, 1) = \'F\' THEN\nSET pri = CONCAT(pri, \'F\'), sec = CONCAT(sec, \'F\'), pos = pos  + 2;; -- nxt = (\'F\', 2)\nELSE\nSET pri = CONCAT(pri, \'F\'), sec = CONCAT(sec, \'F\'), pos = pos  + 1;; -- nxt = (\'F\', 1)\nEND IF;;\nWHEN ch = \'G\' THEN\nIF SUBSTRING(st, pos+1, 1) = \'H\' THEN\nIF (pos > first AND SUBSTRING(st, pos-1, 1) NOT IN (\'A\', \'E\', \'I\', \'O\', \'U\', \'Y\'))\nOR ( pos = first AND SUBSTRING(st, pos+2, 1) != \'I\') THEN\nSET pri = CONCAT(pri, \'K\'), sec = CONCAT(sec, \'K\'), pos = pos  + 2;; -- nxt = (\'K\', 2)\nELSEIF pos = first AND SUBSTRING(st, pos+2, 1) = \'I\' THEN\nSET pri = CONCAT(pri, \'J\'), sec = CONCAT(sec, \'J\'), pos = pos  + 2;; -- nxt = (\'J\', 2)\n-- Parker\'s rule (with some further refinements) - e.g., \'hugh\'\nELSEIF (pos > (first + 1) AND SUBSTRING(st, pos-2, 1) IN (\'B\', \'H\', \'D\') )\nOR (pos > (first + 2) AND SUBSTRING(st, pos-3, 1) IN (\'B\', \'H\', \'D\') )\nOR (pos > (first + 3) AND SUBSTRING(st, pos-4, 1) IN (\'B\', \'H\') ) THEN\nSET pos = pos + 2;; -- nxt = (None, 2)\nELSE\n--  e.g., \'laugh\', \'McLaughlin\', \'cough\', \'gough\', \'rough\', \'tough\'\nIF pos > (first + 2) AND SUBSTRING(st, pos-1, 1) = \'U\'\nAND SUBSTRING(st, pos-3, 1) IN (\'C\', \'G\', \'L\', \'R\', \'T\') THEN\nSET pri = CONCAT(pri, \'F\'), sec = CONCAT(sec, \'F\'), pos = pos  + 2;; -- nxt = (\'F\', 2)\nELSEIF pos > first AND SUBSTRING(st, pos-1, 1) != \'I\' THEN\nSET pri = CONCAT(pri, \'K\'), sec = CONCAT(sec, \'K\'), pos = pos  + 2;; -- nxt = (\'K\', 2)\nELSE\nSET pos = pos + 1;;\nEND IF;;\nEND IF;;\nELSEIF SUBSTRING(st, pos+1, 1) = \'N\' THEN\nIF pos = (first +1) AND SUBSTRING(st, first, 1) IN (\'A\', \'E\', \'I\', \'O\', \'U\', \'Y\') AND NOT is_slavo_germanic THEN\nSET pri = CONCAT(pri, \'KN\'), sec = CONCAT(sec, \'N\'), pos = pos  + 2;; -- nxt = (\'KN\', \'N\', 2)\nELSE\n--  not e.g. \'cagney\'\nIF SUBSTRING(st, pos+2, 2) != \'EY\' AND SUBSTRING(st, pos+1, 1) != \'Y\'\nAND NOT is_slavo_germanic THEN\nSET pri = CONCAT(pri, \'N\'), sec = CONCAT(sec, \'KN\'), pos = pos  + 2;; -- nxt = (\'N\', \'KN\', 2)\nELSE\nSET pri = CONCAT(pri, \'KN\'), sec = CONCAT(sec, \'KN\'), pos = pos  + 2;; -- nxt = (\'KN\', 2)\nEND IF;;\nEND IF;;\n--  \'tagliaro\'\nELSEIF SUBSTRING(st, pos+1, 2) = \'LI\' AND NOT is_slavo_germanic THEN\nSET pri = CONCAT(pri, \'KL\'), sec = CONCAT(sec, \'L\'), pos = pos  + 2;; -- nxt = (\'KL\', \'L\', 2)\n--  -ges-,-gep-,-gel-, -gie- at beginning\nELSEIF pos = first AND (SUBSTRING(st, pos+1, 1) = \'Y\'\nOR SUBSTRING(st, pos+1, 2) IN (\'ES\', \'EP\', \'EB\', \'EL\', \'EY\', \'IB\', \'IL\', \'IN\', \'IE\', \'EI\', \'ER\')) THEN\nSET pri = CONCAT(pri, \'K\'), sec = CONCAT(sec, \'J\'), pos = pos  + 2;; -- nxt = (\'K\', \'J\', 2)\n--  -ger-,  -gy-\nELSEIF (SUBSTRING(st, pos+1, 2) = \'ER\' OR SUBSTRING(st, pos+1, 1) = \'Y\')\nAND SUBSTRING(st, first, 6) NOT IN (\'DANGER\', \'RANGER\', \'MANGER\')\nAND SUBSTRING(st, pos-1, 1) not IN (\'E\', \'I\') AND SUBSTRING(st, pos-1, 3) NOT IN (\'RGY\', \'OGY\') THEN\nSET pri = CONCAT(pri, \'K\'), sec = CONCAT(sec, \'J\'), pos = pos  + 2;; -- nxt = (\'K\', \'J\', 2)\n--  italian e.g, \'biaggi\'\nELSEIF SUBSTRING(st, pos+1, 1) IN (\'E\', \'I\', \'Y\') OR SUBSTRING(st, pos-1, 4) IN (\'AGGI\', \'OGGI\') THEN\n--  obvious germanic\nIF SUBSTRING(st, first, 4) IN (\'VON \', \'VAN \') OR SUBSTRING(st, first, 3) = \'SCH\'\nOR SUBSTRING(st, pos+1, 2) = \'ET\' THEN\nSET pri = CONCAT(pri, \'K\'), sec = CONCAT(sec, \'K\'), pos = pos  + 2;; -- nxt = (\'K\', 2)\nELSE\n--  always soft IF french ending\nIF SUBSTRING(st, pos+1, 4) = \'IER \' THEN\nSET pri = CONCAT(pri, \'J\'), sec = CONCAT(sec, \'J\'), pos = pos  + 2;; -- nxt = (\'J\', 2)\nELSE\nSET pri = CONCAT(pri, \'J\'), sec = CONCAT(sec, \'K\'), pos = pos  + 2;; -- nxt = (\'J\', \'K\', 2)\nEND IF;;\nEND IF;;\nELSEIF SUBSTRING(st, pos+1, 1) = \'G\' THEN\nSET pri = CONCAT(pri, \'K\'), sec = CONCAT(sec, \'K\'), pos = pos  + 2;; -- nxt = (\'K\', 2)\nELSE\nSET pri = CONCAT(pri, \'K\'), sec = CONCAT(sec, \'K\'), pos = pos  + 1;; -- nxt = (\'K\', 1)\nEND IF;;\nWHEN ch = \'H\' THEN\n--  only keep IF first & before vowel OR btw. 2 (\'A\', \'E\', \'I\', \'O\', \'U\', \'Y\')\nIF (pos = first OR SUBSTRING(st, pos-1, 1) IN (\'A\', \'E\', \'I\', \'O\', \'U\', \'Y\'))\nAND SUBSTRING(st, pos+1, 1) IN (\'A\', \'E\', \'I\', \'O\', \'U\', \'Y\') THEN\nSET pri = CONCAT(pri, \'H\'), sec = CONCAT(sec, \'H\'), pos = pos  + 2;; -- nxt = (\'H\', 2)\nELSE --  (also takes care of \'HH\')\nSET pos = pos + 1;; -- nxt = (None, 1)\nEND IF;;\nWHEN ch = \'J\' THEN\n--  obvious spanish, \'jose\', \'san jacinto\'\nIF SUBSTRING(st, pos, 4) = \'JOSE\' OR SUBSTRING(st, first, 4) = \'SAN \' THEN\nIF (pos = first AND SUBSTRING(st, pos+4, 1) = \' \') OR SUBSTRING(st, first, 4) = \'SAN \' THEN\nSET pri = CONCAT(pri, \'H\'), sec = CONCAT(sec, \'H\');; -- nxt = (\'H\',)\nELSE\nSET pri = CONCAT(pri, \'J\'), sec = CONCAT(sec, \'H\');; -- nxt = (\'J\', \'H\')\nEND IF;;\nELSEIF pos = first AND SUBSTRING(st, pos, 4) != \'JOSE\' THEN\nSET pri = CONCAT(pri, \'J\'), sec = CONCAT(sec, \'A\');; -- nxt = (\'J\', \'A\') --  Yankelovich/Jankelowicz\nELSE\n--  spanish pron. of e.g. \'bajador\'\nIF SUBSTRING(st, pos-1, 1) IN (\'A\', \'E\', \'I\', \'O\', \'U\', \'Y\') AND NOT is_slavo_germanic\nAND SUBSTRING(st, pos+1, 1) IN (\'A\', \'O\') THEN\nSET pri = CONCAT(pri, \'J\'), sec = CONCAT(sec, \'H\');; -- nxt = (\'J\', \'H\')\nELSE\nIF pos = last THEN\nSET pri = CONCAT(pri, \'J\');; -- nxt = (\'J\', \' \')\nELSE\nIF SUBSTRING(st, pos+1, 1) not IN (\'L\', \'T\', \'K\', \'S\', \'N\', \'M\', \'B\', \'Z\')\nAND SUBSTRING(st, pos-1, 1) not IN (\'S\', \'K\', \'L\') THEN\nSET pri = CONCAT(pri, \'J\'), sec = CONCAT(sec, \'J\');; -- nxt = (\'J\',)\nEND IF;;\nEND IF;;\nEND IF;;\nEND IF;;\nIF SUBSTRING(st, pos+1, 1) = \'J\' THEN\nSET pos = pos + 2;;\nELSE\nSET pos = pos + 1;;\nEND IF;;\nWHEN ch = \'K\' THEN\nIF SUBSTRING(st, pos+1, 1) = \'K\' THEN\nSET pri = CONCAT(pri, \'K\'), sec = CONCAT(sec, \'K\'), pos = pos  + 2;; -- nxt = (\'K\', 2)\nELSE\nSET pri = CONCAT(pri, \'K\'), sec = CONCAT(sec, \'K\'), pos = pos  + 1;; -- nxt = (\'K\', 1)\nEND IF;;\nWHEN ch = \'L\' THEN\nIF SUBSTRING(st, pos+1, 1) = \'L\' THEN\n--  spanish e.g. \'cabrillo\', \'gallegos\'\nIF (pos = (last - 2) AND SUBSTRING(st, pos-1, 4) IN (\'ILLO\', \'ILLA\', \'ALLE\'))\nOR ((SUBSTRING(st, last-1, 2) IN (\'AS\', \'OS\') OR SUBSTRING(st, last) IN (\'A\', \'O\'))\nAND SUBSTRING(st, pos-1, 4) = \'ALLE\') THEN\nSET pri = CONCAT(pri, \'L\'), pos = pos  + 2;; -- nxt = (\'L\', \' \', 2)\nELSE\nSET pri = CONCAT(pri, \'L\'), sec = CONCAT(sec, \'L\'), pos = pos  + 2;; -- nxt = (\'L\', 2)\nEND IF;;\nELSE\nSET pri = CONCAT(pri, \'L\'), sec = CONCAT(sec, \'L\'), pos = pos  + 1;; -- nxt = (\'L\', 1)\nEND IF;;\nWHEN ch = \'M\' THEN\nIF SUBSTRING(st, pos-1, 3) = \'UMB\'\nAND (pos + 1 = last OR SUBSTRING(st, pos+2, 2) = \'ER\')\nOR SUBSTRING(st, pos+1, 1) = \'M\' THEN\nSET pri = CONCAT(pri, \'M\'), sec = CONCAT(sec, \'M\'), pos = pos  + 2;; -- nxt = (\'M\', 2)\nELSE\nSET pri = CONCAT(pri, \'M\'), sec = CONCAT(sec, \'M\'), pos = pos  + 1;; -- nxt = (\'M\', 1)\nEND IF;;\nWHEN ch = \'N\' THEN\nIF SUBSTRING(st, pos+1, 1) = \'N\' THEN\nSET pri = CONCAT(pri, \'N\'), sec = CONCAT(sec, \'N\'), pos = pos  + 2;; -- nxt = (\'N\', 2)\nELSE\nSET pri = CONCAT(pri, \'N\'), sec = CONCAT(sec, \'N\'), pos = pos  + 1;; -- nxt = (\'N\', 1)\nEND IF;;\n-- ELSEIF ch = u\'Ñ\' THEN\n-- SET pri = CONCAT(pri, \'5\'), sec = CONCAT(sec, \'5\'), pos = pos  + 1;; -- nxt = (\'N\', 1)\nWHEN ch = \'P\' THEN\nIF SUBSTRING(st, pos+1, 1) = \'H\' THEN\nSET pri = CONCAT(pri, \'F\'), sec = CONCAT(sec, \'F\'), pos = pos  + 2;; -- nxt = (\'F\', 2)\nELSEIF SUBSTRING(st, pos+1, 1) IN (\'P\', \'B\') THEN --  also account for \'campbell\', \'raspberry\'\nSET pri = CONCAT(pri, \'P\'), sec = CONCAT(sec, \'P\'), pos = pos  + 2;; -- nxt = (\'P\', 2)\nELSE\nSET pri = CONCAT(pri, \'P\'), sec = CONCAT(sec, \'P\'), pos = pos  + 1;; -- nxt = (\'P\', 1)\nEND IF;;\nWHEN ch = \'Q\' THEN\nIF SUBSTRING(st, pos+1, 1) = \'Q\' THEN\nSET pri = CONCAT(pri, \'K\'), sec = CONCAT(sec, \'K\'), pos = pos  + 2;; -- nxt = (\'K\', 2)\nELSE\nSET pri = CONCAT(pri, \'K\'), sec = CONCAT(sec, \'K\'), pos = pos  + 1;; -- nxt = (\'K\', 1)\nEND IF;;\nWHEN ch = \'R\' THEN\n--  french e.g. \'rogier\', but exclude \'hochmeier\'\nIF pos = last AND not is_slavo_germanic\nAND SUBSTRING(st, pos-2, 2) = \'IE\' AND SUBSTRING(st, pos-4, 2) NOT IN (\'ME\', \'MA\') THEN\nSET sec = CONCAT(sec, \'R\');; -- nxt = (\'\', \'R\')\nELSE\nSET pri = CONCAT(pri, \'R\'), sec = CONCAT(sec, \'R\');; -- nxt = (\'R\',)\nEND IF;;\nIF SUBSTRING(st, pos+1, 1) = \'R\' THEN\nSET pos = pos + 2;;\nELSE\nSET pos = pos + 1;;\nEND IF;;\nWHEN ch = \'S\' THEN\n--  special cases \'island\', \'isle\', \'carlisle\', \'carlysle\'\nIF SUBSTRING(st, pos-1, 3) IN (\'ISL\', \'YSL\') THEN\nSET pos = pos + 1;;\n--  special case \'sugar-\'\nELSEIF pos = first AND SUBSTRING(st, first, 5) = \'SUGAR\' THEN\nSET pri = CONCAT(pri, \'X\'), sec = CONCAT(sec, \'S\'), pos = pos  + 1;; --  nxt =(\'X\', \'S\', 1)\nELSEIF SUBSTRING(st, pos, 2) = \'SH\' THEN\n--  germanic\nIF SUBSTRING(st, pos+1, 4) IN (\'HEIM\', \'HOEK\', \'HOLM\', \'HOLZ\') THEN\nSET pri = CONCAT(pri, \'S\'), sec = CONCAT(sec, \'S\'), pos = pos  + 2;; -- nxt = (\'S\', 2)\nELSE\nSET pri = CONCAT(pri, \'X\'), sec = CONCAT(sec, \'X\'), pos = pos  + 2;; -- nxt = (\'X\', 2)\nEND IF;;\n--  italian & armenian\nELSEIF SUBSTRING(st, pos, 3) IN (\'SIO\', \'SIA\') OR SUBSTRING(st, pos, 4) = \'SIAN\' THEN\nIF NOT is_slavo_germanic THEN\nSET pri = CONCAT(pri, \'S\'), sec = CONCAT(sec, \'X\'), pos = pos  + 3;; -- nxt = (\'S\', \'X\', 3)\nELSE\nSET pri = CONCAT(pri, \'S\'), sec = CONCAT(sec, \'S\'), pos = pos  + 3;; -- nxt = (\'S\', 3)\nEND IF;;\n--  german & anglicisations, e.g. \'smith\' match \'schmidt\', \'snider\' match \'schneider\'\n--  also, -sz- IN slavic language altho IN hungarian it is pronounced \'s\'\nELSEIF (pos = first AND SUBSTRING(st, pos+1, 1) IN (\'M\', \'N\', \'L\', \'W\')) OR SUBSTRING(st, pos+1, 1) = \'Z\' THEN\nSET pri = CONCAT(pri, \'S\'), sec = CONCAT(sec, \'X\');; -- nxt = (\'S\', \'X\')\nIF SUBSTRING(st, pos+1, 1) = \'Z\' THEN\nSET pos = pos + 2;;\nELSE\nSET pos = pos + 1;;\nEND IF;;\nELSEIF SUBSTRING(st, pos, 2) = \'SC\' THEN\n--  Schlesinger\'s rule\nIF SUBSTRING(st, pos+2, 1) = \'H\' THEN\n--  dutch origin, e.g. \'school\', \'schooner\'\nIF SUBSTRING(st, pos+3, 2) IN (\'OO\', \'ER\', \'EN\', \'UY\', \'ED\', \'EM\') THEN\n--  \'schermerhorn\', \'schenker\'\nIF SUBSTRING(st, pos+3, 2) IN (\'ER\', \'EN\') THEN\nSET pri = CONCAT(pri, \'X\'), sec = CONCAT(sec, \'SK\'), pos = pos  + 3;; -- nxt = (\'X\', \'SK\', 3)\nELSE\nSET pri = CONCAT(pri, \'SK\'), sec = CONCAT(sec, \'SK\'), pos = pos  + 3;; -- nxt = (\'SK\', 3)\nEND IF;;\nELSE\nIF pos = first AND SUBSTRING(st, first+3, 1) not IN (\'A\', \'E\', \'I\', \'O\', \'U\', \'Y\') AND SUBSTRING(st, first+3, 1) != \'W\' THEN\nSET pri = CONCAT(pri, \'X\'), sec = CONCAT(sec, \'S\'), pos = pos  + 3;; -- nxt = (\'X\', \'S\', 3)\nELSE\nSET pri = CONCAT(pri, \'X\'), sec = CONCAT(sec, \'X\'), pos = pos  + 3;; -- nxt = (\'X\', 3)\nEND IF;;\nEND IF;;\nELSEIF SUBSTRING(st, pos+2, 1) IN (\'I\', \'E\', \'Y\') THEN\nSET pri = CONCAT(pri, \'S\'), sec = CONCAT(sec, \'S\'), pos = pos  + 3;; -- nxt = (\'S\', 3)\nELSE\nSET pri = CONCAT(pri, \'SK\'), sec = CONCAT(sec, \'SK\'), pos = pos  + 3;; -- nxt = (\'SK\', 3)\nEND IF;;\n--  french e.g. \'resnais\', \'artois\'\nELSEIF pos = last AND SUBSTRING(st, pos-2, 2) IN (\'AI\', \'OI\') THEN\nSET sec = CONCAT(sec, \'S\'), pos = pos  + 1;; -- nxt = (\'\', \'S\')\nELSE\nSET pri = CONCAT(pri, \'S\'), sec = CONCAT(sec, \'S\');; -- nxt = (\'S\',)\nIF SUBSTRING(st, pos+1, 1) IN (\'S\', \'Z\') THEN\nSET pos = pos + 2;;\nELSE\nSET pos = pos + 1;;\nEND IF;;\nEND IF;;\nWHEN ch = \'T\' THEN\nIF SUBSTRING(st, pos, 4) = \'TION\' THEN\nSET pri = CONCAT(pri, \'X\'), sec = CONCAT(sec, \'X\'), pos = pos  + 3;; -- nxt = (\'X\', 3)\nELSEIF SUBSTRING(st, pos, 3) IN (\'TIA\', \'TCH\') THEN\nSET pri = CONCAT(pri, \'X\'), sec = CONCAT(sec, \'X\'), pos = pos  + 3;; -- nxt = (\'X\', 3)\nELSEIF SUBSTRING(st, pos, 2) = \'TH\' OR SUBSTRING(st, pos, 3) = \'TTH\' THEN\n--  special case \'thomas\', \'thames\' OR germanic\nIF SUBSTRING(st, pos+2, 2) IN (\'OM\', \'AM\') OR SUBSTRING(st, first, 4) IN (\'VON \', \'VAN \')\nOR SUBSTRING(st, first, 3) = \'SCH\' THEN\nSET pri = CONCAT(pri, \'T\'), sec = CONCAT(sec, \'T\'), pos = pos  + 2;; -- nxt = (\'T\', 2)\nELSE\nSET pri = CONCAT(pri, \'0\'), sec = CONCAT(sec, \'T\'), pos = pos  + 2;; -- nxt = (\'0\', \'T\', 2)\nEND IF;;\nELSEIF SUBSTRING(st, pos+1, 1) IN (\'T\', \'D\') THEN\nSET pri = CONCAT(pri, \'T\'), sec = CONCAT(sec, \'T\'), pos = pos  + 2;; -- nxt = (\'T\', 2)\nELSE\nSET pri = CONCAT(pri, \'T\'), sec = CONCAT(sec, \'T\'), pos = pos  + 1;; -- nxt = (\'T\', 1)\nEND IF;;\nWHEN ch = \'V\' THEN\nIF SUBSTRING(st, pos+1, 1) = \'V\' THEN\nSET pri = CONCAT(pri, \'F\'), sec = CONCAT(sec, \'F\'), pos = pos  + 2;; -- nxt = (\'F\', 2)\nELSE\nSET pri = CONCAT(pri, \'F\'), sec = CONCAT(sec, \'F\'), pos = pos  + 1;; -- nxt = (\'F\', 1)\nEND IF;;\nWHEN ch = \'W\' THEN\n--  can also be IN middle of word\nIF SUBSTRING(st, pos, 2) = \'WR\' THEN\nSET pri = CONCAT(pri, \'R\'), sec = CONCAT(sec, \'R\'), pos = pos  + 2;; -- nxt = (\'R\', 2)\nELSEIF pos = first AND (SUBSTRING(st, pos+1, 1) IN (\'A\', \'E\', \'I\', \'O\', \'U\', \'Y\')\nOR SUBSTRING(st, pos, 2) = \'WH\') THEN\n--  Wasserman should match Vasserman\nIF SUBSTRING(st, pos+1, 1) IN (\'A\', \'E\', \'I\', \'O\', \'U\', \'Y\') THEN\nSET pri = CONCAT(pri, \'A\'), sec = CONCAT(sec, \'F\'), pos = pos  + 1;; -- nxt = (\'A\', \'F\', 1)\nELSE\nSET pri = CONCAT(pri, \'A\'), sec = CONCAT(sec, \'A\'), pos = pos  + 1;; -- nxt = (\'A\', 1)\nEND IF;;\n--  Arnow should match Arnoff\nELSEIF (pos = last AND SUBSTRING(st, pos-1, 1) IN (\'A\', \'E\', \'I\', \'O\', \'U\', \'Y\'))\nOR SUBSTRING(st, pos-1, 5) IN (\'EWSKI\', \'EWSKY\', \'OWSKI\', \'OWSKY\')\nOR SUBSTRING(st, first, 3) = \'SCH\' THEN\nSET sec = CONCAT(sec, \'F\'), pos = pos  + 1;; -- nxt = (\'\', \'F\', 1)\n-- END IF;;\n--  polish e.g. \'filipowicz\'\nELSEIF SUBSTRING(st, pos, 4) IN (\'WICZ\', \'WITZ\') THEN\nSET pri = CONCAT(pri, \'TS\'), sec = CONCAT(sec, \'FX\'), pos = pos  + 4;; -- nxt = (\'TS\', \'FX\', 4)\nELSE --  default is to skip it\nSET pos = pos + 1;;\nEND IF;;\nWHEN ch = \'X\' THEN\n--  french e.g. breaux\nIF not(pos = last AND (SUBSTRING(st, pos-3, 3) IN (\'IAU\', \'EAU\')\nOR SUBSTRING(st, pos-2, 2) IN (\'AU\', \'OU\'))) THEN\nSET pri = CONCAT(pri, \'KS\'), sec = CONCAT(sec, \'KS\');; -- nxt = (\'KS\',)\nEND IF;;\nIF SUBSTRING(st, pos+1, 1) IN (\'C\', \'X\') THEN\nSET pos = pos + 2;;\nELSE\nSET pos = pos + 1;;\nEND IF;;\nWHEN ch = \'Z\' THEN\n--  chinese pinyin e.g. \'zhao\'\nIF SUBSTRING(st, pos+1, 1) = \'H\' THEN\nSET pri = CONCAT(pri, \'J\'), sec = CONCAT(sec, \'J\'), pos = pos  + 1;; -- nxt = (\'J\', 2)\nELSEIF SUBSTRING(st, pos+1, 3) IN (\'ZO\', \'ZI\', \'ZA\')\nOR (is_slavo_germanic AND pos > first AND SUBSTRING(st, pos-1, 1) != \'T\') THEN\nSET pri = CONCAT(pri, \'S\'), sec = CONCAT(sec, \'TS\');; -- nxt = (\'S\', \'TS\')\nELSE\nSET pri = CONCAT(pri, \'S\'), sec = CONCAT(sec, \'S\');; -- nxt = (\'S\',)\nEND IF;;\nIF SUBSTRING(st, pos+1, 1) = \'Z\' THEN\nSET pos = pos + 2;;\nELSE\nSET pos = pos + 1;;\nEND IF;;\nELSE\nSET pos = pos + 1;; -- DEFAULT is to move to next char\nEND CASE;;\nIF pos = prevpos THEN\nSET pos = pos +1;;\nSET pri = CONCAT(pri,\'<didnt incr>\');; -- it might be better to throw an error here if you really must be accurate\nEND IF;;\nEND WHILE;;\nIF pri != sec THEN\nSET pri = CONCAT(pri, \';;\', sec);;\nEND IF;;\nRETURN (pri);;\nEND ;','DROP FUNCTION IF EXISTS `dm` ;','applied',''),(111,'a76df841db2ecc681c4f87868337ebd14c0cf476','2025-11-05 00:11:44','ALTER TABLE patients\nADD dm_first_name VARCHAR(255),\nADD dm_last_name VARCHAR(255);\n\nSET SQL_SAFE_UPDATES=0;\nUPDATE patients\nSET dm_first_name = dm(first_name);\n\nUPDATE patients\nSET dm_last_name = dm(last_name);\nSET SQL_SAFE_UPDATES=1;','ALTER TABLE patients\nDROP COLUMN dm_first_name;\n\nALTER TABLE patients\nDROP COLUMN dm_last_name;','applied',''),(112,'889b7872fd4f74acc0fd1532cbf8dd21aca3ac5c','2025-11-05 00:11:44','CREATE TRIGGER insertDmFirst\nBEFORE INSERT\nON patients\nFOR EACH ROW\nSET new.dm_first_name = dm(new.first_name);\n\nCREATE TRIGGER updateDmFirst\nBEFORE UPDATE\nON patients\nFOR EACH ROW\nSET new.dm_first_name = dm(new.first_name);\n\nCREATE TRIGGER insertDmLast\nBEFORE INSERT\nON patients\nFOR EACH ROW\nSET new.dm_last_name = dm(new.last_name);\n\nCREATE TRIGGER updateDmLast\nBEFORE UPDATE\nON patients\nFOR EACH ROW\nSET new.dm_last_name = dm(new.last_name);','DROP TRIGGER insertDmFirst;\nDROP TRIGGER updateDmFirst;\nDROP TRIGGER insertDmLast;\nDROP TRIGGER updateDmLast;','applied',''),(113,'c4339a8257802000cc8726d027506c37755546fa','2025-11-05 00:11:44','CREATE TABLE `network_status` (\n`id` INT(11) NOT NULL AUTO_INCREMENT,\n`name` VARCHAR(255) NOT NULL,\n`val` VARCHAR(255) NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC));','DROP TABLE `network_status`;','applied',''),(114,'d674b4dba40b6a420cbfcb0d3964696060095753','2025-11-05 00:11:44','CREATE TABLE `kit_status` (\n`id` INT(11) NOT NULL AUTO_INCREMENT,\n`name` VARCHAR(255) NOT NULL,\n`val` VARCHAR(255) NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC));','DROP TABLE `kit_status`;','applied',''),(115,'2c58de20d6aeb3c765b16e3149b7de063083d882','2025-11-05 00:11:44','CREATE TABLE `database_status` (\n`id` INT(11) NOT NULL AUTO_INCREMENT,\n`name` VARCHAR(255) NOT NULL,\n`val` VARCHAR(255) NOT NULL,\nPRIMARY KEY (`id`),\nUNIQUE INDEX `id_UNIQUE` (`id` ASC));','DROP TABLE `database_status`;','applied',''),(116,'99b45e0a773dd7f2c002d89fc66e413c926cb765','2025-11-05 00:11:44','CREATE  TABLE `internet_status` (\n`id` INTEGER NOT NULL,\n`status` BOOLEAN NOT NULL,\nPRIMARY KEY (`id`));\n\nINSERT INTO `internet_status` (`id`, `status`) VALUES (\'0\', \'0\');','DROP TABLE IF EXISTS `internet_status`;','applied',''),(117,'bdd2382961409cf55698de1e8dba160e7a6b7ecc','2025-11-05 00:11:44','CREATE TABLE `language_codes` (\n`code` VARCHAR(5) NOT NULL,\n`language_name` VARCHAR(64) NOT NULL,\n`status` VARCHAR(64) NOT NULL,\n`updateScheduled` BOOLEAN NOT NULL,\nPRIMARY KEY (code)\n);','DROP TABLE IF EXISTS `language_codes`;','applied',''),(118,'07c3b0e2526ba28ac692470065206bcf3b13a835','2025-11-05 00:11:44','ALTER TABLE `users`\nADD COLUMN `language_code` VARCHAR(5) NULL;\n\nALTER TABLE `chief_complaints`\nADD COLUMN `language_code` VARCHAR(5) NULL;\n\nALTER TABLE `concept_diagnoses`\nADD COLUMN `language_code` VARCHAR(5) NULL;\n\nALTER TABLE `patient_prescriptions`\nADD COLUMN `language_code` VARCHAR(5) NULL;\n\nALTER TABLE `patient_encounters`\nADD COLUMN `language_code` VARCHAR(5) NULL;\n\nALTER TABLE `patient_age_classifications`\nADD COLUMN `language_code` VARCHAR(5) NULL;\n\nALTER TABLE `concept_medication_forms`\nADD COLUMN `language_code` VARCHAR(5) NULL;\n\nALTER TABLE `mission_teams`\nADD COLUMN `language_code` VARCHAR(5) NULL;\n\nALTER TABLE `photos`\nADD COLUMN `language_code` VARCHAR(5) NULL;','ALTER TABLE `users`\nDROP COLUMN `language_code`;\n\nALTER TABLE `chief_complaints`\nDROP COLUMN `language_code`;\n\nALTER TABLE `concept_diagnoses`\nDROP COLUMN `language_code`;\n\nALTER TABLE `patient_prescriptions`\nDROP COLUMN  `language_code`;\n\nALTER TABLE `patient_encounters`\nDROP COLUMN  `language_code`;\n\nALTER TABLE `patient_age_classifications`\nDROP COLUMN  `language_code`;\n\nALTER TABLE `concept_medication_forms`\nDROP COLUMN  `language_code`;\n\nALTER TABLE `mission_teams`\nDROP COLUMN `language_code`;\nALTER TABLE `photos`\nDROP COLUMN `language_code`;','applied',''),(119,'1fab9ae4a5be35d167b743f37daf666affa59de5','2025-11-05 00:11:45','CREATE  TABLE `measurement_categories` (\n`category` VARCHAR(16) PRIMARY KEY NOT NULL\n);','DROP TABLE IF EXISTS `measurement_categories`;','applied',''),(120,'e29dc1ef034d94b3d8df008ee81d19f677a6d797','2025-11-05 00:11:45','CREATE TABLE `measurement_units` (\n`id` INTEGER PRIMARY KEY NOT NULL,\n`unit` VARCHAR(16) NOT NULL,\n`category` VARCHAR(16) NOT NULL,\nFOREIGN KEY (`category`) REFERENCES `measurement_categories`(`category`)\n);','DROP TABLE IF EXISTS `measurement_units`;','applied',''),(121,'7e13a0cbc0e56f32f3ddac2a8808f8a0d44bf4e1','2025-11-05 00:11:45','CREATE  TABLE `pages` (\n`id` INT NOT NULL AUTO_INCREMENT ,\n`name` TEXT NOT NULL ,\nPRIMARY KEY (`id`) ,\nUNIQUE INDEX `id_UNIQUE` (`id` ASC) );','DROP TABLE IF EXISTS `pages`;','applied',''),(122,'266b5d90dbef4154ea5c898ec5c0dbb67eadf043','2025-11-05 00:11:45','CREATE TABLE `page_elements` (\n`element_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,\n`description` TEXT NOT NULL,\nUNIQUE INDEX `element_id_UNIQUE` (`element_id` ASC)\n);\n\nALTER TABLE `page_elements`\nCHANGE COLUMN `element_id` `element_id` INT NOT NULL AUTO_INCREMENT,\nADD COLUMN `page_id` INT NOT NULL,\nADD INDEX `fk_page_1_idx` (`page_id` ASC);\n\nALTER TABLE `page_elements`\nADD CONSTRAINT `fk_page_1`\nFOREIGN KEY (`page_id`)\nREFERENCES `pages` (`id`)\nON DELETE NO ACTION\nON UPDATE NO ACTION;','DROP TABLE IF EXISTS `page_elements`;','applied',''),(123,'ae8adc07c808404d5c95820594a0c5b841f75c1d','2025-11-05 00:11:45','CREATE TABLE `page_element_translations` (\n`translation_id` INT NOT NULL AUTO_INCREMENT,\n`element_id` INT NOT NULL,\n`language_code` VARCHAR(5) NOT NULL,\n`translation` TEXT NOT NULL,\nPRIMARY KEY (`translation_id`),\nUNIQUE INDEX `element_id_UNIQUE` (`element_id` ASC),\nCONSTRAINT `fk_element_id` FOREIGN KEY (`element_id`) REFERENCES `page_elements` (`element_id`) ON DELETE CASCADE ON UPDATE NO ACTION\n);','DROP TABLE IF EXISTS `page_element_translations`;','applied',''),(124,'9ff5c7996d639798168d5ffbb1a79e46d24c4132','2025-11-05 00:11:45','# --- Defaults multiple chief complaints to on in admin settings\nUPDATE `system_settings`\nSET `isActive`=1\nWHERE `id` = 1','','applied',''),(125,'95838bbea97858eed84da8fdbaa013609c47af13','2025-11-05 00:11:45','# --- Updated the name to make it more clear for the end user in admin settings\nUPDATE `kit_status`\nSET `name`= \"Backend Connection\"\nWHERE `id` = 1','','applied','');
/*!40000 ALTER TABLE `play_evolutions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Administrator'),(7,'Manager'),(5,'Nurse'),(3,'Pharmacist'),(2,'Physician'),(4,'Researcher'),(6,'SuperUser');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `isActive` bit(1) NOT NULL,
  `description` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES (1,'Multiple chief complaints','\0','When checked, a user can add multiple chief complaints for a patient'),(2,'Medical PMH Tab','','When checked, the Past Medical History tab on medical appears'),(3,'Medical Photo Tab','','When checked, the Photo tab on medical appears'),(4,'Medical HPI Consolidate','\0','When checked, the HPI tab on medical is consolidated into one Narrative text field'),(5,'Metric System Option','','When checked, the entire system becomes metric'),(6,'Country Filter','\0','When checked, patients from other countries will not show up in a search'),(7,'Diabetes Prompt','\0','When checked, asks a physician in medical if they screened a patient for diabetes when blood pressure is over 135/80 and age is over 18 OR older than 25 and BMI greater than or equal to 25');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tab_field_sizes`
--

DROP TABLE IF EXISTS `tab_field_sizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tab_field_sizes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tab_field_sizes`
--

LOCK TABLES `tab_field_sizes` WRITE;
/*!40000 ALTER TABLE `tab_field_sizes` DISABLE KEYS */;
INSERT INTO `tab_field_sizes` VALUES (2,'large'),(1,'medium');
/*!40000 ALTER TABLE `tab_field_sizes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tab_field_types`
--

DROP TABLE IF EXISTS `tab_field_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tab_field_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tab_field_types`
--

LOCK TABLES `tab_field_types` WRITE;
/*!40000 ALTER TABLE `tab_field_types` DISABLE KEYS */;
INSERT INTO `tab_field_types` VALUES (2,'number'),(1,'text'),(3,'yes/no');
/*!40000 ALTER TABLE `tab_field_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tab_fields`
--

DROP TABLE IF EXISTS `tab_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tab_fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `isDeleted` bit(1) NOT NULL DEFAULT b'0',
  `tab_id` int NOT NULL,
  `type_id` int DEFAULT NULL,
  `size_id` int DEFAULT NULL,
  `sort_order` int DEFAULT NULL,
  `placeholder` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `fk_tab_fields_tab_idx` (`tab_id`),
  KEY `fk_tab_fields_type_idx` (`type_id`),
  KEY `fk_tab_fields_size_idx` (`size_id`),
  CONSTRAINT `fk_tab_fields_size` FOREIGN KEY (`size_id`) REFERENCES `tab_field_sizes` (`id`),
  CONSTRAINT `fk_tab_fields_tab` FOREIGN KEY (`tab_id`) REFERENCES `tabs` (`id`),
  CONSTRAINT `fk_tab_fields_type` FOREIGN KEY (`type_id`) REFERENCES `tab_field_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tab_fields`
--

LOCK TABLES `tab_fields` WRITE;
/*!40000 ALTER TABLE `tab_fields` DISABLE KEYS */;
INSERT INTO `tab_fields` VALUES (26,'onset','\0',1,1,NULL,NULL,NULL),(27,'severity','\0',1,2,NULL,NULL,NULL),(28,'radiation','\0',1,1,NULL,NULL,NULL),(29,'quality','\0',1,1,NULL,NULL,NULL),(30,'provokes','\0',1,1,NULL,NULL,NULL),(31,'palliates','\0',1,1,NULL,NULL,NULL),(32,'timeOfDay','\0',1,1,NULL,NULL,NULL),(33,'physicalExamination','\0',1,1,NULL,NULL,NULL),(34,'narrative','\0',1,1,NULL,NULL,NULL),(35,'assessment','\0',3,1,NULL,NULL,NULL),(36,'problem','\0',3,1,NULL,NULL,NULL),(37,'procedure_counseling','\0',3,1,NULL,NULL,NULL),(38,'pharmacy_note','\0',3,1,NULL,NULL,NULL),(39,'medicalSurgicalHistory','\0',2,1,NULL,NULL,NULL),(40,'socialHistory','\0',2,1,NULL,NULL,NULL),(41,'currentMedication','\0',2,1,NULL,NULL,NULL),(42,'familyHistory','\0',2,1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tab_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabs`
--

DROP TABLE IF EXISTS `tabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tabs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `user_id` int DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `isDeleted` bit(1) NOT NULL DEFAULT b'0',
  `left_column_size` int NOT NULL DEFAULT '0',
  `right_column_size` int NOT NULL DEFAULT '0',
  `isCustom` bit(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`),
  KEY `fk_custom_tabs_user_id_idx` (`user_id`),
  CONSTRAINT `fk_custom_tabs_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabs`
--

LOCK TABLES `tabs` WRITE;
/*!40000 ALTER TABLE `tabs` DISABLE KEYS */;
INSERT INTO `tabs` VALUES (1,'HPI',NULL,'2025-11-05 00:11:46','\0',2,2,'\0'),(2,'PMH',NULL,'2025-11-05 00:11:46','\0',0,0,'\0'),(3,'Treatment',NULL,'2025-11-05 00:11:46','\0',0,0,'\0'),(4,'Photos',NULL,'2025-11-05 00:11:46','\0',0,0,'\0');
/*!40000 ALTER TABLE `tabs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `role_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `fk_user_roles_user_id_users_id` (`user_id`),
  KEY `fk_user_roles_role_id_roles_id` (`role_id`),
  CONSTRAINT `fk_user_roles_role_id_roles_id` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`),
  CONSTRAINT `fk_user_roles_user_id_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=216 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` VALUES (2,2,6),(29,3,5),(187,1,1),(209,4,1),(210,4,7),(211,4,5),(212,4,3),(213,4,2),(214,4,4),(215,4,6);
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `passwordCreatedDate` datetime NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `date_created` datetime DEFAULT '0000-01-01 00:00:00',
  `created_by` int DEFAULT NULL,
  `isDeleted` bit(1) NOT NULL DEFAULT b'0',
  `isPasswordReset` bit(1) NOT NULL DEFAULT b'0',
  `notes` varchar(255) DEFAULT NULL,
  `language_code` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Administrator','','admin','$2a$10$ZpNHH4KEjQWB6llihS/5K.YehrCDCSef29tP.Fq4GZDr1QoGTkiMe','2025-12-12 00:24:20','2026-03-17 16:13:28','2025-11-05 00:11:46',NULL,'\0','\0',NULL,'en'),(2,'SuperUser','','superuser','$2a$10$xniQrmCSeQamJCsBS2OoY.Fq1.NmJmIXuypNd2kmiO7cWP9pcY2ye','2025-11-05 00:11:46','2025-11-05 00:11:46','2025-11-05 00:11:46',NULL,'\0','\0',NULL,'en'),(3,'TestNurse','','testnurse','$2a$10$onbZaxe58Szd1tT1ivUaNugHaqkNGuH3qK4GXG18JmOctuLJWCpVS','2025-11-05 00:11:46','2025-11-06 23:50:17','2025-11-05 00:11:46',NULL,'\0','\0',NULL,'en'),(4,'Manager','l','test@email.com','$2a$10$JgDeOaASE2xj6C103PSHd.Ykyo5/52aN7WzQTzjZbdQxJivOf9evW','2026-01-06 21:45:14','2026-04-07 20:10:37','2025-11-05 00:19:11',1,'\0','\0','a','en');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vitals`
--

DROP TABLE IF EXISTS `vitals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vitals` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `data_type` varchar(255) DEFAULT NULL,
  `unit_of_measurement` varchar(255) DEFAULT NULL,
  `isDeleted` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vitals`
--

LOCK TABLES `vitals` WRITE;
/*!40000 ALTER TABLE `vitals` DISABLE KEYS */;
INSERT INTO `vitals` VALUES (1,'respiratoryRate','int','breaths/minute','\0'),(2,'heartRate','int','beats/minute','\0'),(3,'temperature','float','Fahrenheit','\0'),(4,'oxygenSaturation','float','percent','\0'),(5,'heightFeet','int','feet','\0'),(6,'heightInches','int','inches','\0'),(7,'weight','float','pounds','\0'),(8,'bloodPressureSystolic','int','mmHg','\0'),(9,'bloodPressureDiastolic','int','diastolic','\0'),(10,'glucose','int','mg/dl','\0'),(11,'weeksPregnant','integer','weeks','\0'),(12,'smoker','int','True/False','\0'),(13,'diabetic','int','True/False','\0'),(14,'alcohol','int','True/False','\0'),(15,'cholesterol','int','True/False','\0'),(16,'hypertension','int','True/False','\0');
/*!40000 ALTER TABLE `vitals` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-07 20:10:41
